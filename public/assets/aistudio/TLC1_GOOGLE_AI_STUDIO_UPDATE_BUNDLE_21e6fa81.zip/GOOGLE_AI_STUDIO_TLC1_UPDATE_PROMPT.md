# Google AI Studio Master Implementation Prompt — TLC-1 Pune Real Estate Project Master Database Update

Copy and paste the prompt block below directly into **Google AI Studio** along with uploading `TLC1_GOOGLE_AI_STUDIO_UPDATE_BUNDLE.zip` (or the JSON/Kotlin files inside it) to update your **TLC-1 (`pavanpatil93-dot/Tlc-1`)** application.

---

## COPY-PASTE PROMPT FOR GOOGLE AI STUDIO

```text
ROLE & OBJECTIVE:
You are the Lead Android & Full-Stack Database Architect updating the existing TLC-1 application (Repository: pavanpatil93-dot/Tlc-1).
I have attached the verified "TLC-1 Pune Real Estate Master Project Database" bundle (`TLC1_GOOGLE_AI_STUDIO_UPDATE_BUNDLE.zip`), which contains:
1. `assets/master_db/*.json` — 14 normalized relational JSON tables + `manifest.json` covering 124 verified real estate projects and 36 developer groups across Pune & PCMC (with East Pune priority).
2. `assets/master_db/tlc1_pune_master_projects.db` — Pre-built, referentially validated SQLite database containing the exact same 14 normalized tables.
3. `android_kotlin_room/MasterProjectEntities.kt`, `MasterProjectDao.kt`, and `MasterDatabaseSeeder.kt` — Ready-to-integrate Room Entities, DAO, and Coroutine JSON Asset Seeder.
4. `docs/SCHEMA.md` & `docs/IMPORT_GUIDE_TLC1.md` — Full DDL specifications and non-destructive upsert rules.

BUSINESS DIVISION ROUTING (CRITICAL):
The TLC-1 app supports two operational divisions that share this unified Project Master Database:
1. ASCEND COMMERCIAL SOLUTIONS (`business_division IN ('ASCEND', 'BOTH')`):
   - Commercial office towers, Grade-A IT parks / SEZs, business parks, high-street retail, showrooms, industrial/logistics parks, and commercial investment properties (53 commercial/mixed-use projects & configurations).
   - Area measurements strictly preserve Carpet Area vs. Built-Up Area vs. Chargeable Area (`area_basis`).
2. AUREA LIVING LLP (`business_division IN ('AUREA', 'BOTH')`):
   - Residential apartments, luxury residences, villas, row houses, plotted developments, and integrated townships (80 residential/mixed-use projects & configurations).

NON-DESTRUCTIVE INVENTORY SEPARATION RULE (MANDATORY):
- Strictly separate Project Master Directory data (`projects`, `developers`, `project_locations`, `project_phases`, `project_towers`, `residential_configurations`, `commercial_configurations`, `project_amenities`, `project_aliases`, `project_rera_registrations`, `project_price_observations`, `project_sources`, `project_verification`, `project_change_history`) from Employee Unit Inventory (`ACS-OL-####`, `ACS-OS-####`, `ACS-RL-####`, `ACS-RS-####`, `AUR-RS-####`, `AUR-RR-####`, `AUR-PL-####`), direct owner/landlord POC mobile numbers, and active CRM requirement leads.
- NEVER drop, clear, or overwrite employee-entered unit inventory, owner contacts, or CRM leads during database migration or master project seeding.
- Link existing or new employee unit inventory items to `projects.project_id` (e.g., `TLC-PRJ-001` through `TLC-PRJ-124`) as a foreign key.

IMPLEMENTATION TASKS TO EXECUTE IN TLC-1:

TASK 1 — INTEGRATE NORMALIZED ROOM ENTITIES & DAO:
- Add all 14 `@Entity` classes from `android_kotlin_room/MasterProjectEntities.kt` (`DeveloperEntity`, `ProjectEntity`, `ProjectLocationEntity`, `ProjectPhaseEntity`, `ProjectTowerEntity`, `ResidentialConfigEntity`, `CommercialConfigEntity`, `ProjectAmenityEntity`, `ProjectAliasEntity`, `ProjectReraEntity`, `ProjectSourceEntity`, `PriceObservationEntity`, `ProjectVerificationEntity`, `ProjectChangeHistoryEntity`) to the TLC-1 Room `@Database` declaration.
- Register `MasterProjectDao` in the Room database class and add a non-destructive Room `Migration` that runs `CREATE TABLE IF NOT EXISTS` and `CREATE INDEX IF NOT EXISTS` for all 14 tables (exact SQLite DDL is in `docs/SCHEMA.md`).

TASK 2 — ASSET PACKAGING & IDEMPOTENT STARTUP SEEDING:
- Place all 15 JSON files (`projects.json`, `developers.json`, `project_phases.json`, `project_towers.json`, `residential_configurations.json`, `commercial_configurations.json`, `project_amenities.json`, `project_rera.json`, `project_price_observations.json`, `project_sources.json`, `project_aliases.json`, `project_locations.json`, `project_verification.json`, `project_change_history.json`, `manifest.json`) inside `app/src/main/assets/master_db/`.
- Run `MasterDatabaseSeeder.seedOrRefreshMasterDatabase()` on app startup (or via the "Sync Master Project Directory" button in Settings) inside `Dispatchers.IO` when `manifest.json`'s `schema_version` / `generated_at` is newer than SharedPreferences `last_seeded_master_version`.
- Ensure all seeding uses `@Upsert` (`INSERT OR REPLACE` on master tables only, or `INSERT OR IGNORE` on `project_change_history`) so foreign-key links from employee inventory remain intact.

TASK 3 — DIVISION-AWARE UI, ALIAS SEARCH & EAST PUNE PRIORITY FILTERING:
- Update the Project Directory & Requirement Matcher screens so users can:
  1. Toggle between **All Divisions**, **Ascend Commercial Solutions (`ASCEND` + `BOTH`)**, and **Aurea Living LLP (`AUREA` + `BOTH`)**.
  2. Filter by **Pune Corridor / Zone** (`East Pune` prioritized first, `West Pune`, `North Pune / PCMC`, `South Pune`, `Central Pune`, `Extended Pune`), **Civic Body** (`PMC`, `PCMC`, `PMRDA`, `MIDC`), **Locality** (45 canonical localities), **Category/Subcategory**, **Construction Status**, and **Verification Badge** (`RERA_VERIFIED`, `DEVELOPER_VERIFIED`, `PORTAL_ONLY`, `VERIFICATION_PENDING`).
  3. Search seamlessly across `official_project_name`, `alternate_project_name`, `marketing_name`, `developer_name`, `locality`, `rera_registration_number`, AND `project_aliases.alias_name` (so searching "KP Towers", "EON IT Park", "WTC Kharadi", "New Kalyani Nagar", or "Blue Waters" resolves to the exact canonical project).
- On the Project Detail screen:
  - Display the Project Identity, Developer Card, MahaRERA Status Badge & Registration Number, Administrative vs. Marketing Locality, Google Maps deep link (`google_maps_url`), Phase/Tower specs, Confirmed Amenities, and Source Attribution links (`official_project_url`, `source_portal_url`, `last_verified_date`).
  - If `project_category` is `Commercial` or `Mixed-Use`, show the **Commercial Configurations** card (`asset_subclass`, `unit_configuration`, `area_range`, `area_basis`, `office_condition`, `floor_to_floor_height`, `parking_allocation`).
  - If `project_category` is `Residential` or `Mixed-Use`, show the **Residential Configurations** card (`bhk_type`, `carpet_area_range`, `price_range_display`, `starting_advertised_price_inr`).
  - Show a dedicated **"Available Employee Unit Inventory in This Project"** section below the master project specs that queries the operational `unit_inventory` table by `project_id`, plus an **"+ Add Unit to This Project"** button that pre-fills `project_id`, `official_project_name`, `developer_name`, `locality`, and `rera_registration_number`.

OUTPUT EXPECTATION:
Provide the complete, updated code files (Database class, Migration, Entities, DAO, Seeder, Repository/ViewModel, and Compose/XML UI screens) with zero placeholders or truncated methods.
```
