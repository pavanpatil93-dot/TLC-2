#!/usr/bin/env python3
"""Automated Integrity & Referential Validator for TLC-1 Pune Master Project Database."""

import json
import pathlib
import sys

BASE_DIR = pathlib.Path(__file__).resolve().parent
JSON_DIR = BASE_DIR.parent / "json" if (BASE_DIR.parent / "json").exists() else BASE_DIR / "json"

REQUIRED_JSON_FILES = [
    "projects.json",
    "developers.json",
    "project_phases.json",
    "project_towers.json",
    "residential_configurations.json",
    "commercial_configurations.json",
    "project_amenities.json",
    "project_rera.json",
    "project_price_observations.json",
    "project_sources.json",
    "project_aliases.json",
    "project_locations.json",
    "project_verification.json",
    "project_change_history.json",
    "manifest.json",
]

PRIMARY_KEYS = {
    "projects.json": "project_id",
    "developers.json": "developer_id",
    "project_phases.json": "phase_id",
    "project_towers.json": "tower_id",
    "residential_configurations.json": "res_config_id",
    "commercial_configurations.json": "comm_config_id",
    "project_amenities.json": "amenity_id",
    "project_rera.json": "rera_record_id",
    "project_price_observations.json": "price_observation_id",
    "project_sources.json": "source_id",
    "project_aliases.json": "alias_id",
    "project_locations.json": "location_id",
    "project_verification.json": "verification_id",
    "project_change_history.json": "change_id",
}


def main():
    errors = []
    loaded = {}

    print(f"Validating JSON tables in: {JSON_DIR}")
    for fname in REQUIRED_JSON_FILES:
        fpath = JSON_DIR / fname
        if not fpath.exists():
            errors.append(f"Missing required JSON file: {fname}")
            continue
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                loaded[fname] = json.load(f)
        except Exception as exc:
            errors.append(f"Invalid JSON syntax in {fname}: {exc}")

    if errors:
        for e in errors:
            print(f"[ERROR] {e}")
        sys.exit(1)

    # 1. Primary Key Uniqueness Checks
    pk_sets = {}
    for fname, pk_field in PRIMARY_KEYS.items():
        records = loaded[fname]
        seen = set()
        for idx, r in enumerate(records):
            val = r.get(pk_field)
            if not val:
                errors.append(f"{fname}[{idx}] missing primary key '{pk_field}'")
            elif val in seen:
                errors.append(f"{fname} duplicate primary key '{pk_field}': {val}")
            else:
                seen.add(val)
        pk_sets[fname] = seen
        print(f"  [OK] {fname}: {len(records)} records, unique PK '{pk_field}' verified.")

    # 2. Foreign Key Referential Integrity Checks
    project_ids = pk_sets["projects.json"]
    developer_ids = pk_sets["developers.json"]
    phase_ids = pk_sets["project_phases.json"]
    source_ids = pk_sets["project_sources.json"]

    for p in loaded["projects.json"]:
        if p["developer_id"] not in developer_ids:
            errors.append(f"projects.json ({p['project_id']}) references unknown developer_id: {p['developer_id']}")
        for req in ("official_project_name", "project_category", "locality", "zone", "verification_status"):
            if not p.get(req):
                errors.append(f"projects.json ({p['project_id']}) missing required field: {req}")

    fk_project_tables = [
        "project_phases.json",
        "project_towers.json",
        "residential_configurations.json",
        "commercial_configurations.json",
        "project_amenities.json",
        "project_rera.json",
        "project_price_observations.json",
        "project_sources.json",
        "project_aliases.json",
        "project_locations.json",
        "project_verification.json",
        "project_change_history.json",
    ]
    for tname in fk_project_tables:
        for r in loaded[tname]:
            pid = r.get("project_id")
            if pid not in project_ids:
                errors.append(f"{tname} references orphan project_id: {pid}")

    for t in loaded["project_towers.json"]:
        if t.get("phase_id") not in phase_ids:
            errors.append(f"project_towers.json ({t['tower_id']}) references orphan phase_id: {t.get('phase_id')}")

    for prc in loaded["project_price_observations.json"]:
        if prc.get("source_id") not in source_ids:
            errors.append(f"project_price_observations.json ({prc['price_observation_id']}) references orphan source_id: {prc.get('source_id')}")

    if errors:
        print("\nVALIDATION FAILED:")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)

    print("\nALL VALIDATION CHECKS PASSED SUCCESSFULLY (0 Errors, 100% Referential Integrity).")


if __name__ == "__main__":
    main()
