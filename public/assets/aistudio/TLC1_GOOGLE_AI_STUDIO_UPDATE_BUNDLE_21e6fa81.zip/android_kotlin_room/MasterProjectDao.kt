package com.tlc1.pune.data.master

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface MasterProjectDao {

    @Upsert
    suspend fun upsertDevelopers(items: List<DeveloperEntity>)

    @Upsert
    suspend fun upsertProjects(items: List<ProjectEntity>)

    @Upsert
    suspend fun upsertLocations(items: List<ProjectLocationEntity>)

    @Upsert
    suspend fun upsertPhases(items: List<ProjectPhaseEntity>)

    @Upsert
    suspend fun upsertTowers(items: List<ProjectTowerEntity>)

    @Upsert
    suspend fun upsertResidentialConfigs(items: List<ResidentialConfigEntity>)

    @Upsert
    suspend fun upsertCommercialConfigs(items: List<CommercialConfigEntity>)

    @Upsert
    suspend fun upsertAmenities(items: List<ProjectAmenityEntity>)

    @Upsert
    suspend fun upsertAliases(items: List<ProjectAliasEntity>)

    @Upsert
    suspend fun upsertReraRecords(items: List<ProjectReraEntity>)

    @Upsert
    suspend fun upsertSources(items: List<ProjectSourceEntity>)

    @Upsert
    suspend fun upsertPriceObservations(items: List<PriceObservationEntity>)

    @Upsert
    suspend fun upsertVerifications(items: List<ProjectVerificationEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertChangeHistory(items: List<ProjectChangeHistoryEntity>)

    @Query("""
        SELECT DISTINCT p.* FROM projects p
        LEFT JOIN project_aliases a ON p.project_id = a.project_id
        WHERE (:division = 'ALL' OR p.business_division = :division OR p.business_division = 'BOTH')
          AND (:zone = 'ALL' OR p.zone = :zone)
          AND (:locality = 'ALL' OR p.locality = :locality)
          AND (:category = 'ALL' OR p.project_category = :category)
          AND (
              :searchQuery = ''
              OR p.official_project_name LIKE '%' || :searchQuery || '%'
              OR p.alternate_project_name LIKE '%' || :searchQuery || '%'
              OR p.marketing_name LIKE '%' || :searchQuery || '%'
              OR p.developer_name LIKE '%' || :searchQuery || '%'
              OR p.locality LIKE '%' || :searchQuery || '%'
              OR p.rera_registration_number LIKE '%' || :searchQuery || '%'
              OR a.alias_name LIKE '%' || :searchQuery || '%'
          )
        ORDER BY
          CASE WHEN p.zone = 'East Pune' THEN 0 ELSE 1 END,
          p.locality ASC,
          p.official_project_name ASC
    """)
    fun observeFilteredProjects(
        division: String = "ALL",
        zone: String = "ALL",
        locality: String = "ALL",
        category: String = "ALL",
        searchQuery: String = ""
    ): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE project_id = :projectId LIMIT 1")
    suspend fun getProjectById(projectId: String): ProjectEntity?

    @Query("SELECT * FROM residential_configurations WHERE project_id = :projectId")
    suspend fun getResidentialConfigsForProject(projectId: String): List<ResidentialConfigEntity>

    @Query("SELECT * FROM commercial_configurations WHERE project_id = :projectId")
    suspend fun getCommercialConfigsForProject(projectId: String): List<CommercialConfigEntity>

    @Query("SELECT * FROM project_locations WHERE project_id = :projectId LIMIT 1")
    suspend fun getLocationForProject(projectId: String): ProjectLocationEntity?

    @Query("SELECT * FROM project_rera_registrations WHERE project_id = :projectId")
    suspend fun getReraForProject(projectId: String): List<ProjectReraEntity>

    @Query("SELECT * FROM project_price_observations WHERE project_id = :projectId")
    suspend fun getPriceObservationsForProject(projectId: String): List<PriceObservationEntity>

    @Query("SELECT * FROM project_aliases WHERE project_id = :projectId")
    suspend fun getAliasesForProject(projectId: String): List<ProjectAliasEntity>
}
