package com.tlc1.pune.data.master

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

class MasterDatabaseSeeder(
    private val context: Context,
    private val dao: MasterProjectDao
) {
    private val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    private inline fun <reified T> readAssetJson(fileName: String): List<T> {
        val raw = context.assets.open("master_db/$fileName").bufferedReader().use { it.readText() }
        return jsonParser.decodeFromString(raw)
    }

    /**
     * Seeds or refreshes all 14 Pune Project Master tables idempotently via Room @Upsert.
     * NEVER deletes or overwrites employee unit inventory (ACS-*, AUR-*), owner POCs, or CRM leads.
     */
    suspend fun seedOrRefreshMasterDatabase() = withContext(Dispatchers.IO) {
        dao.upsertDevelopers(readAssetJson("developers.json"))
        dao.upsertProjects(readAssetJson("projects.json"))
        dao.upsertLocations(readAssetJson("project_locations.json"))
        dao.upsertPhases(readAssetJson("project_phases.json"))
        dao.upsertTowers(readAssetJson("project_towers.json"))
        dao.upsertResidentialConfigs(readAssetJson("residential_configurations.json"))
        dao.upsertCommercialConfigs(readAssetJson("commercial_configurations.json"))
        dao.upsertAmenities(readAssetJson("project_amenities.json"))
        dao.upsertAliases(readAssetJson("project_aliases.json"))
        dao.upsertReraRecords(readAssetJson("project_rera.json"))
        dao.upsertSources(readAssetJson("project_sources.json"))
        dao.upsertPriceObservations(readAssetJson("project_price_observations.json"))
        dao.upsertVerifications(readAssetJson("project_verification.json"))
        dao.insertChangeHistory(readAssetJson("project_change_history.json"))
    }
}
