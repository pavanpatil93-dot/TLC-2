package com.tlc1.pune.data.master

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "developers")
data class DeveloperEntity(
    @PrimaryKey val developer_id: String,
    val developer_name: String,
    val developer_group: String,
    val specialization: String? = null,
    val headquarters_city: String? = null,
    val registered_office_address: String? = null,
    val website_url: String? = null,
    val verification_status: String,
    val data_quality: String,
    val last_verified_date: String
)

@Serializable
@Entity(
    tableName = "projects",
    foreignKeys = [
        ForeignKey(
            entity = DeveloperEntity::class,
            parentColumns = ["developer_id"],
            childColumns = ["developer_id"],
            onUpdate = ForeignKey.CASCADE,
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["locality"]),
        Index(value = ["zone"]),
        Index(value = ["project_category"]),
        Index(value = ["business_division"]),
        Index(value = ["developer_id"]),
        Index(value = ["rera_registration_number"])
    ]
)
data class ProjectEntity(
    @PrimaryKey val project_id: String,
    val official_project_name: String,
    val alternate_project_name: String? = null,
    val marketing_name: String? = null,
    val developer_id: String,
    val developer_name: String,
    val business_division: String, // "ASCEND", "AUREA", or "BOTH"
    val project_category: String,  // "Commercial", "Residential", or "Mixed-Use"
    val project_subcategory: String,
    val primary_phase: String? = null,
    val rera_registration_number: String,
    val rera_registration_status: String,
    val verification_status: String,
    val data_quality: String,
    val zone: String,
    val administrative_body: String,
    val locality: String,
    val sublocality: String? = null,
    val pin_code: String? = null,
    val total_land_area_acres: Double? = null,
    val total_towers: Int? = null,
    val total_floors: Int? = null,
    val total_units: Int? = null,
    val residential_unit_count: Int? = null,
    val commercial_unit_count: Int? = null,
    val launch_date: String? = null,
    val expected_possession_date: String? = null,
    val construction_status: String,
    val oc_cc_status: String? = null,
    val configurations_summary: String? = null,
    val area_range_summary: String? = null,
    val advertised_price_range: String? = null,
    val official_project_url: String? = null,
    val source_portal_url: String? = null,
    val last_verified_date: String
)

@Serializable
@Entity(
    tableName = "project_locations",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"])]
)
data class ProjectLocationEntity(
    @PrimaryKey val location_id: String,
    val project_id: String,
    val country: String,
    val state: String,
    val city: String,
    val zone: String,
    val administrative_area: String,
    val locality: String,
    val sublocality: String? = null,
    val full_address: String,
    val pin_code: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val google_maps_url: String? = null,
    val main_road_access: String? = null,
    val nearby_landmarks: String? = null
)

@Serializable
@Entity(
    tableName = "project_phases",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"])]
)
data class ProjectPhaseEntity(
    @PrimaryKey val phase_id: String,
    val project_id: String,
    val phase_name: String,
    val rera_registration_number: String? = null,
    val launch_date: String? = null,
    val expected_possession_date: String? = null,
    val construction_status: String? = null,
    val total_towers_in_phase: Int? = null,
    val total_units_in_phase: Int? = null
)

@Serializable
@Entity(
    tableName = "project_towers",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ProjectPhaseEntity::class,
            parentColumns = ["phase_id"],
            childColumns = ["phase_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"]), Index(value = ["phase_id"])]
)
data class ProjectTowerEntity(
    @PrimaryKey val tower_id: String,
    val project_id: String,
    val phase_id: String,
    val tower_name: String,
    val total_floors: Int? = null,
    val building_structure: String? = null,
    val lift_specifications: String? = null,
    val parking_levels: String? = null
)

@Serializable
@Entity(
    tableName = "residential_configurations",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"])]
)
data class ResidentialConfigEntity(
    @PrimaryKey val res_config_id: String,
    val project_id: String,
    val phase_id: String,
    val bhk_type: String,
    val carpet_area_range: String? = null,
    val area_basis: String,
    val starting_advertised_price_inr: Long? = null,
    val maximum_advertised_price_inr: Long? = null,
    val price_range_display: String? = null,
    val price_observation_date: String,
    val price_source_url: String? = null
)

@Serializable
@Entity(
    tableName = "commercial_configurations",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"])]
)
data class CommercialConfigEntity(
    @PrimaryKey val comm_config_id: String,
    val project_id: String,
    val phase_id: String,
    val asset_subclass: String,
    val unit_configuration: String,
    val area_range: String? = null,
    val area_basis: String,
    val office_condition: String? = null,
    val floor_to_floor_height: String? = null,
    val hvac_and_power_backup: String? = null,
    val parking_allocation: String? = null,
    val possession_status: String? = null,
    val asking_price_display: String? = null,
    val starting_price_inr: Long? = null,
    val maximum_price_inr: Long? = null,
    val observation_date: String,
    val source_url: String? = null
)

@Serializable
@Entity(
    tableName = "project_amenities",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"])]
)
data class ProjectAmenityEntity(
    @PrimaryKey val amenity_id: String,
    val project_id: String,
    val confirmed_amenities: String,
    val clubhouse: Boolean,
    val swimming_pool: Boolean,
    val gymnasium: Boolean,
    val security_cctv: Boolean,
    val power_backup: Boolean,
    val fire_safety: Boolean,
    val commercial_lobby_highspeed_lifts: Boolean
)

@Serializable
@Entity(
    tableName = "project_aliases",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"]), Index(value = ["alias_name"])]
)
data class ProjectAliasEntity(
    @PrimaryKey val alias_id: String,
    val project_id: String,
    val canonical_name: String,
    val alias_name: String,
    val alias_type: String,
    val source_portal: String? = null,
    val deduplication_rule: String? = null
)

@Serializable
@Entity(
    tableName = "project_rera_registrations",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"]), Index(value = ["rera_registration_number"])]
)
data class ProjectReraEntity(
    @PrimaryKey val rera_record_id: String,
    val project_id: String,
    val phase_id: String,
    val rera_registration_number: String,
    val registered_project_name: String,
    val promoter_name: String,
    val registered_locality: String? = null,
    val proposed_completion_date: String? = null,
    val rera_verification_classification: String,
    val official_rera_portal_url: String? = null
)

@Serializable
@Entity(
    tableName = "project_sources",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"])]
)
data class ProjectSourceEntity(
    @PrimaryKey val source_id: String,
    val project_id: String,
    val source_name: String,
    val source_url: String,
    val retrieved_timestamp: String,
    val source_category: String,
    val access_status: String,
    val reliability_classification: String
)

@Serializable
@Entity(
    tableName = "project_price_observations",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ProjectSourceEntity::class,
            parentColumns = ["source_id"],
            childColumns = ["source_id"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["project_id"]), Index(value = ["source_id"])]
)
data class PriceObservationEntity(
    @PrimaryKey val price_observation_id: String,
    val project_id: String,
    val configuration_id: String? = null,
    val price_display: String? = null,
    val min_asking_price_inr: Long? = null,
    val max_asking_price_inr: Long? = null,
    val price_per_sqft_inr: Long? = null,
    val area_basis: String,
    val currency: String,
    val observation_date: String,
    val source_id: String,
    val source_url: String? = null,
    val price_type: String,
    val verification_status: String
)

@Serializable
@Entity(
    tableName = "project_verification",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"])]
)
data class ProjectVerificationEntity(
    @PrimaryKey val verification_id: String,
    val project_id: String,
    val verification_status: String,
    val data_quality_band: String,
    val rera_matched: Boolean,
    val developer_site_matched: Boolean,
    val multi_portal_corroborated: Boolean,
    val conflicting_fields_flagged: String? = null,
    val auditor_notes: String? = null,
    val last_verified_date: String
)

@Serializable
@Entity(
    tableName = "project_change_history",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["project_id"],
            childColumns = ["project_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["project_id"])]
)
data class ProjectChangeHistoryEntity(
    @PrimaryKey val change_id: String,
    val project_id: String,
    val change_timestamp: String,
    val change_type: String,
    val changed_by: String,
    val source_id: String,
    val conflict_resolution_policy: String,
    val change_summary: String
)
