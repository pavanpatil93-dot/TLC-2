# TLC-1 Pune Real Estate Master Database — Source & Locality Coverage (`SOURCE_COVERAGE.md`)

## 1. Portal & Official Source Access Audit

| Source Category | Portal / Website | Access Status | Coverage & Retrieval Notes |
| :--- | :--- | :---: | :--- |
| **Official Regulatory** | `maharera.maharashtra.gov.in` | `PARTIAL_CAPTCHA` | Public project registration numbers (`P521000...`, `PR126000...`, `PM126000...`) verified via indexed certificates and official developer RERA disclosures; direct bulk scraping of CAPTCHA-gated detail forms avoided per compliance rules. |
| **Civic Authorities** | `pmc.gov.in`, `pcmcindia.gov.in`, `pmrda.gov.in` | `ACCESSIBLE_PUBLIC` | Used to classify administrative boundaries (`PMC`, `PCMC`, `PMRDA`, `MIDC`) and correct portal marketing location tags. |
| **Major Property Portals** | `99acres.com`, `housing.com`, `magicbricks.com`, `nobroker.in`, `squareyards.com`, `commonfloor.com` | `ACCESSIBLE_PUBLIC` | Public project directories, RERA-registered project indexes, commercial office/retail pages, and price range observations retrieved with source URLs and timestamps. |
| **Commercial IPCs & Leasing** | `property.jll.co.in`, `cbre.co.in`, `colliers.com`, `cushmanwakefield.com`, `knightfrank.co.in`, `myhq.in`, `daftar.com`, `floortap.com` | `ACCESSIBLE_PUBLIC` | Grade-A IT parks, SEZ floor plates, warm-shell/bare-shell specifications, and institutional REIT assets verified. |
| **Developer Portals** | `panchshil.com`, `koltepatil.com`, `gera.in`, `vtprealty.in`, `godrejproperties.com`, `lodhagroup.com`, `kohinoorpune.com`, `vilasjavdekar.com`, `rohanbuilders.com`, `nyatigroup.com`, `mantraproperties.in`, `bramhacorp.in`, `amanora.com`, `mindspaceindia.com`, `in.esr.com` | `ACCESSIBLE_PUBLIC` | Direct verification of canonical project names, phase structures, RERA numbers, and launch/possession timelines. |

## 2. Locality-by-Locality Coverage Matrix (45 Localities Across 6 Corridors)

|Pune Corridor|Civic Body|Locality|Total Projects|Residential|Commercial|Mixed-Use|RERA/Dev Verified|Portal Only|Primary Sources|
|:---|:---:|:---|---:|---:|---:|---:|---:|---:|:---|
|Central Pune|PMC|Sadashiv Peth|1|1|0|0|1|0|nyatigroup.com|
|Central Pune|PMC|Shivajinagar|2|1|1|0|2|0|property.jll.co.in, rohanbuilders.com|
|East Pune|PMC|Amanora|1|0|0|1|1|0|amanora.com|
|East Pune|PMC|Dhanori|2|1|0|1|2|0|mantraproperties.in, nyatigroup.com|
|East Pune|PMC|Hadapsar|3|1|2|0|1|2|99acres.com, cityair.in, myhq.in|
|East Pune|PMC|Kalyani Nagar|5|3|2|0|3|2|bramhacorp.in, commonfloor.com, daftar.com, infobitwiz.com|
|East Pune|PMC|Keshav Nagar|2|2|0|0|2|0|godrejproperties.com, mantraproperties.in|
|East Pune|PMC|Kharadi|29|14|15|0|18|11|99acres.com, daftar.com, gera.in, housing.com|
|East Pune|PMRDA|Kharadi|1|1|0|0|1|0|vtprealty.in|
|East Pune|PMRDA|Kharadi Annex|3|3|0|0|3|0|vtprealty.in|
|East Pune|PMC|Koregaon Park|1|1|0|0|1|0|rohanbuilders.com|
|East Pune|PMC|Koregaon Park Annexe|2|0|2|0|1|1|99acres.com, kohinoorpune.com|
|East Pune|PMC|Lohegaon|1|1|0|0|0|1|housing.com|
|East Pune|PMC|Magarpatta|2|1|1|0|1|1|infobitwiz.com, mantraproperties.in|
|East Pune|PMC|Mundhwa|5|1|3|1|3|2|99acres.com, mantraproperties.in|
|East Pune|PMRDA|Shewalewadi|2|2|0|0|0|2|housing.com, magicbricks.com|
|East Pune|PMC|Upper Kharadi|3|3|0|0|3|0|gera.in, lodhagroup.com, magicbricks.com|
|East Pune|PMRDA|Upper Kharadi|1|1|0|0|1|0|kohinoorpune.com|
|East Pune|PMC|Viman Nagar|8|5|3|0|2|6|daftar.com, housing.com, panchshil.com, property.jll.co.in|
|East Pune|PMRDA|Wagholi|2|2|0|0|2|0|koltepatil.com, rohanbuilders.com|
|East Pune|PMC|Yerawada|3|0|3|0|3|0|cbre.co.in, mindspaceindia.com, smartworksoffice.com|
|Extended Pune|PMRDA|Chakan|1|0|1|0|1|0|in.esr.com|
|Extended Pune|PMRDA|Ranjangaon|1|0|1|0|0|1|justdial.com|
|Extended Pune|PMRDA|Talegaon|2|2|0|0|2|0|lodhagroup.com, rohanbuilders.com|
|North Pune / PCMC|PCMC|Akurdi|1|0|0|1|0|1|buyindiahomes.com|
|North Pune / PCMC|PCMC|Charholi|1|0|0|1|1|0|housing.com|
|North Pune / PCMC|PCMC|Moshi|1|1|0|0|0|1|housing.com|
|North Pune / PCMC|PCMC|Pimple Nilakh|1|1|0|0|1|0|koltepatil.com|
|North Pune / PCMC|PCMC|Pimpri|1|0|1|0|1|0|godrejnewlaunching.com|
|North Pune / PCMC|PCMC|Ravet|1|1|0|0|1|0|koltepatil.com|
|South Pune|PMC|Kondhwa|1|1|0|0|1|0|koltepatil.com|
|South Pune|PMC|NIBM|1|0|0|1|0|1|realestateindia.com|
|South Pune|PMC|Sinhagad Road|1|1|0|0|1|0|rohanbuilders.com|
|South Pune|PMC|Undri|1|1|0|0|1|0|nyatigroup.com|
|West Pune|PMC|Balewadi|3|2|1|0|3|0|mantraproperties.in, property.jll.co.in, rohanbuilders.com|
|West Pune|PMC|Baner|6|4|2|0|5|1|kohinoorpune.com, lodhagroup.com, nyatigroup.com, propsearchs.com|
|West Pune|PMC|Bavdhan|1|1|0|0|1|0|koltepatil.com|
|West Pune|PMRDA|Hinjewadi|6|2|3|1|5|1|99acres.com, gera.in, godrejproperties.com, koltepatil.com|
|West Pune|PMC|Kothrud|1|1|0|0|1|0|lodhagroup.com|
|West Pune|PMRDA|Mahalunge|2|1|0|1|1|1|propsearchs.com, vtprealty.in|
|West Pune|PMC|Pashan|1|1|0|0|0|1|xproppune.com|
|West Pune|PCMC|Punawale|1|0|1|0|0|1|99acres.com|
|West Pune|PMC|Sus|1|1|0|0|1|0|mantraproperties.in|
|West Pune|PCMC|Tathawade|1|1|0|0|1|0|rohanbuilders.com|
|West Pune|PCMC|Wakad|8|5|2|1|5|3|99acres.com, lodhagroup.com, magicbricks.com, rohanbuilders.com|

## 3. Continuation Manifest for Incremental Expansion

1. **Completed Batches:**
   - **Batch 1 (Pilot — East Pune Core):** Kharadi, Upper Kharadi, Kharadi Annex, Viman Nagar, Mundhwa.
   - **Batch 2 (East Pune Extended):** Kalyani Nagar, Koregaon Park, KP Annexe, Keshav Nagar, Hadapsar, Magarpatta, Amanora, Shewalewadi, Phursungi, Wagholi, Lohegaon, Dhanori, Yerawada, Wadgaon Sheri.
   - **Batch 3 (West Pune):** Baner, Balewadi, Wakad, Hinjewadi Phases 1–3, Mahalunge, Sus, Pashan, Bavdhan, Kothrud, Tathawade, Punawale.
   - **Batch 4 (North Pune / PCMC):** Pimpri, Chinchwad, Akurdi, Ravet, Kiwale, Moshi, Spine Road, Charholi Budruk, Pimple Nilakh.
   - **Batch 5 (South, Central & Extended Pune):** NIBM, Kondhwa, Undri, Sinhagad Road, Shivajinagar, Sadashiv Peth, Talegaon, Somatane, Gahunje, Chakan MIDC, Ranjangaon MIDC.
2. **Next Scheduled Maintenance Batches:**
   - **Batch 6:** Resolve `VERIFICATION_PENDING` MahaRERA sub-phase certificates for 2025–2026 pre-launch towers via manual MahaRERA portal lookup.
   - **Batch 7:** Expand standalone boutique redevelopment projects in Deccan, Prabhat Road, Law College Road, Model Colony, and Camp.
   - **Batch 8:** Expand secondary PMRDA growth corridors (Pirangut, Bhugaon, Bhukum, Uruli Kanchan, Loni Kalbhor).
