# TLC-1 Pune Real Estate Project Master Database

**Target Repository:** `pavanpatil93-dot/Tlc-1`  
**Database Version:** `1.0.0`  
**Last Research & Verification Date:** `2026-11-10`  
**Supported Business Divisions:**
1. **ASCEND COMMERCIAL SOLUTIONS** (`ASCEND` / `BOTH`) — Commercial office towers, Grade-A IT/SEZ parks, business parks, high-street retail, showrooms, industrial/logistics parks, and commercial investment properties.
2. **AUREA LIVING LLP** (`AUREA` / `BOTH`) — Residential apartments, luxury residences, villas, row houses, plotted developments, and integrated residential townships.

## 1. Executive Summary & Verified Record Counts

| Metric | Verified Count | Notes |
| :--- | :---: | :--- |
| **Total Unique Canonical Projects** | **124** | Deduplicated across 6 Pune geographic corridors |
| **Residential Projects (`AUREA`)** | **71** | Apartments, luxury towers, villas, townships, plots |
| **Commercial Projects (`ASCEND`)** | **44** | Grade-A IT parks, office towers, retail, industrial/warehousing |
| **Mixed-Use Projects (`BOTH`)** | **9** | Integrated residential + retail/office developments |
| **Verified Developer Entities** | **36** | Official developer groups & institutional REITs |
| **Explicit MahaRERA Numbers Verified** | **76** | Verified `P521000...`, `PR126000...`, and `PM126000...` registrations |
| **Developer Website Verified Projects** | **78** | Direct verification from official promoter portals |
| **Portal-Corroborated Projects** | **40** | Cross-checked across 99acres, Housing.com, MagicBricks, JLL, CBRE |
| **Sub-Phase RERA Verification Pending** | **26** | Flagged `VERIFICATION_PENDING` (blocked by MahaRERA CAPTCHA) |
| **Duplicate Portal Listings Merged** | **38** | Stored in `project_aliases` to prevent duplicate CRM entries |

## 2. Core Architectural Separation Principle

In strict compliance with the TLC-1 Master Operating Framework:
- **Project Master Level (This Database):** Stores canonical project-level identity, developer linkage, RERA compliance, administrative geography, tower/phase specs, published BHK/office configurations, confirmed amenities, and timestamped portal/developer price observations.
- **Employee Unit Inventory Level (Preserved Separately in TLC-1):** Individual available/sold/leased units (`ACS-OL-####`, `ACS-OS-####`, `ACS-RL-####`, `ACS-RS-####`, `AUR-RS-####`, `AUR-RR-####`, `AUR-PL-####`), direct owner/landlord POC mobile numbers, negotiated quotation sheets, and active client requirement leads remain in their dedicated operational tables linked via `project_id`.

## 3. Package Directory Structure

- `excel/Pune_All_Projects_Master.xlsx` — Master workbook with formula-driven Executive Summary, BarChart visualization, All 124 Projects Master tab, and Locality Coverage Matrix.
- `excel/Pune_Commercial_Projects.xlsx` — Commercial & Mixed-Use projects for Ascend Commercial Solutions (`40` projects + `40` commercial configuration records).
- `excel/Pune_Residential_Projects.xlsx` — Residential & Mixed-Use projects for Aurea Living LLP (`92` projects + `92` residential configuration records).
- `excel/Pune_Developers_Master.xlsx` — Master directory of `36` Pune developers and institutional REITs.
- `excel/Pune_Project_Configurations.xlsx` — Multi-tab workbook containing Residential Configurations, Commercial Configurations, Phases & Towers, and Confirmed Amenities.
- `excel/Pune_RERA_Verification.xlsx` — MahaRERA registration records and verification audit trail.
- `excel/Pune_Project_Price_Observations.xlsx` — Timestamped price observations separating developer advertised, portal advertised, resale asking, and rental asking prices.
- `excel/Pune_Data_Quality_Report.xlsx` — Source attribution registry, deduplication alias log, and locality coverage matrix.
- `json/*.json` — 14 normalized relational JSON tables + `manifest.json` ready for Room/SQLite batch ingestion.
- `docs/` — Complete technical documentation (`README.md`, `SCHEMA.md`, `SOURCE_COVERAGE.md`, `DATA_QUALITY_REPORT.md`, `IMPORT_GUIDE_TLC1.md`).
- `scripts/validate_database.py` — Automated integrity validator verifying JSON syntax, primary key uniqueness, foreign key integrity, and required fields.
