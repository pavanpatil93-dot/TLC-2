# TLC-1 Pune Real Estate Master Database — Relational & Room Schema (`SCHEMA.md`)

This schema is designed for **Android Room (SQLite)** inside `pavanpatil93-dot/Tlc-1`. Every table uses deterministic string primary keys (`TLC-PRJ-###`, `DEV-###`, `PHS-###-A`, etc.) so incremental updates can execute idempotent `INSERT OR IGNORE` / `@Upsert` operations without breaking foreign keys from employee unit inventory tables.

## 1. Entity-Relationship Overview

- `developers` (`1`) ─── (`N`) `projects` (`developer_id`)
- `projects` (`1`) ─── (`1`) `project_locations` (`project_id`)
- `projects` (`1`) ─── (`N`) `project_phases` (`project_id`)
- `project_phases` (`1`) ─── (`N`) `project_towers` (`phase_id`, `project_id`)
- `projects` (`1`) ─── (`N`) `residential_configurations` (`project_id`, `phase_id`)
- `projects` (`1`) ─── (`N`) `commercial_configurations` (`project_id`, `phase_id`)
- `projects` (`1`) ─── (`1`) `project_amenities` (`project_id`)
- `projects` (`1`) ─── (`N`) `project_aliases` (`project_id`)
- `projects` (`1`) ─── (`N`) `project_rera_registrations` (`project_id`, `phase_id`)
- `projects` (`1`) ─── (`N`) `project_price_observations` (`project_id`, `configuration_id`, `source_id`)
- `projects` (`1`) ─── (`N`) `project_sources` (`project_id`)
- `projects` (`1`) ─── (`1`) `project_verification` (`project_id`)
- `projects` (`1`) ─── (`N`) `project_change_history` (`project_id`, `source_id`)

## 2. SQLite DDL Definitions (Room Compatible)

```sql
CREATE TABLE IF NOT EXISTS developers (
    developer_id TEXT PRIMARY KEY NOT NULL,
    developer_name TEXT NOT NULL,
    developer_group TEXT NOT NULL,
    specialization TEXT,
    headquarters_city TEXT,
    registered_office_address TEXT,
    website_url TEXT,
    verification_status TEXT NOT NULL,
    data_quality TEXT NOT NULL,
    last_verified_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS projects (
    project_id TEXT PRIMARY KEY NOT NULL,
    official_project_name TEXT NOT NULL,
    alternate_project_name TEXT,
    marketing_name TEXT,
    developer_id TEXT NOT NULL,
    developer_name TEXT NOT NULL,
    business_division TEXT NOT NULL, -- 'ASCEND', 'AUREA', or 'BOTH'
    project_category TEXT NOT NULL,  -- 'Commercial', 'Residential', or 'Mixed-Use'
    project_subcategory TEXT NOT NULL,
    primary_phase TEXT,
    rera_registration_number TEXT NOT NULL,
    rera_registration_status TEXT NOT NULL,
    verification_status TEXT NOT NULL,
    data_quality TEXT NOT NULL,
    zone TEXT NOT NULL,
    administrative_body TEXT NOT NULL,
    locality TEXT NOT NULL,
    sublocality TEXT,
    pin_code TEXT,
    total_land_area_acres REAL,
    total_towers INTEGER,
    total_floors INTEGER,
    total_units INTEGER,
    residential_unit_count INTEGER,
    commercial_unit_count INTEGER,
    launch_date TEXT,
    expected_possession_date TEXT,
    construction_status TEXT NOT NULL,
    oc_cc_status TEXT,
    configurations_summary TEXT,
    area_range_summary TEXT,
    advertised_price_range TEXT,
    official_project_url TEXT,
    source_portal_url TEXT,
    last_verified_date TEXT NOT NULL,
    FOREIGN KEY(developer_id) REFERENCES developers(developer_id) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_projects_locality ON projects(locality);
CREATE INDEX IF NOT EXISTS idx_projects_zone ON projects(zone);
CREATE INDEX IF NOT EXISTS idx_projects_category ON projects(project_category);
CREATE INDEX IF NOT EXISTS idx_projects_division ON projects(business_division);
CREATE INDEX IF NOT EXISTS idx_projects_developer ON projects(developer_id);
CREATE INDEX IF NOT EXISTS idx_projects_rera ON projects(rera_registration_number);

CREATE TABLE IF NOT EXISTS project_locations (
    location_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    country TEXT NOT NULL,
    state TEXT NOT NULL,
    city TEXT NOT NULL,
    zone TEXT NOT NULL,
    administrative_area TEXT NOT NULL,
    locality TEXT NOT NULL,
    sublocality TEXT,
    full_address TEXT NOT NULL,
    pin_code TEXT,
    latitude REAL,
    longitude REAL,
    google_maps_url TEXT,
    main_road_access TEXT,
    nearby_landmarks TEXT,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS project_phases (
    phase_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    phase_name TEXT NOT NULL,
    rera_registration_number TEXT,
    launch_date TEXT,
    expected_possession_date TEXT,
    construction_status TEXT,
    total_towers_in_phase INTEGER,
    total_units_in_phase INTEGER,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS project_towers (
    tower_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    phase_id TEXT NOT NULL,
    tower_name TEXT NOT NULL,
    total_floors INTEGER,
    building_structure TEXT,
    lift_specifications TEXT,
    parking_levels TEXT,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
    FOREIGN KEY(phase_id) REFERENCES project_phases(phase_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS residential_configurations (
    res_config_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    phase_id TEXT NOT NULL,
    bhk_type TEXT NOT NULL,
    carpet_area_range TEXT,
    area_basis TEXT NOT NULL,
    starting_advertised_price_inr INTEGER,
    maximum_advertised_price_inr INTEGER,
    price_range_display TEXT,
    price_observation_date TEXT NOT NULL,
    price_source_url TEXT,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS commercial_configurations (
    comm_config_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    phase_id TEXT NOT NULL,
    asset_subclass TEXT NOT NULL,
    unit_configuration TEXT NOT NULL,
    area_range TEXT,
    area_basis TEXT NOT NULL,
    office_condition TEXT,
    floor_to_floor_height TEXT,
    hvac_and_power_backup TEXT,
    parking_allocation TEXT,
    possession_status TEXT,
    asking_price_display TEXT,
    starting_price_inr INTEGER,
    maximum_price_inr INTEGER,
    observation_date TEXT NOT NULL,
    source_url TEXT,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS project_amenities (
    amenity_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    confirmed_amenities TEXT NOT NULL,
    clubhouse INTEGER NOT NULL,
    swimming_pool INTEGER NOT NULL,
    gymnasium INTEGER NOT NULL,
    security_cctv INTEGER NOT NULL,
    power_backup INTEGER NOT NULL,
    fire_safety INTEGER NOT NULL,
    commercial_lobby_highspeed_lifts INTEGER NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS project_aliases (
    alias_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    canonical_name TEXT NOT NULL,
    alias_name TEXT NOT NULL,
    alias_type TEXT NOT NULL,
    source_portal TEXT,
    deduplication_rule TEXT,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_aliases_name ON project_aliases(alias_name);

CREATE TABLE IF NOT EXISTS project_rera_registrations (
    rera_record_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    phase_id TEXT NOT NULL,
    rera_registration_number TEXT NOT NULL,
    registered_project_name TEXT NOT NULL,
    promoter_name TEXT NOT NULL,
    registered_locality TEXT,
    proposed_completion_date TEXT,
    rera_verification_classification TEXT NOT NULL,
    official_rera_portal_url TEXT,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS project_sources (
    source_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    source_name TEXT NOT NULL,
    source_url TEXT NOT NULL,
    retrieved_timestamp TEXT NOT NULL,
    source_category TEXT NOT NULL,
    access_status TEXT NOT NULL,
    reliability_classification TEXT NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS project_price_observations (
    price_observation_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    configuration_id TEXT,
    price_display TEXT,
    min_asking_price_inr INTEGER,
    max_asking_price_inr INTEGER,
    price_per_sqft_inr INTEGER,
    area_basis TEXT NOT NULL,
    currency TEXT NOT NULL,
    observation_date TEXT NOT NULL,
    source_id TEXT NOT NULL,
    source_url TEXT,
    price_type TEXT NOT NULL,
    verification_status TEXT NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
    FOREIGN KEY(source_id) REFERENCES project_sources(source_id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS project_verification (
    verification_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    verification_status TEXT NOT NULL,
    data_quality_band TEXT NOT NULL,
    rera_matched INTEGER NOT NULL,
    developer_site_matched INTEGER NOT NULL,
    multi_portal_corroborated INTEGER NOT NULL,
    conflicting_fields_flagged TEXT,
    auditor_notes TEXT,
    last_verified_date TEXT NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS project_change_history (
    change_id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL,
    change_timestamp TEXT NOT NULL,
    change_type TEXT NOT NULL,
    changed_by TEXT NOT NULL,
    source_id TEXT NOT NULL,
    conflict_resolution_policy TEXT NOT NULL,
    change_summary TEXT NOT NULL,
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);
```
