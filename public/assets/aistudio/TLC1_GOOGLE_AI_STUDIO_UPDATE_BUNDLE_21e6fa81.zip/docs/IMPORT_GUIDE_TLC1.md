# TLC-1 Android Application Integration & Upsert Guide (`IMPORT_GUIDE_TLC1.md`)

**Target Repository:** `pavanpatil93-dot/Tlc-1`

## 1. Non-Destructive Database Integration Architecture

The TLC-1 Android app serves two operational divisions (**Ascend Commercial Solutions** and **Aurea Living LLP**). To ensure that importing or refreshing the **Pune Project Master Database** never overwrites employee-entered data:

1. **Master Directory Tables (Read/Refresh from this Package):**
   - `developers`, `projects`, `project_locations`, `project_phases`, `project_towers`, `residential_configurations`, `commercial_configurations`, `project_amenities`, `project_aliases`, `project_rera_registrations`, `project_price_observations`, `project_sources`, `project_verification`, `project_change_history`.
2. **Operational CRM & Inventory Tables (Preserved Untouched in App DB):**
   - `unit_inventory` (Employee-logged units `ACS-OL-####`, `ACS-OS-####`, `AUR-RS-####`, etc., linked via `project_id` FK)
   - `owner_contacts` (Direct landlord/owner POC details and mobile numbers)
   - `client_requirements` & `crm_followups` (Active buyer/tenant inquiries, site visits, and deal pipelines)
   - `employee_notes` & `media_attachments` (Field inspection notes, floor plan PDFs, and photos)

## 2. Recommended Room Upsert & Conflict Resolution Strategy

When seeding or updating the Room database from `json/*.json`:

```kotlin
@Dao
interface MasterProjectDao {
    @Upsert
    suspend fun upsertDevelopers(developers: List<DeveloperEntity>)

    @Upsert
    suspend fun upsertProjects(projects: List<ProjectEntity>)

    @Upsert
    suspend fun upsertLocations(locations: List<ProjectLocationEntity>)

    @Upsert
    suspend fun upsertPhases(phases: List<ProjectPhaseEntity>)

    @Upsert
    suspend fun upsertTowers(towers: List<ProjectTowerEntity>)

    @Upsert
    suspend fun upsertResidentialConfigs(configs: List<ResidentialConfigEntity>)

    @Upsert
    suspend fun upsertCommercialConfigs(configs: List<CommercialConfigEntity>)

    @Upsert
    suspend fun upsertAmenities(amenities: List<ProjectAmenityEntity>)

    @Upsert
    suspend fun upsertAliases(aliases: List<ProjectAliasEntity>)

    @Upsert
    suspend fun upsertReraRecords(reraRecords: List<ProjectReraEntity>)

    @Upsert
    suspend fun upsertSources(sources: List<ProjectSourceEntity>)

    @Upsert
    suspend fun upsertPriceObservations(prices: List<PriceObservationEntity>)

    @Upsert
    suspend fun upsertVerifications(verifications: List<ProjectVerificationEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertChangeHistory(changes: List<ProjectChangeHistoryEntity>)
}
```

### Trust Hierarchy Rules During Incremental Sync:
1. Never overwrite a record verified as `RERA_VERIFIED` or `DEVELOPER_VERIFIED` with `PORTAL_ONLY` data unless `last_verified_date` is newer and verified by an auditor.
2. When matching incoming portal leads or employee unit entries by name, query `project_aliases.alias_name` (case-insensitive) to resolve alternate names (e.g., *"KP Towers"* -> `TLC-PRJ-014` *"Kohinoor Presidentia"*, *"EON IT Park"* -> `TLC-PRJ-001` *"EON Free Zone Phase 1"*).
3. Filter projects by `business_division IN ('ASCEND', 'BOTH')` for the **Ascend Commercial Solutions** workspace and `business_division IN ('AUREA', 'BOTH')` for the **Aurea Living LLP** workspace.
