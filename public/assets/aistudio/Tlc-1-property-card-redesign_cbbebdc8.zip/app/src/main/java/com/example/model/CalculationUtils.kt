package com.example.model

import java.text.DecimalFormat
import java.util.Locale

object CalculationUtils {

    /**
     * Formats Indian currency into compact format: ₹50k, ₹1.25 Lac, ₹2.50 Cr.
     */
    fun formatIndianCurrency(amount: Double, isMonthly: Boolean = false): String {
        val suffix = if (isMonthly) "/mo" else ""
        if (amount <= 0) return "₹0$suffix"

        val formatted = when {
            amount >= 10_000_000.0 -> { // 1 Crore+
                val cr = amount / 10_000_000.0
                val df = DecimalFormat("#.##")
                "₹${df.format(cr)} Cr"
            }
            amount >= 100_000.0 -> { // 1 Lakh+
                val lac = amount / 100_000.0
                val df = DecimalFormat("#.##")
                "₹${df.format(lac)} Lac"
            }
            amount >= 1_000.0 -> { // 1 Thousand+
                val k = amount / 1_000.0
                val df = DecimalFormat("#.#")
                "₹${df.format(k)}k"
            }
            else -> {
                val df = DecimalFormat("#,##0")
                "₹${df.format(amount)}"
            }
        }
        return "$formatted$suffix"
    }

    /**
     * Formats full Indian currency with commas: ₹1,25,000
     */
    fun formatIndianCurrencyFull(amount: Double): String {
        val df = DecimalFormat("##,##,###")
        return "₹${df.format(amount.toLong())}"
    }

    /**
     * Sale rate per carpet sq.ft = Price / Carpet Sq.Ft
     */
    fun calculateRatePerCarpet(price: Double, carpetSqFt: Double): Double? {
        if (price <= 0 || carpetSqFt <= 0) return null
        return price / carpetSqFt
    }

    /**
     * Sale rate per built-up sq.ft = Price / Built-up Sq.Ft
     */
    fun calculateRatePerBuiltUp(price: Double, builtUpSqFt: Double?): Double? {
        if (builtUpSqFt == null || builtUpSqFt <= 0 || price <= 0) return null
        return price / builtUpSqFt
    }

    /**
     * Rent per carpet sq.ft = Monthly Rent / Carpet Sq.Ft
     */
    fun calculateRentPerCarpet(monthlyRent: Double, carpetSqFt: Double): Double? {
        if (monthlyRent <= 0 || carpetSqFt <= 0) return null
        return monthlyRent / carpetSqFt
    }

    /**
     * Built-up Area = Carpet Area * (1 + Loading% / 100)
     */
    fun calculateBuiltUpFromCarpet(carpetSqFt: Double, loadingPercent: Double): Double {
        if (carpetSqFt <= 0) return 0.0
        return carpetSqFt * (1.0 + (loadingPercent / 100.0))
    }

    /**
     * Carpet-to-built-up loading percentage = ((BuiltUp - Carpet) / Carpet) * 100
     */
    fun calculateLoadingPercentage(carpetSqFt: Double, builtUpSqFt: Double?): Double? {
        if (builtUpSqFt == null || builtUpSqFt <= carpetSqFt || carpetSqFt <= 0) return null
        return ((builtUpSqFt - carpetSqFt) / carpetSqFt) * 100.0
    }

    /**
     * Monthly Base Rent = Rent Rate * Applicable Area
     */
    fun calculateMonthlyRentFromRate(ratePerSqFt: Double, applicableAreaSqFt: Double): Double {
        if (ratePerSqFt <= 0 || applicableAreaSqFt <= 0) return 0.0
        return ratePerSqFt * applicableAreaSqFt
    }

    /**
     * Rent Rate per sq.ft = Monthly Rent / Applicable Area
     */
    fun calculateRentRatePerSqFt(monthlyRent: Double, applicableAreaSqFt: Double): Double? {
        if (monthlyRent <= 0 || applicableAreaSqFt <= 0) return null
        return monthlyRent / applicableAreaSqFt
    }

    /**
     * Deposit Amount = Confirmed Monthly Rent * Deposit Months
     */
    fun calculateDepositAmount(monthlyRent: Double, depositMonths: Double): Double {
        if (monthlyRent <= 0 || depositMonths <= 0) return 0.0
        return monthlyRent * depositMonths
    }

    /**
     * Annual Rent = Monthly Rent * 12
     */
    fun calculateAnnualRent(monthlyRent: Double): Double {
        return monthlyRent * 12.0
    }

    /**
     * Gross Rental Yield (%) = (Annual Rent / Purchase Price) * 100
     */
    fun calculateGrossYield(annualOrMonthlyRent: Double, purchasePrice: Double, isMonthly: Boolean = true): Double? {
        if (purchasePrice <= 0 || annualOrMonthlyRent <= 0) return null
        val annualRent = if (isMonthly) annualOrMonthlyRent * 12.0 else annualOrMonthlyRent
        return (annualRent / purchasePrice) * 100.0
    }

    /**
     * Net ROI (%) = ((Annual Rental Income - Annual Expenses) / Total Investment Cost) * 100
     */
    fun calculateNetRoi(
        monthlyRent: Double,
        monthlyMaintenance: Double = 0.0,
        otherAnnualExpenses: Double = 0.0,
        purchasePrice: Double
    ): Double? {
        if (purchasePrice <= 0 || monthlyRent <= 0) return null
        val netAnnualIncome = (monthlyRent * 12.0) - (monthlyMaintenance * 12.0) - otherAnnualExpenses
        return (netAnnualIncome / purchasePrice) * 100.0
    }

    /**
     * Rent escalation projections (e.g. 5% annual or 15% 3-yearly)
     */
    fun calculateEscalatedRent(currentRent: Double, escalationPercent: Double, periods: Int = 1): Double {
        var rent = currentRent
        repeat(periods) {
            rent += (rent * (escalationPercent / 100.0))
        }
        return rent
    }

    /**
     * Computes data completeness score (0 to 100%) from explicitly defined required fields
     * for Commercial vs. Residential properties.
     * Does not count unavailable optional attributes as automatically complete.
     */
    fun computeCompletenessScore(property: PropertyItem): Int {
        return if (property.isCommercial()) {
            var points = 0
            val totalRequired = 7
            if (property.propertyCode.isNotBlank()) points++
            if (property.projectName.isNotBlank()) points++
            if (property.location.isNotBlank()) points++
            if (property.carpetAreaSqFt > 0.0) points++
            if (property.priceOrRent > 0.0 || (property.rent != null && property.rent > 0.0) || (property.priceSale != null && property.priceSale > 0.0)) points++
            if (property.propertyType.isNotBlank()) points++
            if (!property.ownerContact.isNullOrBlank() || !property.ownerName.isNullOrBlank()) points++
            ((points * 100) / totalRequired).coerceIn(0, 100)
        } else {
            var points = 0
            val totalRequired = 7
            if (property.propertyCode.isNotBlank()) points++
            if (property.projectName.isNotBlank()) points++
            if (property.location.isNotBlank()) points++
            if (!property.bhk.isNullOrBlank()) points++
            if (property.carpetAreaSqFt > 0.0) points++
            if (property.priceOrRent > 0.0 || (property.rent != null && property.rent > 0.0) || (property.priceSale != null && property.priceSale > 0.0)) points++
            if (property.possession.isNotBlank()) points++
            ((points * 100) / totalRequired).coerceIn(0, 100)
        }
    }

    /**
     * Formats sq.ft area with commas (e.g. 3,250) without inventing decimals.
     */
    fun formatAreaNumber(area: Double): String {
        if (area <= 0.0) return "0"
        val df = DecimalFormat("#,###")
        return df.format(area.toLong())
    }
}
