package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppColorScheme = lightColorScheme(
    primary = PremiumTeal,
    onPrimary = Color.White,
    primaryContainer = PremiumTealLight,
    onPrimaryContainer = DeepNavy,
    secondary = DeepNavy,
    onSecondary = Color.White,
    secondaryContainer = PillCategoryBlueBg,
    onSecondaryContainer = PillCategoryBlueText,
    tertiary = PillBrandPurpleText,
    onTertiary = Color.White,
    tertiaryContainer = PillBrandPurpleBg,
    onTertiaryContainer = PillBrandPurpleText,
    background = SoftWhiteBg,
    onBackground = NavyPrimaryText,
    surface = PureWhiteCard,
    onSurface = NavyPrimaryText,
    surfaceVariant = SurfacePlaceholder,
    onSurfaceVariant = SlateSecondaryText,
    outline = CardDividerBorder,
    outlineVariant = Color(0xFFCBD5E1)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        typography = Typography,
        content = content
    )
}
