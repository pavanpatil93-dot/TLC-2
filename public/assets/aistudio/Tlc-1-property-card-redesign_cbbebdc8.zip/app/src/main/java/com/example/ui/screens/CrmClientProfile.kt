package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private data class CrmRequirement(
    val id: String, val segment: String, val purpose: String,
    val description: String, val location: String, val budget: String
)
private data class CrmActivity(
    val id: String, val type: String, val date: String, val notes: String,
    val nextFollowUp: String
)

private fun profileArray(context: Context, leadId: String, key: String): JSONArray =
    runCatching {
        JSONArray(context.getSharedPreferences("crm_profile_v1", Context.MODE_PRIVATE)
            .getString("${leadId}_${key}", "[]") ?: "[]")
    }.getOrDefault(JSONArray())

private fun persistProfileArray(context: Context, leadId: String, key: String, array: JSONArray) {
    context.getSharedPreferences("crm_profile_v1", Context.MODE_PRIVATE).edit()
        .putString("${leadId}_${key}", array.toString()).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrmClientProfile(leadId: String, clientName: String, onClose: () -> Unit) {
    val context = LocalContext.current
    var requirements by remember(leadId) {
        mutableStateOf(loadRequirements(context, leadId))
    }
    var activities by remember(leadId) {
        mutableStateOf(loadActivities(context, leadId))
    }
    var addingRequirement by remember { mutableStateOf(false) }
    var addingActivity by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(clientName) },
        text = {
            Column(Modifier.heightIn(max = 520.dp)) {
                Text("Client profile", style = MaterialTheme.typography.titleMedium)
                Text("Requirements and follow-up history are stored locally on this device.",
                    style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { addingRequirement = true }) { Text("+ Requirement") }
                    OutlinedButton(onClick = { addingActivity = true }) { Text("+ Activity") }
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Text("Requirements (${requirements.size})", style = MaterialTheme.typography.titleSmall) }
                    if (requirements.isEmpty()) item { Text("No additional requirements yet.") }
                    items(requirements, key = { "req_${it.id}" }) { req ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                Text("${req.segment} • ${req.purpose}", style = MaterialTheme.typography.labelLarge)
                                Text(req.description)
                                if (req.location.isNotBlank()) Text("Location: ${req.location}")
                                if (req.budget.isNotBlank()) Text("Budget: ${req.budget}")
                            }
                        }
                    }
                    item { Text("Activity & Follow-ups (${activities.size})", style = MaterialTheme.typography.titleSmall) }
                    if (activities.isEmpty()) item { Text("No activities logged yet.") }
                    items(activities, key = { "act_${it.id}" }) { activity ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                Text("${activity.type} • ${activity.date}", style = MaterialTheme.typography.labelLarge)
                                Text(activity.notes)
                                if (activity.nextFollowUp.isNotBlank())
                                    Text("Next follow-up: ${activity.nextFollowUp}")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )

    if (addingRequirement) {
        RequirementEditor(onDismiss = { addingRequirement = false }) { req ->
            requirements = listOf(req) + requirements
            persistRequirements(context, leadId, requirements)
            addingRequirement = false
        }
    }
    if (addingActivity) {
        ActivityEditor(onDismiss = { addingActivity = false }) { activity ->
            activities = listOf(activity) + activities
            persistActivities(context, leadId, activities)
            addingActivity = false
        }
    }
}

private fun loadRequirements(context: Context, id: String): List<CrmRequirement> =
    runCatching {
        val array = profileArray(context, id, "requirements")
        (0 until array.length()).map { i ->
            val j = array.getJSONObject(i)
            CrmRequirement(j.optString("id"), j.optString("segment"),
                j.optString("purpose"), j.optString("description"),
                j.optString("location"), j.optString("budget"))
        }
    }.getOrDefault(emptyList())

private fun persistRequirements(context: Context, id: String, values: List<CrmRequirement>) {
    val array = JSONArray()
    values.forEach {
        array.put(JSONObject().put("id", it.id).put("segment", it.segment)
            .put("purpose", it.purpose).put("description", it.description)
            .put("location", it.location).put("budget", it.budget))
    }
    persistProfileArray(context, id, "requirements", array)
}

private fun loadActivities(context: Context, id: String): List<CrmActivity> =
    runCatching {
        val array = profileArray(context, id, "activities")
        (0 until array.length()).map { i ->
            val j = array.getJSONObject(i)
            CrmActivity(j.optString("id"), j.optString("type"), j.optString("date"),
                j.optString("notes"), j.optString("nextFollowUp"))
        }
    }.getOrDefault(emptyList())

private fun persistActivities(context: Context, id: String, values: List<CrmActivity>) {
    val array = JSONArray()
    values.forEach {
        array.put(JSONObject().put("id", it.id).put("type", it.type)
            .put("date", it.date).put("notes", it.notes)
            .put("nextFollowUp", it.nextFollowUp))
    }
    persistProfileArray(context, id, "activities", array)
}

@Composable
private fun RequirementEditor(onDismiss: () -> Unit, onSave: (CrmRequirement) -> Unit) {
    var segment by remember { mutableStateOf("Commercial") }
    var purpose by remember { mutableStateOf("Lease") }
    var description by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var budget by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("New requirement") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Commercial", "Residential").forEach {
                        FilterChip(selected = segment == it, onClick = { segment = it }, label = { Text(it) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Lease", "Buy").forEach {
                        FilterChip(selected = purpose == it, onClick = { purpose = it }, label = { Text(it) })
                    }
                }
                OutlinedTextField(description, { description = it }, label = { Text("Property / size / configuration") })
                OutlinedTextField(location, { location = it }, label = { Text("Preferred location") })
                OutlinedTextField(budget, { budget = it }, label = { Text("Budget") })
            }
        },
        confirmButton = {
            TextButton(enabled = description.isNotBlank(), onClick = {
                onSave(CrmRequirement(UUID.randomUUID().toString(), segment, purpose,
                    description.trim(), location.trim(), budget.trim()))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun ActivityEditor(onDismiss: () -> Unit, onSave: (CrmActivity) -> Unit) {
    var type by remember { mutableStateOf("Call") }
    var date by remember { mutableStateOf(java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())) }
    var notes by remember { mutableStateOf("") }
    var next by remember { mutableStateOf("") }
    val validDate = isValidCrmDate(date)
    val validNext = next.isBlank() || isValidCrmDate(next)
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Log activity") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("Call", "Visit", "Note").forEach {
                        FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it) })
                    }
                }
                OutlinedTextField(date, { date = it }, label = { Text("Activity date YYYY-MM-DD") },
                    isError = !validDate, singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("Outcome / notes") })
                OutlinedTextField(next, { next = it }, label = { Text("Next follow-up YYYY-MM-DD") },
                    isError = !validNext, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = notes.isNotBlank() && validDate && validNext, onClick = {
                onSave(CrmActivity(UUID.randomUUID().toString(), type, date, notes.trim(), next))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun isValidCrmDate(value: String): Boolean {
    if (!value.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return false
    return runCatching {
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).apply { isLenient = false }.parse(value) != null
    }.getOrDefault(false)
}
