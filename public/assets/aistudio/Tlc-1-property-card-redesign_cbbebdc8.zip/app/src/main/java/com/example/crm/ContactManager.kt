package com.example.crm

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PropertyItem
import org.json.JSONArray

object ContactUtils {

    fun normalizePhoneNumber(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val digits = raw.filter { it.isDigit() }
        return when {
            digits.length == 12 && digits.startsWith("91") -> digits.substring(2)
            digits.length == 11 && digits.startsWith("0") -> digits.substring(1)
            digits.length > 10 -> digits.takeLast(10)
            else -> digits
        }
    }

    fun formatDisplayPhone(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val clean = normalizePhoneNumber(raw)
        return if (clean.length == 10) {
            "${clean.substring(0, 5)} ${clean.substring(5)}"
        } else raw.trim()
    }

    fun extractContactFromUri(context: Context, contactUri: Uri): Pair<String, String>? {
        return try {
            val cursor = context.contentResolver.query(
                contactUri,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                null
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    val name = if (nameIdx >= 0) it.getString(nameIdx).orEmpty() else ""
                    val number = if (numIdx >= 0) it.getString(numIdx).orEmpty() else ""
                    Pair(name.trim(), normalizePhoneNumber(number))
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }
}

data class ContactMatch(
    val role: String,
    val name: String,
    val phone: String,
    val detail: String
)

fun findDuplicateContacts(
    context: Context,
    phoneInput: String?,
    allProperties: List<PropertyItem> = emptyList()
): List<ContactMatch> {
    val clean = ContactUtils.normalizePhoneNumber(phoneInput)
    if (clean.length < 7) return emptyList()

    val results = mutableListOf<ContactMatch>()

    // 1. Check CRM leads
    runCatching {
        val raw = context.getSharedPreferences("crm_development_v1", Context.MODE_PRIVATE)
            .getString("leads", "[]") ?: "[]"
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            val leadPhone = ContactUtils.normalizePhoneNumber(item.optString("phone"))
            if (leadPhone == clean && clean != "0000000000") {
                results.add(
                    ContactMatch(
                        role = "Client Lead",
                        name = item.optString("name", "Unnamed Client"),
                        phone = item.optString("phone"),
                        detail = "${item.optString("segment")} • ${item.optString("status")} • ${item.optString("requirement")}"
                    )
                )
            }
        }
    }

    // 2. Check Property Owners
    for (prop in allProperties) {
        val ownerPhone = ContactUtils.normalizePhoneNumber(prop.ownerContact)
        if (ownerPhone == clean && clean.isNotBlank() && clean != "0000000000") {
            results.add(
                ContactMatch(
                    role = "Property Owner",
                    name = prop.ownerName.orEmpty().ifBlank { "Owner" },
                    phone = prop.ownerContact.orEmpty(),
                    detail = "Property ${prop.propertyCode} (${prop.projectName})"
                )
            )
        }
    }

    return results.distinctBy { "${it.role}_${it.name}_${it.phone}" }
}

@Composable
fun ReusableContactPickerField(
    name: String,
    onNameChange: (String) -> Unit,
    phone: String,
    onPhoneChange: (String) -> Unit,
    labelPrefix: String = "Contact",
    allProperties: List<PropertyItem> = emptyList(),
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val duplicates = remember(phone, allProperties) {
        findDuplicateContacts(context, phone, allProperties)
    }

    val contactPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = result.data?.data
            if (uri != null) {
                ContactUtils.extractContactFromUri(context, uri)?.let { (pickedName, pickedPhone) ->
                    if (pickedName.isNotBlank() && name.isBlank()) {
                        onNameChange(pickedName)
                    }
                    if (pickedPhone.isNotBlank()) {
                        onPhoneChange(pickedPhone)
                    }
                }
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$labelPrefix Information",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            TextButton(
                onClick = {
                    val pickIntent = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
                    contactPickerLauncher.launch(pickIntent)
                },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContactPhone,
                    contentDescription = "Pick from device contacts",
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.width(4.dp))
                Text("Pick from Contacts", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            }
        }

        OutlinedTextField(
            value = name,
            onValueChange = onNameChange,
            label = { Text("$labelPrefix Name *") },
            placeholder = { Text("Full name / Company") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = phone,
            onValueChange = onPhoneChange,
            label = { Text("$labelPrefix Mobile Number *") },
            placeholder = { Text("10-digit mobile number") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth()
        )

        if (duplicates.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFFEF2F2))
                    .border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Duplicate warning",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "Existing Contact Found (${duplicates.size}):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color(0xFF991B1B)
                        )
                    }
                    duplicates.take(2).forEach { match ->
                        Text(
                            text = "• ${match.name} (${match.role}) — ${match.detail}",
                            fontSize = 10.5.sp,
                            color = Color(0xFF7F1D1D),
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}
