package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.crm.*
import com.example.model.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

enum class OpportunityCategory {
    CLIENT, OWNER_DEVELOPER, BROKER_PARTNER
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrmCallsScreen(
    inventory: List<PropertyItem> = emptyList(),
    onAddPropertyToInventory: ((PropertyItem) -> Unit)? = null,
    onNavigateToClients: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var calls by remember { mutableStateOf(CrmCallManager.readCalls(context)) }
    var selectedFilter by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    var callForOpportunity by remember { mutableStateOf<CrmCallRecord?>(null) }
    var showQuickIntakeDialog by remember { mutableStateOf(false) }
    var showActivitiesDialog by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val deviceCalls = CrmCallManager.safeReadDeviceCallLogs(context)
            if (deviceCalls.isNotEmpty()) {
                val existingIds = calls.map { it.id }.toSet()
                val newOnes = deviceCalls.filterNot { it.id in existingIds }
                calls = newOnes + calls
                CrmCallManager.saveCalls(context, calls)
                Toast.makeText(context, "Synced ${newOnes.size} recent calls from device", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "No recent calls found in call log", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(
                context,
                "Device call log access denied. Use manual Quick Call intake anytime.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    val unlinkedCount = remember(calls) { calls.count { !it.isLinked } }
    val today = remember {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.timeInMillis
    }
    val todayCallsCount = remember(calls) { calls.count { it.timestamp >= today } }
    val convertedCount = remember(calls) { calls.count { it.isLinked } }

    val filteredCalls = remember(calls, selectedFilter, searchQuery) {
        calls.filter { call ->
            val matchesFilter = when (selectedFilter) {
                "Unlinked" -> !call.isLinked
                "Incoming" -> call.callType == CallType.INCOMING
                "Outgoing" -> call.callType == CallType.OUTGOING
                "Missed" -> call.callType == CallType.MISSED
                "Converted" -> call.isLinked
                else -> true
            }
            val matchesSearch = searchQuery.isBlank() ||
                call.callerName.contains(searchQuery, ignoreCase = true) ||
                call.phoneNumber.contains(searchQuery, ignoreCase = true) ||
                call.notes.contains(searchQuery, ignoreCase = true)

            matchesFilter && matchesSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandCharcoalDark)
            .padding(14.dp)
    ) {
        // Screen Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Call Intelligence",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )
                Text(
                    text = "Incoming, outgoing, missed and unlinked enquiries",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryDark
                )
            }

            IconButton(onClick = { showActivitiesDialog = true }) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = "Activity logs",
                    tint = AscendGold
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // Metrics Grid (4 compact cards)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CallMetricCard(
                title = "Total",
                value = "${calls.size}",
                modifier = Modifier.weight(1f)
            )
            CallMetricCard(
                title = "Unlinked",
                value = "$unlinkedCount",
                highlight = unlinkedCount > 0,
                modifier = Modifier.weight(1f)
            )
            CallMetricCard(
                title = "Today",
                value = "$todayCallsCount",
                modifier = Modifier.weight(1f)
            )
            CallMetricCard(
                title = "Converted",
                value = "$convertedCount",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(12.dp))

        // Action Buttons Row: Quick Log + Device Sync + Demo Data
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { showQuickIntakeDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f).height(38.dp)
            ) {
                Icon(Icons.Default.PhoneCallback, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Log Call", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    val hasPerm = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.READ_CALL_LOG
                    ) == PackageManager.PERMISSION_GRANTED
                    if (hasPerm) {
                        val deviceCalls = CrmCallManager.safeReadDeviceCallLogs(context)
                        val existingIds = calls.map { it.id }.toSet()
                        val newOnes = deviceCalls.filterNot { it.id in existingIds }
                        calls = newOnes + calls
                        CrmCallManager.saveCalls(context, calls)
                        Toast.makeText(context, "Loaded ${newOnes.size} recent calls", Toast.LENGTH_SHORT).show()
                    } else {
                        permissionLauncher.launch(Manifest.permission.READ_CALL_LOG)
                    }
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(38.dp)
            ) {
                Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Sync Device", fontSize = 12.sp)
            }

            if (calls.none { it.id.startsWith("demo_call_") }) {
                TextButton(
                    onClick = {
                        val demo = CrmCallManager.getDemoCalls()
                        val existingIds = calls.map { it.id }.toSet()
                        calls = demo.filterNot { it.id in existingIds } + calls
                        CrmCallManager.saveCalls(context, calls)
                    },
                    modifier = Modifier.height(38.dp)
                ) {
                    Text("+ Demo", fontSize = 11.sp, color = AscendGold)
                }
            } else {
                TextButton(
                    onClick = {
                        calls = calls.filterNot { it.id.startsWith("demo_call_") }
                        CrmCallManager.saveCalls(context, calls)
                    },
                    modifier = Modifier.height(38.dp)
                ) {
                    Text("- Demo", fontSize = 11.sp, color = TextSecondaryDark)
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by caller, mobile or notes...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().height(50.dp)
        )

        Spacer(Modifier.height(8.dp))

        // Filter Chips
        androidx.compose.foundation.lazy.LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val filterOptions = listOf(
                "All" to "${calls.size}",
                "Unlinked" to "$unlinkedCount",
                "Missed" to "${calls.count { it.callType == CallType.MISSED }}",
                "Incoming" to "${calls.count { it.callType == CallType.INCOMING }}",
                "Outgoing" to "${calls.count { it.callType == CallType.OUTGOING }}",
                "Converted" to "$convertedCount"
            )
            items(filterOptions) { (label, count) ->
                FilterChip(
                    selected = selectedFilter == label,
                    onClick = { selectedFilter = label },
                    label = { Text("$label ($count)") }
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // Call Records List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredCalls, key = { it.id }) { call ->
                CallRecordCard(
                    call = call,
                    onCreateOpportunity = { callForOpportunity = call }
                )
            }

            if (filteredCalls.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.PhoneMissed,
                                contentDescription = null,
                                tint = TextSecondaryDark,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "No calls found for '$selectedFilter'",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = "Tap 'Log Call' or '+ Demo' to add enquiry records.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryDark
                            )
                        }
                    }
                }
            }
        }
    }

    if (showQuickIntakeDialog) {
        QuickCallIntakeDialog(
            onDismiss = { showQuickIntakeDialog = false },
            onSaveCall = { newCall ->
                calls = listOf(newCall) + calls
                CrmCallManager.saveCalls(context, calls)
                CrmCallManager.logActivity(
                    context = context,
                    entityId = newCall.id,
                    type = "Call Logged",
                    summary = "${newCall.callType.label} Call logged with ${newCall.callerName}",
                    details = "Phone: ${newCall.phoneNumber} • ${newCall.notes}"
                )
                showQuickIntakeDialog = false
            }
        )
    }

    callForOpportunity?.let { call ->
        NewOpportunityDialog(
            call = call,
            allProperties = inventory,
            onDismiss = { callForOpportunity = null },
            onOpportunityCreated = { oppType, oppTitle, oppId ->
                CrmCallManager.linkCallToOpportunity(
                    context = context,
                    callId = call.id,
                    oppType = oppType,
                    oppTitle = oppTitle,
                    oppId = oppId
                )
                calls = CrmCallManager.readCalls(context)
                callForOpportunity = null
                Toast.makeText(context, "Opportunity Created: $oppTitle", Toast.LENGTH_SHORT).show()
            },
            onAddPropertyToInventory = onAddPropertyToInventory
        )
    }

    if (showActivitiesDialog) {
        ActivityHistoryDialog(
            onDismiss = { showActivitiesDialog = false }
        )
    }
}

@Composable
private fun CallMetricCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    Surface(
        modifier = modifier.height(64.dp),
        shape = RoundedCornerShape(10.dp),
        color = if (highlight) Color(0xFFFEF2F2) else BrandCharcoalSurface,
        border = androidx.compose.foundation.BorderStroke(
            0.8.dp,
            if (highlight) Color(0xFFFCA5A5) else BrandCharcoalBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                fontSize = 11.sp,
                color = if (highlight) Color(0xFFDC2626) else TextSecondaryDark
            )
            Text(
                text = value,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = if (highlight) Color(0xFFB91C1C) else TextPrimaryDark
            )
        }
    }
}

@Composable
private fun CallRecordCard(
    call: CrmCallRecord,
    onCreateOpportunity: () -> Unit
) {
    val context = LocalContext.current
    val (typeIcon, typeColor) = when (call.callType) {
        CallType.INCOMING -> Icons.Default.CallReceived to Color(0xFF10B981)
        CallType.OUTGOING -> Icons.Default.CallMade to Color(0xFF3B82F6)
        CallType.MISSED -> Icons.Default.CallMissed to Color(0xFFEF4444)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface),
        border = androidx.compose.foundation.BorderStroke(0.8.dp, BrandCharcoalBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(typeColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = typeIcon,
                            contentDescription = call.callType.label,
                            tint = typeColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(Modifier.width(10.dp))

                    Column {
                        Text(
                            text = call.callerName.ifBlank { "Unknown Caller" },
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimaryDark
                        )
                        Text(
                            text = "${ContactUtils.formatDisplayPhone(call.phoneNumber)} • ${CrmCallManager.formatTimestamp(call.timestamp)}",
                            fontSize = 11.sp,
                            color = TextSecondaryDark
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = typeColor.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = if (call.durationSeconds > 0) CrmCallManager.formatDuration(call.durationSeconds) else call.callType.label,
                        color = typeColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            if (call.notes.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = call.notes,
                    fontSize = 12.sp,
                    color = TextPrimaryDark,
                    lineHeight = 16.sp
                )
            }

            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (call.isLinked) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Linked",
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "${call.linkedOpportunityType}: ${call.linkedOpportunityTitle.orEmpty()}",
                            fontSize = 11.sp,
                            color = Color(0xFF047857),
                            fontWeight = FontWeight.Medium
                        )
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFFFFFBEB),
                        border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0xFFFDE68A))
                    ) {
                        Text(
                            text = "Unlinked Enquiry",
                            color = Color(0xFFB45309),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = {
                            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${call.phoneNumber}"))
                            runCatching { context.startActivity(dialIntent) }
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "Call", tint = AscendGold, modifier = Modifier.size(16.dp))
                    }

                    IconButton(
                        onClick = {
                            val clean = ContactUtils.normalizePhoneNumber(call.phoneNumber)
                            val waUrl = "https://wa.me/91$clean"
                            val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse(waUrl))
                            runCatching { context.startActivity(waIntent) }
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = "WhatsApp", tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                    }

                    if (!call.isLinked) {
                        Button(
                            onClick = onCreateOpportunity,
                            colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Create Opp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickCallIntakeDialog(
    onDismiss: () -> Unit,
    onSaveCall: (CrmCallRecord) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var callType by remember { mutableStateOf(CallType.INCOMING) }
    var notes by remember { mutableStateOf("") }
    var durationMinutes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Call") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CallType.values().forEach { t ->
                        FilterChip(
                            selected = callType == t,
                            onClick = { callType = t },
                            label = { Text(t.label) }
                        )
                    }
                }

                ReusableContactPickerField(
                    name = name,
                    onNameChange = { name = it },
                    phone = phone,
                    onPhoneChange = { phone = it },
                    labelPrefix = "Caller"
                )

                OutlinedTextField(
                    value = durationMinutes,
                    onValueChange = { durationMinutes = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Duration (minutes, optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Call Discussion / Enquiry Details *") },
                    placeholder = { Text("e.g. Inquired about 2,000 sq.ft office in Kharadi...") },
                    modifier = Modifier.fillMaxWidth().height(90.dp)
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = phone.isNotBlank() && notes.isNotBlank(),
                onClick = {
                    val durSec = (durationMinutes.toIntOrNull() ?: 0) * 60
                    val record = CrmCallRecord(
                        callerName = name.ifBlank { "Caller ${ContactUtils.formatDisplayPhone(phone)}" },
                        phoneNumber = ContactUtils.normalizePhoneNumber(phone),
                        callType = callType,
                        durationSeconds = durSec,
                        notes = notes.trim(),
                        isLinked = false
                    )
                    onSaveCall(record)
                }
            ) {
                Text("Save Call")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewOpportunityDialog(
    call: CrmCallRecord,
    allProperties: List<PropertyItem> = emptyList(),
    onDismiss: () -> Unit,
    onOpportunityCreated: (oppType: String, oppTitle: String, oppId: String) -> Unit,
    onAddPropertyToInventory: ((PropertyItem) -> Unit)? = null
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf(OpportunityCategory.CLIENT) }

    // Client fields
    var clientName by remember(call) { mutableStateOf(call.callerName) }
    var clientPhone by remember(call) { mutableStateOf(call.phoneNumber) }
    var segment by remember { mutableStateOf("Commercial") }
    var clientRequirement by remember(call) { mutableStateOf(call.notes) }
    var clientLocation by remember { mutableStateOf("Kharadi, Viman Nagar") }
    var clientBudget by remember { mutableStateOf("") }
    var clientStatus by remember { mutableStateOf("Hot") }
    val defaultFollowUp = remember {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }
    var clientFollowUp by remember { mutableStateOf(defaultFollowUp) }

    // Owner fields
    var ownerName by remember(call) { mutableStateOf(call.callerName) }
    var ownerContact by remember(call) { mutableStateOf(call.phoneNumber) }
    var projectName by remember { mutableStateOf("") }
    var propertyLocation by remember { mutableStateOf("Kharadi") }
    var unitNumber by remember { mutableStateOf("") }
    var propertyTab by remember { mutableStateOf(InventoryTab.OFF_LEASE) }
    var carpetArea by remember { mutableStateOf("1200") }
    var priceRent by remember { mutableStateOf("") }
    var ownerRemarks by remember(call) { mutableStateOf(call.notes) }

    // Broker fields
    var brokerName by remember(call) { mutableStateOf(call.callerName) }
    var brokerPhone by remember(call) { mutableStateOf(call.phoneNumber) }
    var brokerFirm by remember { mutableStateOf("") }
    var brokerActionType by remember { mutableStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Convert Call to Opportunity", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Caller: ${ContactUtils.formatDisplayPhone(call.phoneNumber)}", fontSize = 11.sp, color = TextSecondaryDark)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
            ) {
                TabRow(
                    selectedTabIndex = selectedCategory.ordinal,
                    containerColor = BrandCharcoalSurface,
                    contentColor = AscendGold
                ) {
                    Tab(
                        selected = selectedCategory == OpportunityCategory.CLIENT,
                        onClick = { selectedCategory = OpportunityCategory.CLIENT },
                        text = { Text("Client", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedCategory == OpportunityCategory.OWNER_DEVELOPER,
                        onClick = { selectedCategory = OpportunityCategory.OWNER_DEVELOPER },
                        text = { Text("Owner", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedCategory == OpportunityCategory.BROKER_PARTNER,
                        onClick = { selectedCategory = OpportunityCategory.BROKER_PARTNER },
                        text = { Text("Broker", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    when (selectedCategory) {
                        OpportunityCategory.CLIENT -> {
                            item {
                                ReusableContactPickerField(
                                    name = clientName,
                                    onNameChange = { clientName = it },
                                    phone = clientPhone,
                                    onPhoneChange = { clientPhone = it },
                                    labelPrefix = "Client",
                                    allProperties = allProperties
                                )
                            }
                            item {
                                Text("Business Segment", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("Commercial", "Residential").forEach { seg ->
                                        FilterChip(
                                            selected = segment == seg,
                                            onClick = { segment = seg },
                                            label = { Text(seg) }
                                        )
                                    }
                                }
                            }
                            item {
                                OutlinedTextField(
                                    value = clientRequirement,
                                    onValueChange = { clientRequirement = it },
                                    label = { Text("Requirement Description *") },
                                    placeholder = { Text("e.g. 2,000 sq.ft office for lease") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = clientLocation,
                                    onValueChange = { clientLocation = it },
                                    label = { Text("Preferred Locations") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = clientBudget,
                                    onValueChange = { clientBudget = it },
                                    label = { Text("Budget (e.g. ₹1.2 Lakh/mo or ₹2 Cr)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                Text("Status", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf("New", "Warm", "Hot").forEach { st ->
                                        FilterChip(
                                            selected = clientStatus == st,
                                            onClick = { clientStatus = st },
                                            label = { Text(st) }
                                        )
                                    }
                                }
                            }
                            item {
                                OutlinedTextField(
                                    value = clientFollowUp,
                                    onValueChange = { clientFollowUp = it },
                                    label = { Text("Next Follow-up (YYYY-MM-DD)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        OpportunityCategory.OWNER_DEVELOPER -> {
                            item {
                                ReusableContactPickerField(
                                    name = ownerName,
                                    onNameChange = { ownerName = it },
                                    phone = ownerContact,
                                    onPhoneChange = { ownerContact = it },
                                    labelPrefix = "Owner",
                                    allProperties = allProperties
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = projectName,
                                    onValueChange = { projectName = it },
                                    label = { Text("Project / Building Name *") },
                                    placeholder = { Text("e.g. Gera Imperium, World Trade Center") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = propertyLocation,
                                    onValueChange = { propertyLocation = it },
                                    label = { Text("Location (Micro-market) *") },
                                    placeholder = { Text("e.g. Kharadi, Viman Nagar") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = unitNumber,
                                    onValueChange = { unitNumber = it },
                                    label = { Text("Unit / Office Number") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                Text("Inventory Category", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf(
                                        InventoryTab.OFF_LEASE,
                                        InventoryTab.SHOP_LEASE,
                                        InventoryTab.OFF_OUT,
                                        InventoryTab.RESI_RESALE
                                    ).forEach { t ->
                                        FilterChip(
                                            selected = propertyTab == t,
                                            onClick = { propertyTab = t },
                                            label = { Text(t.code, fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = carpetArea,
                                        onValueChange = { carpetArea = it },
                                        label = { Text("Carpet Sq.Ft") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = priceRent,
                                        onValueChange = { priceRent = it },
                                        label = { Text("Rent / Price ₹") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                            item {
                                OutlinedTextField(
                                    value = ownerRemarks,
                                    onValueChange = { ownerRemarks = it },
                                    label = { Text("Owner Remarks / Notes") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        OpportunityCategory.BROKER_PARTNER -> {
                            item {
                                ReusableContactPickerField(
                                    name = brokerName,
                                    onNameChange = { brokerName = it },
                                    phone = brokerPhone,
                                    onPhoneChange = { brokerPhone = it },
                                    labelPrefix = "Broker",
                                    allProperties = allProperties
                                )
                            }
                            item {
                                OutlinedTextField(
                                    value = brokerFirm,
                                    onValueChange = { brokerFirm = it },
                                    label = { Text("Firm / Real Estate Agency") },
                                    placeholder = { Text("e.g. Pune Prime Properties") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                Text("Broker Enquiry Type", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FilterChip(
                                        selected = brokerActionType == 0,
                                        onClick = { brokerActionType = 0 },
                                        label = { Text("Listing Property") }
                                    )
                                    FilterChip(
                                        selected = brokerActionType == 1,
                                        onClick = { brokerActionType = 1 },
                                        label = { Text("Client Enquiry") }
                                    )
                                }
                            }
                            if (brokerActionType == 0) {
                                item {
                                    OutlinedTextField(
                                        value = projectName,
                                        onValueChange = { projectName = it },
                                        label = { Text("Property / Project Name *") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                item {
                                    OutlinedTextField(
                                        value = propertyLocation,
                                        onValueChange = { propertyLocation = it },
                                        label = { Text("Location *") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                item {
                                    OutlinedTextField(
                                        value = priceRent,
                                        onValueChange = { priceRent = it },
                                        label = { Text("Rent / Price ₹") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            } else {
                                item {
                                    OutlinedTextField(
                                        value = clientRequirement,
                                        onValueChange = { clientRequirement = it },
                                        label = { Text("Broker's Client Requirement *") },
                                        placeholder = { Text("e.g. Client needs 3,000 sq.ft office in Viman Nagar") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                item {
                                    OutlinedTextField(
                                        value = clientBudget,
                                        onValueChange = { clientBudget = it },
                                        label = { Text("Client Budget") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    when (selectedCategory) {
                        OpportunityCategory.CLIENT -> {
                            val leadId = UUID.randomUUID().toString()
                            val newLead = org.json.JSONObject().apply {
                                put("id", leadId)
                                put("name", clientName.trim())
                                put("phone", ContactUtils.normalizePhoneNumber(clientPhone))
                                put("segment", segment)
                                put("requirement", clientRequirement.trim())
                                put("location", clientLocation.trim())
                                put("budget", clientBudget.trim())
                                put("status", clientStatus)
                                put("nextFollowUp", clientFollowUp.trim())
                                put("notes", "Converted from Call: ${call.notes}")
                                put("assignedTo", "")
                            }
                            val existingLeads = runCatching {
                                org.json.JSONArray(
                                    context.getSharedPreferences("crm_development_v1", Context.MODE_PRIVATE)
                                        .getString("leads", "[]") ?: "[]"
                                )
                            }.getOrDefault(org.json.JSONArray())
                            existingLeads.put(newLead)
                            context.getSharedPreferences("crm_development_v1", Context.MODE_PRIVATE)
                                .edit()
                                .putString("leads", existingLeads.toString())
                                .apply()

                            onOpportunityCreated("Client", clientName.trim(), leadId)
                        }

                        OpportunityCategory.OWNER_DEVELOPER -> {
                            val newPropCode = "OL-${(100..999).random()}"
                            val todayStr = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date())
                            val newProp = PropertyItem(
                                id = UUID.randomUUID().toString(),
                                tab = propertyTab,
                                propertyCode = newPropCode,
                                date = todayStr,
                                location = propertyLocation.trim(),
                                projectName = projectName.trim(),
                                unitNumber = unitNumber.trim(),
                                carpetAreaSqFt = carpetArea.toDoubleOrNull() ?: 0.0,
                                priceOrRent = priceRent.toDoubleOrNull() ?: 0.0,
                                ownerName = ownerName.trim(),
                                ownerContact = ContactUtils.normalizePhoneNumber(ownerContact),
                                internalRemarks = "Added via Call Intake: ${ownerRemarks.trim()}",
                                status = AvailabilityStatus.AVAILABLE
                            )
                            onAddPropertyToInventory?.invoke(newProp)
                            onOpportunityCreated("Owner", "$projectName ($newPropCode)", newProp.id)
                        }

                        OpportunityCategory.BROKER_PARTNER -> {
                            if (brokerActionType == 0) {
                                val newPropCode = "BP-${(100..999).random()}"
                                val todayStr = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date())
                                val newProp = PropertyItem(
                                    id = UUID.randomUUID().toString(),
                                    tab = InventoryTab.OFF_LEASE,
                                    propertyCode = newPropCode,
                                    date = todayStr,
                                    location = propertyLocation.trim(),
                                    projectName = projectName.trim(),
                                    priceOrRent = priceRent.toDoubleOrNull() ?: 0.0,
                                    ownerName = "${brokerName.trim()} (${brokerFirm.trim()})",
                                    ownerContact = ContactUtils.normalizePhoneNumber(brokerPhone),
                                    sourceInfo = "Broker: ${brokerFirm.ifBlank { brokerName }}",
                                    internalRemarks = "Broker Call Intake: ${call.notes}",
                                    status = AvailabilityStatus.AVAILABLE
                                )
                                onAddPropertyToInventory?.invoke(newProp)
                                onOpportunityCreated("Broker Listing", "$projectName ($newPropCode)", newProp.id)
                            } else {
                                val leadId = UUID.randomUUID().toString()
                                val brokerTag = if (brokerFirm.isNotBlank()) "Broker: $brokerFirm (${brokerName})" else "Broker: $brokerName"
                                val newLead = org.json.JSONObject().apply {
                                    put("id", leadId)
                                    put("name", "Client via $brokerTag")
                                    put("phone", ContactUtils.normalizePhoneNumber(brokerPhone))
                                    put("segment", "Commercial")
                                    put("requirement", clientRequirement.trim())
                                    put("location", "Pune")
                                    put("budget", clientBudget.trim())
                                    put("status", "Hot")
                                    put("nextFollowUp", defaultFollowUp)
                                    put("notes", "Broker CP Lead. Contact: $brokerName ($brokerPhone). Call notes: ${call.notes}")
                                    put("assignedTo", "")
                                }
                                val existingLeads = runCatching {
                                    org.json.JSONArray(
                                        context.getSharedPreferences("crm_development_v1", Context.MODE_PRIVATE)
                                            .getString("leads", "[]") ?: "[]"
                                    )
                                }.getOrDefault(org.json.JSONArray())
                                existingLeads.put(newLead)
                                context.getSharedPreferences("crm_development_v1", Context.MODE_PRIVATE)
                                    .edit()
                                    .putString("leads", existingLeads.toString())
                                    .apply()

                                onOpportunityCreated("Broker Enquiry", brokerTag, leadId)
                            }
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = Color(0xFF0F172A))
            ) {
                Text("Create & Link", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ActivityHistoryDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val activities = remember { CrmCallManager.readActivityLogs(context) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Activity & Opportunity History (${activities.size})", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp)
            ) {
                if (activities.isEmpty()) {
                    Text("No activities recorded yet. When calls are logged or opportunities created, timestamped audit logs appear here.")
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(activities, key = { it.id }) { log ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface),
                                border = androidx.compose.foundation.BorderStroke(0.6.dp, BrandCharcoalBorder)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(log.type, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AscendGold)
                                        Text(CrmCallManager.formatTimestamp(log.timestamp), fontSize = 10.sp, color = TextSecondaryDark)
                                    }
                                    Spacer(Modifier.height(4.dp))
                                    Text(log.summary, fontSize = 12.5.sp, color = TextPrimaryDark, fontWeight = FontWeight.Medium)
                                    if (log.details.isNotBlank()) {
                                        Text(log.details, fontSize = 11.sp, color = TextSecondaryDark)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
