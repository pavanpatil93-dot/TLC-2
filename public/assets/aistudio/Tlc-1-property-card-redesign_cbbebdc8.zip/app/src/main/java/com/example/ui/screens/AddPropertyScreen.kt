package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.ExtractedPropertyDraft
import com.example.ai.GeminiRealEstateService
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AddPropertyScreen(
    onSaveProperty: (PropertyItem) -> Unit,
    onCheckDuplicates: (String, String, String) -> List<PropertyItem>,
    onGenerateCode: (InventoryTab) -> String,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val aiService = remember { GeminiRealEstateService() }

    // 0: Option A (AI Smart Add), 1: Option B (Manual Form)
    var selectedOption by remember { mutableStateOf(0) }

    // --- Option A: AI Smart Add State ---
    var rawInputText by remember { mutableStateOf("") }
    var isExtracting by remember { mutableStateOf(false) }
    var extractedDraft by remember { mutableStateOf<ExtractedPropertyDraft?>(null) }
    var duplicateMatchesAI by remember { mutableStateOf<List<PropertyItem>>(emptyList()) }
    var showEditModeAI by remember { mutableStateOf(false) }

    // Draft edit states
    var editTabAI by remember { mutableStateOf(InventoryTab.OFF_LEASE) }
    var editProjectAI by remember { mutableStateOf("") }
    var editLocationAI by remember { mutableStateOf("") }
    var editUnitAI by remember { mutableStateOf("") }
    var editFloorAI by remember { mutableStateOf("Mid Floor") }
    var editCarpetAI by remember { mutableStateOf("0") }
    var editRentAI by remember { mutableStateOf("") }
    var editSaleAI by remember { mutableStateOf("") }
    var editDepositAI by remember { mutableStateOf("") }
    var editFurnishingAI by remember { mutableStateOf(FurnishingType.SEMI_FURNISHED) }
    var editContactAI by remember { mutableStateOf("") }
    var editPhoneAI by remember { mutableStateOf("") }
    var editRemarksAI by remember { mutableStateOf("") }

    // --- Option B: Manual Form State (24 Master Fields) ---
    var formTab by remember { mutableStateOf(InventoryTab.OFF_LEASE) }
    var formPropertyCode by remember { mutableStateOf(onGenerateCode(InventoryTab.OFF_LEASE)) }
    var formDate by remember { mutableStateOf("13/10/2026") }
    var formLocation by remember { mutableStateOf("") }
    var formProject by remember { mutableStateOf("") }
    var formUnitNo by remember { mutableStateOf("") }
    var formFloor by remember { mutableStateOf("Mid Floor") }
    var formPropertyType by remember { mutableStateOf("Commercial") }
    var formCarpetArea by remember { mutableStateOf("") }
    var formBuiltUpArea by remember { mutableStateOf("") }
    var formPriceSale by remember { mutableStateOf("") }
    var formRent by remember { mutableStateOf("") }
    var formDeposit by remember { mutableStateOf("") }
    var formRoi by remember { mutableStateOf("") }
    var formPossession by remember { mutableStateOf("Immediate") }
    var formFurnishing by remember { mutableStateOf(FurnishingType.FULLY_FURNISHED) }
    var formStatus by remember { mutableStateOf(AvailabilityStatus.AVAILABLE) }
    var formOwnerName by remember { mutableStateOf("") }
    var formOwnerContact by remember { mutableStateOf("") }
    var formSource by remember { mutableStateOf("") }
    var formRemarks by remember { mutableStateOf("") }
    var formListingLink by remember { mutableStateOf("") }
    var formInternalRemark by remember { mutableStateOf("") }

    // Mobile Media & Document Upload States
    var uploadedPhotos by remember { mutableStateOf<List<String>>(emptyList()) }
    var uploadedAttachments by remember { mutableStateOf<List<PropertyAttachment>>(emptyList()) }
    var formVideoUrl by remember { mutableStateOf<String?>(null) }
    var formFloorPlanUrl by remember { mutableStateOf<String?>(null) }

    val sampleWhatsApp = "Office for lease at Gera Imperium Alpha, Kharadi, 922 sq.ft carpet, fully furnished, rent ₹85,000, deposit 6 months, immediate possession, 10 workstations and 2 cabins, contact Rahul 9876543210."

    val sampleShop = "Retail shop for lease at Phoenix Marketcity, Viman Nagar, 1200 sq.ft carpet, 24 ft frontage, ground floor, bare shell, rent ₹1.60 Lac, deposit 6 months, contact Suresh 9822188220."
    val sampleResale = "Luxury 3 BHK resale flat at Kasturi Apostrophe, Wakad, 1420 sqft carpet, fully furnished, price ₹1.75 Cr, 2 covered car parks, contact Amit 9860011223."

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandCharcoalDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .padding(bottom = 80.dp)
            .testTag("add_property_screen")
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "+ ADD NEW PROPERTY",
                    color = TextPrimaryDark,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "MASTER INVENTORY • ASCEND & AUREA",
                    color = AscendGold,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
            }

            IconButton(onClick = onCancel) {
                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = TextSecondaryDark)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Options Switcher: Option A vs Option B
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(BrandCharcoalSurface)
                .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(10.dp))
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selectedOption == 0) AscendGold else Color.Transparent)
                    .clickable { selectedOption = 0 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = if (selectedOption == 0) BrandCharcoalDark else TextSecondaryDark,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Option A — AI Smart Add",
                        color = if (selectedOption == 0) BrandCharcoalDark else TextSecondaryDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selectedOption == 1) AscendGold else Color.Transparent)
                    .clickable { selectedOption = 1 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.EditNote,
                        contentDescription = null,
                        tint = if (selectedOption == 1) BrandCharcoalDark else TextSecondaryDark,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Option B — Manual Form",
                        color = if (selectedOption == 1) BrandCharcoalDark else TextSecondaryDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // =========================================================================
        // OPTION A: AI SMART ADD (TEXT PASTE & PREVIEW)
        // =========================================================================
        if (selectedOption == 0) {
            // Text area for pasting raw property text
            Text(
                text = "Paste WhatsApp / Broker / SMS Property Message:",
                color = TextPrimaryDark,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = rawInputText,
                onValueChange = { rawInputText = it },
                placeholder = {
                    Text(
                        "Paste property message in normal language...\nExample: \"Office for lease at Gera Imperium Alpha, Kharadi, 922 sq.ft carpet, fully furnished, rent ₹85,000, deposit 6 months, immediate possession...\"",
                        color = TextMutedDark,
                        fontSize = 12.sp
                    )
                },
                minLines = 4,
                maxLines = 7,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_raw_input_field"),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = BrandCharcoalSurface,
                    unfocusedContainerColor = BrandCharcoalSurface,
                    focusedBorderColor = AscendGold,
                    unfocusedBorderColor = BrandCharcoalBorder,
                    focusedTextColor = TextPrimaryDark,
                    unfocusedTextColor = TextPrimaryDark
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Sample Prompts Chips
            Text("Sample messages for quick testing:", color = TextMutedDark, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SampleChip("Commercial Office") { rawInputText = sampleWhatsApp }
                SampleChip("Retail Shop") { rawInputText = sampleShop }
                SampleChip("Residential Resale") { rawInputText = sampleResale }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Extract with AI Button
            Button(
                onClick = {
                    if (rawInputText.isBlank()) {
                        Toast.makeText(context, "Please paste a property message first", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    isExtracting = true
                    coroutineScope.launch {
                        try {
                            val draft = aiService.parsePropertyMessage(rawInputText)
                            extractedDraft = draft
                            editTabAI = draft.tab
                            editProjectAI = draft.projectName
                            editLocationAI = draft.location
                            editUnitAI = draft.unitNumber
                            editFloorAI = draft.floor
                            editCarpetAI = draft.carpetAreaSqFt.toInt().toString()
                            editRentAI = draft.rent?.toLong()?.toString() ?: ""
                            editSaleAI = draft.priceSale?.toLong()?.toString() ?: ""
                            editDepositAI = draft.deposit?.toLong()?.toString() ?: ""
                            editFurnishingAI = draft.furnishing
                            editContactAI = draft.contactName ?: ""
                            editPhoneAI = draft.contactPhone ?: ""
                            editRemarksAI = draft.remarks ?: ""

                            // Check duplicates
                            val dupes = onCheckDuplicates("", draft.projectName, draft.unitNumber)
                            duplicateMatchesAI = dupes
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error extracting details: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            isExtracting = false
                        }
                    }
                },
                enabled = !isExtracting && rawInputText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("extract_ai_btn")
            ) {
                if (isExtracting) {
                    CircularProgressIndicator(color = BrandCharcoalDark, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Extracting Master Fields with AI...", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Extract Master Property Details", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }

            // Extracted Draft Preview
            if (extractedDraft != null) {
                Spacer(modifier = Modifier.height(16.dp))
                val draft = extractedDraft!!

                // Duplicate Warning Banner
                if (duplicateMatchesAI.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF331B15))
                            .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "POTENTIAL DUPLICATE DETECTED (${duplicateMatchesAI.size} matching)",
                                    color = Color(0xFFEF4444),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Project ${draft.projectName} with unit ${draft.unitNumber} may already exist.",
                                    color = TextSecondaryDark,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Extracted Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AscendGold.copy(alpha = 0.5f))),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "EXTRACTED PREVIEW (EDITABLE)",
                                color = AscendGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Category: ${editTabAI.code}",
                                color = TextSecondaryDark,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick Spec Grid
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SpecItemBox("Project", editProjectAI.ifBlank { "Not specified" }, Modifier.weight(1f))
                            SpecItemBox("Location", editLocationAI.ifBlank { "Pune" }, Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SpecItemBox("Carpet Area", "$editCarpetAI sq.ft", Modifier.weight(1f))
                            SpecItemBox("Commercials", if (editTabAI.isRental) "Rent: ₹$editRentAI" else "Sale: ₹$editSaleAI", Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SpecItemBox("Furnishing", editFurnishingAI.label, Modifier.weight(1f))
                            SpecItemBox("Contact", "${editContactAI.ifBlank { "Direct" }} • $editPhoneAI", Modifier.weight(1f))
                        }

                        // Edit Toggle
                        Spacer(modifier = Modifier.height(10.dp))
                        TextButton(
                            onClick = { showEditModeAI = !showEditModeAI },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Icon(if (showEditModeAI) Icons.Default.ExpandLess else Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp), tint = AscendGold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (showEditModeAI) "Hide Field Editor" else "Edit Extracted Fields", color = AscendGold, fontSize = 11.sp)
                        }

                        // Expanded Editor Fields
                        AnimatedVisibility(visible = showEditModeAI) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                                OutlinedTextField(
                                    value = editProjectAI,
                                    onValueChange = { editProjectAI = it },
                                    label = { Text("Project / Building") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = editLocationAI,
                                    onValueChange = { editLocationAI = it },
                                    label = { Text("Location") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = editUnitAI,
                                    onValueChange = { editUnitAI = it },
                                    label = { Text("Unit / Shop / Office No") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = editCarpetAI,
                                    onValueChange = { editCarpetAI = it },
                                    label = { Text("Carpet Area (sq.ft)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                if (editTabAI.isRental) {
                                    OutlinedTextField(
                                        value = editRentAI,
                                        onValueChange = { editRentAI = it },
                                        label = { Text("Rent (₹/mo)") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    OutlinedTextField(
                                        value = editDepositAI,
                                        onValueChange = { editDepositAI = it },
                                        label = { Text("Deposit (₹)") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                } else {
                                    OutlinedTextField(
                                        value = editSaleAI,
                                        onValueChange = { editSaleAI = it },
                                        label = { Text("Price / Sale (₹)") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                OutlinedTextField(
                                    value = editContactAI,
                                    onValueChange = { editContactAI = it },
                                    label = { Text("Owner / Contact Person") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = editPhoneAI,
                                    onValueChange = { editPhoneAI = it },
                                    label = { Text("Contact Number") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = editRemarksAI,
                                    onValueChange = { editRemarksAI = it },
                                    label = { Text("Remarks") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Mobile Photos & Document Upload Component
                        com.example.ui.components.PropertyMediaUploadSection(
                            photosList = uploadedPhotos,
                            onPhotosChange = { uploadedPhotos = it },
                            attachments = uploadedAttachments,
                            onAttachmentsChange = { uploadedAttachments = it },
                            videoUrl = formVideoUrl,
                            onVideoUrlChange = { formVideoUrl = it },
                            floorPlanUrl = formFloorPlanUrl,
                            onFloorPlanUrlChange = { formFloorPlanUrl = it }
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // CONFIRM & ADD BUTTON
                        Button(
                            onClick = {
                                val generatedCode = onGenerateCode(editTabAI)
                                val carpetDouble = editCarpetAI.toDoubleOrNull() ?: draft.carpetAreaSqFt
                                val rentDouble = editRentAI.toDoubleOrNull() ?: draft.rent
                                val saleDouble = editSaleAI.toDoubleOrNull() ?: draft.priceSale
                                val primaryPrice = if (editTabAI.isRental) (rentDouble ?: 0.0) else (saleDouble ?: 0.0)

                                val newProperty = PropertyItem(
                                    id = "prop_${System.currentTimeMillis()}",
                                    propertyCode = generatedCode,
                                    date = "13/10/2026",
                                    location = editLocationAI.ifBlank { draft.location },
                                    projectName = editProjectAI.ifBlank { draft.projectName },
                                    unitNumber = editUnitAI.ifBlank { draft.unitNumber },
                                    floor = editFloorAI,
                                    propertyType = draft.propertyType,
                                    tab = editTabAI,
                                    carpetAreaSqFt = carpetDouble,
                                    priceOrRent = primaryPrice,
                                    priceSale = saleDouble,
                                    rent = rentDouble,
                                    deposit = editDepositAI.toDoubleOrNull() ?: draft.deposit,
                                    furnishing = editFurnishingAI,
                                    possession = draft.possession,
                                    status = AvailabilityStatus.AVAILABLE,
                                    ownerName = editContactAI.ifBlank { draft.contactName },
                                    ownerContact = editPhoneAI.ifBlank { draft.contactPhone },
                                    remarks = editRemarksAI.ifBlank { draft.remarks },
                                    images = if (uploadedPhotos.isNotEmpty()) uploadedPhotos else listOf("https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80"),
                                    attachments = uploadedAttachments,
                                    videoUrl = formVideoUrl,
                                    floorPlanUrl = formFloorPlanUrl
                                )
                                onSaveProperty(newProperty)

                                Toast.makeText(context, "Added $generatedCode to Master Inventory!", Toast.LENGTH_SHORT).show()
                                extractedDraft = null
                                rawInputText = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("confirm_and_add_ai_btn")
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Confirm & Add to Inventory", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // =========================================================================
        // OPTION B: MANUAL FORM (24 MASTER FIELDS)
        // =========================================================================
        if (selectedOption == 1) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Section 1: Category & Identification
                FormSectionCard("1. IDENTIFICATION & CATEGORY") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Inventory Tab (Sub Type):", color = TextSecondaryDark, fontSize = 11.sp)
                        // Tab Selector
                        var tabExpanded by remember { mutableStateOf(false) }
                        Box {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(BrandCharcoalSurface)
                                    .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(8.dp))
                                    .clickable { tabExpanded = true }
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(formTab.title, color = AscendGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = AscendGold)
                            }

                            DropdownMenu(
                                expanded = tabExpanded,
                                onDismissRequest = { tabExpanded = false },
                                modifier = Modifier.background(BrandCharcoalSurface)
                            ) {
                                InventoryTab.values().filter { it != InventoryTab.UND_CONST }.forEach { tab ->
                                    DropdownMenuItem(
                                        text = { Text(tab.title, color = TextPrimaryDark, fontSize = 12.sp) },
                                        onClick = {
                                            formTab = tab
                                            formPropertyCode = onGenerateCode(tab)
                                            tabExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = formPropertyCode,
                                onValueChange = { formPropertyCode = it },
                                label = { Text("Property Code") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = { formPropertyCode = onGenerateCode(formTab) },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandCharcoalSurface, contentColor = AscendGold),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .border(1.dp, AscendGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            ) {
                                Text("Generate", fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Section 2: Location & Building
                FormSectionCard("2. PROJECT & LOCATION") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = formProject,
                            onValueChange = { formProject = it },
                            label = { Text("Project / Building *") },
                            placeholder = { Text("e.g. Gera Imperium Alpha, World Trade Center") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("form_project_input")
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = formUnitNo,
                                onValueChange = { formUnitNo = it },
                                label = { Text("Unit / Shop / Office No") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = formFloor,
                                onValueChange = { formFloor = it },
                                label = { Text("Floor") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedTextField(
                            value = formLocation,
                            onValueChange = { formLocation = it },
                            label = { Text("Location (Micro-market) *") },
                            placeholder = { Text("e.g. Kharadi, Baner, Viman Nagar, Pune") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Section 3: Areas & Commercials
                FormSectionCard("3. COMMERCIALS & SPECS") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = formCarpetArea,
                                onValueChange = { formCarpetArea = it },
                                label = { Text("Carpet Area (sq.ft) *") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = formBuiltUpArea,
                                onValueChange = { formBuiltUpArea = it },
                                label = { Text("Built-up Area (sq.ft)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (formTab.isRental) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = formRent,
                                    onValueChange = { formRent = it },
                                    label = { Text("Monthly Rent (₹) *") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = formDeposit,
                                    onValueChange = { formDeposit = it },
                                    label = { Text("Deposit (₹)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        } else {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = formPriceSale,
                                    onValueChange = { formPriceSale = it },
                                    label = { Text("Price / Sale (₹) *") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = formRoi,
                                    onValueChange = { formRoi = it },
                                    label = { Text("ROI %") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = formPossession,
                                onValueChange = { formPossession = it },
                                label = { Text("Possession") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            // Furnishing dropdown
                            var furnExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedTextField(
                                    value = formFurnishing.label,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Furnishing") },
                                    trailingIcon = {
                                        IconButton(onClick = { furnExpanded = true }) {
                                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().clickable { furnExpanded = true }
                                )
                                DropdownMenu(
                                    expanded = furnExpanded,
                                    onDismissRequest = { furnExpanded = false },
                                    modifier = Modifier.background(BrandCharcoalSurface)
                                ) {
                                    FurnishingType.values().forEach { f ->
                                        DropdownMenuItem(
                                            text = { Text(f.label, color = TextPrimaryDark, fontSize = 12.sp) },
                                            onClick = {
                                                formFurnishing = f
                                                furnExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 4: Owner & Internal Contacts
                FormSectionCard("4. CONTACT & INTERNAL DETAILS") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        com.example.crm.ReusableContactPickerField(
                            name = formOwnerName,
                            onNameChange = { formOwnerName = it },
                            phone = formOwnerContact,
                            onPhoneChange = { formOwnerContact = it },
                            labelPrefix = "Owner / Contact"
                        )

                        OutlinedTextField(
                            value = formSource,
                            onValueChange = { formSource = it },
                            label = { Text("Source (Channel Partner / Direct)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = formRemarks,
                            onValueChange = { formRemarks = it },
                            label = { Text("Public Remarks (Features, View, Parking)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = formInternalRemark,
                            onValueChange = { formInternalRemark = it },
                            label = { Text("Internal Staff Remark (Private)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Mobile Media & Document Upload Section
                FormSectionCard("PROPERTY PHOTOS & ATTACHMENTS (MOBILE UPLOAD)") {
                    com.example.ui.components.PropertyMediaUploadSection(
                        photosList = uploadedPhotos,
                        onPhotosChange = { uploadedPhotos = it },
                        attachments = uploadedAttachments,
                        onAttachmentsChange = { uploadedAttachments = it },
                        videoUrl = formVideoUrl,
                        onVideoUrlChange = { formVideoUrl = it },
                        floorPlanUrl = formFloorPlanUrl,
                        onFloorPlanUrlChange = { formFloorPlanUrl = it }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // SAVE BUTTON
                Button(
                    onClick = {
                        if (formProject.isBlank() || formLocation.isBlank() || formCarpetArea.isBlank()) {
                            Toast.makeText(context, "Please fill required fields (Project, Location, Carpet Area)", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val carpetDouble = formCarpetArea.toDoubleOrNull() ?: 1000.0
                        val rentDouble = formRent.toDoubleOrNull()
                        val saleDouble = formPriceSale.toDoubleOrNull()
                        val primaryPrice = if (formTab.isRental) (rentDouble ?: 0.0) else (saleDouble ?: 0.0)

                        val newProp = PropertyItem(
                            id = "prop_${System.currentTimeMillis()}",
                            propertyCode = formPropertyCode.trim().ifBlank { onGenerateCode(formTab) },
                            date = formDate,
                            location = formLocation.trim(),
                            projectName = formProject.trim(),
                            unitNumber = formUnitNo.trim(),
                            floor = formFloor.trim(),
                            propertyType = if (formTab.isCommercial) "Commercial" else "Residential",
                            tab = formTab,
                            carpetAreaSqFt = carpetDouble,
                            builtUpAreaSqFt = formBuiltUpArea.toDoubleOrNull(),
                            priceOrRent = primaryPrice,
                            priceSale = saleDouble,
                            rent = rentDouble,
                            deposit = formDeposit.toDoubleOrNull(),
                            roiPercent = formRoi.toDoubleOrNull(),
                            possession = formPossession.trim(),
                            furnishing = formFurnishing,
                            status = formStatus,
                            ownerName = formOwnerName.trim().ifBlank { null },
                            ownerContact = formOwnerContact.trim().ifBlank { null },
                            sourceInfo = formSource.trim().ifBlank { null },
                            remarks = formRemarks.trim().ifBlank { null },
                            listingLink = formListingLink.trim().ifBlank { null },
                            internalRemarks = formInternalRemark.trim().ifBlank { null },
                            images = if (uploadedPhotos.isNotEmpty()) uploadedPhotos else listOf("https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80"),
                            attachments = uploadedAttachments,
                            videoUrl = formVideoUrl,
                            floorPlanUrl = formFloorPlanUrl
                        )
                        onSaveProperty(newProp)

                        Toast.makeText(context, "Saved ${newProp.propertyCode} to Master Inventory!", Toast.LENGTH_SHORT).show()
                        onCancel()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_manual_form_btn")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save to Master Inventory", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun FormSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BrandCharcoalBorder)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                color = AscendGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun SpecItemBox(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(BrandCharcoalSurface)
            .border(0.5.dp, BrandCharcoalBorder, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(text = label, color = TextMutedDark, fontSize = 9.sp)
            Text(text = value, color = TextPrimaryDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
fun SampleChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(BrandCharcoalSurface)
            .border(0.5.dp, AscendGold.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text = label, color = AscendGold, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}
