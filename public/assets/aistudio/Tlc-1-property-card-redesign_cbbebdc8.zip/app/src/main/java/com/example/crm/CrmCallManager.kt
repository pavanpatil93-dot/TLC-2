package com.example.crm

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CallLog
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class CallType(val label: String) {
    INCOMING("Incoming"),
    OUTGOING("Outgoing"),
    MISSED("Missed");

    companion object {
        fun fromString(value: String): CallType =
            values().firstOrNull { it.name.equals(value, true) || it.label.equals(value, true) } ?: INCOMING
    }
}

data class CrmCallRecord(
    val id: String = UUID.randomUUID().toString(),
    val callerName: String,
    val phoneNumber: String,
    val callType: CallType,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0,
    val notes: String = "",
    val isLinked: Boolean = false,
    val linkedOpportunityType: String? = null, // "Client", "Owner", "Broker"
    val linkedOpportunityTitle: String? = null,
    val linkedOpportunityId: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("callerName", callerName)
        put("phoneNumber", phoneNumber)
        put("callType", callType.name)
        put("timestamp", timestamp)
        put("durationSeconds", durationSeconds)
        put("notes", notes)
        put("isLinked", isLinked)
        put("linkedOpportunityType", linkedOpportunityType.orEmpty())
        put("linkedOpportunityTitle", linkedOpportunityTitle.orEmpty())
        put("linkedOpportunityId", linkedOpportunityId.orEmpty())
    }

    companion object {
        fun fromJson(obj: JSONObject): CrmCallRecord = CrmCallRecord(
            id = obj.optString("id", UUID.randomUUID().toString()),
            callerName = obj.optString("callerName", "Unknown Caller"),
            phoneNumber = obj.optString("phoneNumber", ""),
            callType = CallType.fromString(obj.optString("callType", "INCOMING")),
            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
            durationSeconds = obj.optInt("durationSeconds", 0),
            notes = obj.optString("notes", ""),
            isLinked = obj.optBoolean("isLinked", false),
            linkedOpportunityType = obj.optString("linkedOpportunityType").ifBlank { null },
            linkedOpportunityTitle = obj.optString("linkedOpportunityTitle").ifBlank { null },
            linkedOpportunityId = obj.optString("linkedOpportunityId").ifBlank { null }
        )
    }
}

data class CrmActivityLog(
    val id: String = UUID.randomUUID().toString(),
    val entityId: String,
    val type: String, // "Call Logged", "Opportunity Created", "Client Follow-up", "Property Linked"
    val timestamp: Long = System.currentTimeMillis(),
    val summary: String,
    val details: String = "",
    val author: String = "Staff"
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("entityId", entityId)
        put("type", type)
        put("timestamp", timestamp)
        put("summary", summary)
        put("details", details)
        put("author", author)
    }

    companion object {
        fun fromJson(obj: JSONObject): CrmActivityLog = CrmActivityLog(
            id = obj.optString("id", UUID.randomUUID().toString()),
            entityId = obj.optString("entityId", ""),
            type = obj.optString("type", "General"),
            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
            summary = obj.optString("summary", ""),
            details = obj.optString("details", ""),
            author = obj.optString("author", "Staff")
        )
    }
}

object CrmCallManager {
    private const val PREFS_NAME = "crm_call_intelligence_v1"
    private const val KEY_CALLS = "calls_records"
    private const val KEY_ACTIVITIES = "activity_logs"

    fun readCalls(context: Context): List<CrmCallRecord> {
        return runCatching {
            val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_CALLS, "[]") ?: "[]"
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                CrmCallRecord.fromJson(array.getJSONObject(i))
            }
        }.getOrDefault(emptyList())
    }

    fun saveCalls(context: Context, calls: List<CrmCallRecord>) {
        val array = JSONArray()
        calls.forEach { array.put(it.toJson()) }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_CALLS, array.toString())
            .apply()
    }

    fun addOrUpdateCall(context: Context, call: CrmCallRecord) {
        val current = readCalls(context).toMutableList()
        val index = current.indexOfFirst { it.id == call.id }
        if (index >= 0) {
            current[index] = call
        } else {
            current.add(0, call)
        }
        saveCalls(context, current)
    }

    fun linkCallToOpportunity(
        context: Context,
        callId: String,
        oppType: String,
        oppTitle: String,
        oppId: String
    ) {
        val calls = readCalls(context).map { call ->
            if (call.id == callId) {
                call.copy(
                    isLinked = true,
                    linkedOpportunityType = oppType,
                    linkedOpportunityTitle = oppTitle,
                    linkedOpportunityId = oppId
                )
            } else call
        }
        saveCalls(context, calls)

        // Log activity
        logActivity(
            context = context,
            entityId = oppId,
            type = "Opportunity Created",
            summary = "Created $oppType Opportunity from Call ($oppTitle)",
            details = "Linked to Call ID: $callId"
        )
    }

    fun readActivityLogs(context: Context, entityId: String? = null): List<CrmActivityLog> {
        return runCatching {
            val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_ACTIVITIES, "[]") ?: "[]"
            val array = JSONArray(raw)
            val list = (0 until array.length()).map { i ->
                CrmActivityLog.fromJson(array.getJSONObject(i))
            }
            if (entityId != null) {
                list.filter { it.entityId == entityId }
            } else list
        }.getOrDefault(emptyList())
    }

    fun logActivity(
        context: Context,
        entityId: String,
        type: String,
        summary: String,
        details: String = "",
        author: String = "Staff"
    ) {
        val current = readActivityLogs(context).toMutableList()
        val item = CrmActivityLog(
            id = UUID.randomUUID().toString(),
            entityId = entityId,
            type = type,
            timestamp = System.currentTimeMillis(),
            summary = summary,
            details = details,
            author = author
        )
        current.add(0, item)
        val array = JSONArray()
        current.take(300).forEach { array.put(it.toJson()) }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACTIVITIES, array.toString())
            .apply()
    }

    /**
     * Safely queries device call logs if Android READ_CALL_LOG permission is explicitly granted.
     * Complies with Google Play developer policies:
     * - Returns gracefully if permission is not granted (zero crashes, no forced prompt).
     * - Does NOT transmit call logs outside the local device.
     */
    fun safeReadDeviceCallLogs(context: Context): List<CrmCallRecord> {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CALL_LOG
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) return emptyList()

        return try {
            val projection = arrayOf(
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.NUMBER,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE,
                CallLog.Calls.DURATION
            )
            val cursor = context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                projection,
                null,
                null,
                "${CallLog.Calls.DATE} DESC LIMIT 50"
            )
            val list = mutableListOf<CrmCallRecord>()
            cursor?.use {
                val nameIdx = it.getColumnIndex(CallLog.Calls.CACHED_NAME)
                val numIdx = it.getColumnIndex(CallLog.Calls.NUMBER)
                val typeIdx = it.getColumnIndex(CallLog.Calls.TYPE)
                val dateIdx = it.getColumnIndex(CallLog.Calls.DATE)
                val durIdx = it.getColumnIndex(CallLog.Calls.DURATION)

                while (it.moveToNext()) {
                    val rawName = if (nameIdx >= 0) it.getString(nameIdx).orEmpty() else ""
                    val rawNum = if (numIdx >= 0) it.getString(numIdx).orEmpty() else ""
                    val typeVal = if (typeIdx >= 0) it.getInt(typeIdx) else CallLog.Calls.INCOMING_TYPE
                    val dateVal = if (dateIdx >= 0) it.getLong(dateIdx) else System.currentTimeMillis()
                    val durVal = if (durIdx >= 0) it.getInt(durIdx) else 0

                    val callType = when (typeVal) {
                        CallLog.Calls.OUTGOING_TYPE -> CallType.OUTGOING
                        CallLog.Calls.MISSED_TYPE -> CallType.MISSED
                        else -> CallType.INCOMING
                    }

                    list.add(
                        CrmCallRecord(
                            id = "device_call_${dateVal}_${rawNum.takeLast(4)}",
                            callerName = rawName.ifBlank { "Unknown" },
                            phoneNumber = ContactUtils.normalizePhoneNumber(rawNum),
                            callType = callType,
                            timestamp = dateVal,
                            durationSeconds = durVal,
                            notes = "Imported from device call log",
                            isLinked = false
                        )
                    )
                }
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Demo Call History for real estate workflow verification.
     * Includes unlinked enquiries, missed calls, incoming leads, and broker follow-ups.
     */
    fun getDemoCalls(): List<CrmCallRecord> {
        val now = System.currentTimeMillis()
        val hour = 3600 * 1000L
        return listOf(
            CrmCallRecord(
                id = "demo_call_1",
                callerName = "Rajesh Singhania",
                phoneNumber = "9822011223",
                callType = CallType.MISSED,
                timestamp = now - (15 * 60 * 1000L),
                durationSeconds = 0,
                notes = "Missed call — called back twice earlier. Inquiring for Kharadi office lease.",
                isLinked = false
            ),
            CrmCallRecord(
                id = "demo_call_2",
                callerName = "Dr. Ananya Kulkarni",
                phoneNumber = "9860012345",
                callType = CallType.INCOMING,
                timestamp = now - (2 * hour),
                durationSeconds = 245,
                notes = "Interested in 3 BHK luxury flat in Keshav Nagar / Mundhwa for self-use. Budget ₹1.8 Cr.",
                isLinked = false
            ),
            CrmCallRecord(
                id = "demo_call_3",
                callerName = "Vikram More (Channel Partner)",
                phoneNumber = "9881122334",
                callType = CallType.INCOMING,
                timestamp = now - (5 * hour),
                durationSeconds = 380,
                notes = "Has pre-leased bank branch property for sale in Baner with 7.2% ROI.",
                isLinked = false
            ),
            CrmCallRecord(
                id = "demo_call_4",
                callerName = "Pooja Deshmukh",
                phoneNumber = "9766001122",
                callType = CallType.OUTGOING,
                timestamp = now - (22 * hour),
                durationSeconds = 190,
                notes = "Follow-up regarding site visit scheduled for Saturday at Gera Imperium Alpha.",
                isLinked = true,
                linkedOpportunityType = "Client",
                linkedOpportunityTitle = "Pooja Deshmukh • Office Lease",
                linkedOpportunityId = "demo_opp_client_1"
            ),
            CrmCallRecord(
                id = "demo_call_5",
                callerName = "Unknown Caller",
                phoneNumber = "9923456780",
                callType = CallType.INCOMING,
                timestamp = now - (26 * hour),
                durationSeconds = 85,
                notes = "Called regarding newspaper listing of retail showroom in Viman Nagar.",
                isLinked = false
            ),
            CrmCallRecord(
                id = "demo_call_6",
                callerName = "Amitabh Sharma (Owner)",
                phoneNumber = "9850123456",
                callType = CallType.OUTGOING,
                timestamp = now - (48 * hour),
                durationSeconds = 310,
                notes = "Confirmed rental expectation of ₹1,40,000/mo for 1,600 sq.ft office in Kalyani Nagar.",
                isLinked = true,
                linkedOpportunityType = "Owner",
                linkedOpportunityTitle = "Owner of OL-204 (Marigold IT)",
                linkedOpportunityId = "demo_opp_owner_1"
            )
        )
    }

    fun formatDuration(seconds: Int): String {
        return if (seconds <= 0) "0s"
        else {
            val mins = seconds / 60
            val secs = seconds % 60
            if (mins > 0) "${mins}m ${secs}s" else "${secs}s"
        }
    }

    fun formatTimestamp(epochMillis: Long): String {
        val df = SimpleDateFormat("dd MMM, hh:mm a", Locale.US)
        return df.format(Date(epochMillis))
    }
}
