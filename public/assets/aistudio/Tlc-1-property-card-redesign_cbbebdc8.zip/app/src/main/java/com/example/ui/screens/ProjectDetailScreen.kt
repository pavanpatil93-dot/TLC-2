package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.CalculationUtils
import com.example.model.UnderConstProject
import com.example.ui.theme.*

@Composable
fun ProjectDetailScreen(
    project: UnderConstProject,
    isInternalMode: Boolean,
    onBack: () -> Unit,
    onShareWhatsApp: () -> Unit
) {
    val context = LocalContext.current
    var selectedPhotoIndex by remember { mutableStateOf(0) }

    Scaffold(
        bottomBar = {
            Surface(
                color = BrandCharcoalSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            if (!project.brochureUrl.isNullOrBlank()) {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(project.brochureUrl))
                                context.startActivity(intent)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AscendGold),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Brochure PDF")
                    }

                    Button(
                        onClick = onShareWhatsApp,
                        modifier = Modifier.weight(1.2f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share Project", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BrandCharcoalDark)
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .testTag("project_detail_screen")
        ) {
            // Photo Gallery
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
            ) {
                if (project.photoGallery.isNotEmpty()) {
                    AsyncImage(
                        model = project.photoGallery.getOrElse(selectedPhotoIndex) { project.photoGallery.first() },
                        contentDescription = project.projectName,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.6f))
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(BrandCharcoalDark.copy(alpha = 0.85f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(project.projectCode, color = AscendGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }

            // Project Details Body
            Column(modifier = Modifier.padding(16.dp)) {
                // MahaRERA & Possession Badges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(AscendGold.copy(alpha = 0.2f))
                            .border(0.8.dp, AscendGold, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("MAHARERA: ${project.mahaReraNumber}", color = AscendGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Text("Possession: ${project.possessionYear}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(project.projectName, color = TextPrimaryDark, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("By ${project.builderName} • ${project.location}", color = TextSecondaryDark, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("STARTING PRICE", color = TextMutedDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(
                            CalculationUtils.formatIndianCurrency(project.startingPrice),
                            color = TextPrimaryDark,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text("Calculated from active available configurations", color = AscendGold, fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // All Configurations Table
                Text(
                    text = "ALL MATCHING CONFIGURATIONS (${project.configurations.size})",
                    color = AscendGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    project.configurations.forEach { cfg ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(cfg.configName, color = TextPrimaryDark, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    Text("${cfg.carpetAreaSqFt.toInt()} sq.ft carpet • ${cfg.possessionDate}", color = TextSecondaryDark, fontSize = 12.sp)
                                    val rate = CalculationUtils.calculateRatePerCarpet(cfg.price, cfg.carpetAreaSqFt)
                                    if (rate != null) {
                                        Text("₹${rate.toInt()}/sq.ft (Indicative)", color = TextMutedDark, fontSize = 10.sp)
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(CalculationUtils.formatIndianCurrency(cfg.price), color = AscendGold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text("${cfg.unitsAvailable} Units Left", color = StatusAvailable, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }

                // Project Amenities
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "PROJECT AMENITIES & FEATURES",
                    color = AscendGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandCharcoalSurface)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    project.amenities.forEach { amen ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AscendGold, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(amen, color = TextPrimaryDark, fontSize = 12.sp)
                        }
                    }
                }

                // Internal vs Client Contacts
                Spacer(modifier = Modifier.height(20.dp))
                if (isInternalMode) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1710)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("INTERNAL DEVELOPER MANDATE:", color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Contact: ${project.builderContactPerson ?: "N/A"} (${project.builderPhone ?: "N/A"})", color = TextPrimaryDark, fontSize = 12.sp)
                            Text("Remarks: ${project.internalRemarks ?: "N/A"}", color = TextSecondaryDark, fontSize = 11.sp)
                        }
                    }
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("OFFICIAL AUREA LIVING MANDATE", color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("For private booking and site walkthroughs:\n📞 9766880099 | 9766668099", color = TextPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
