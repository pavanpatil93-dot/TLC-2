package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.location.Location
import java.util.Locale
import com.example.data.FileStorageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.components.PropertyCard
import com.example.ui.theme.*

@Composable
fun PropertyDetailScreen(
    property: PropertyItem,
    allProperties: List<PropertyItem>,
    isInternalMode: Boolean,
    isFavorite: Boolean,
    isInComparison: Boolean,
    onBack: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleCompare: () -> Unit,
    onShareWhatsApp: () -> Unit,
    onVerifyProperty: () -> Unit,
    onStatusChange: (AvailabilityStatus) -> Unit,
    onPropertySelect: (PropertyItem) -> Unit,
    onEditProperty: (() -> Unit)? = null,
    onDeleteProperty: (() -> Unit)? = null,
    onViewOnMap: ((PropertyItem) -> Unit)? = null
) {
    val context = LocalContext.current
    var selectedImageIndex by remember { mutableStateOf(0) }
    var showFullScreenGallery by remember { mutableStateOf(false) }
    var showDeleteConfirmationDialog by remember { mutableStateOf(false) }
    var showVerifyConfirmationDialog by remember { mutableStateOf(false) }
    var showClientSuggestions by remember { mutableStateOf(false) }

    val similarProperties = remember(property, allProperties) {
        allProperties.filter {
            it.id != property.id && (it.tab == property.tab || it.location == property.location)
        }.take(3)
    }

    // Nearby suggestions are calculated only from valid stored coordinates.
    // Do not treat approximate locality names as precise locations.
    val nearbyProperties = remember(property, allProperties) {
        val lat = property.lat
        val lng = property.lng
        if (lat == null || lng == null || lat !in -90.0..90.0 || lng !in -180.0..180.0 ||
            (lat == 0.0 && lng == 0.0)) {
            emptyList()
        } else {
            allProperties.mapNotNull { candidate ->
                val otherLat = candidate.lat
                val otherLng = candidate.lng
                if (candidate.id == property.id || candidate.archiveStatus != ArchiveStatus.ACTIVE ||
                    candidate.status != AvailabilityStatus.AVAILABLE ||
                    otherLat == null || otherLng == null ||
                    otherLat !in -90.0..90.0 || otherLng !in -180.0..180.0 ||
                    (otherLat == 0.0 && otherLng == 0.0)) {
                    null
                } else {
                    val results = FloatArray(1)
                    Location.distanceBetween(lat, lng, otherLat, otherLng, results)
                    val distanceKm = results[0] / 1000f
                    if (distanceKm <= 5f) candidate to distanceKm else null
                }
            }.sortedBy { it.second }.take(5)
        }
    }

    Scaffold(
        bottomBar = {
            Surface(
                color = BrandCharcoalSurface,
                tonalElevation = 10.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(BrandCharcoalCard)
                            .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(10.dp))
                    ) {
                        Icon(
                            if (isFavorite) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Save",
                            tint = if (isFavorite) AscendGold else Color.White
                        )
                    }

                    IconButton(
                        onClick = onToggleCompare,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isInComparison) AscendGold else BrandCharcoalCard)
                            .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(10.dp))
                    ) {
                        Icon(
                            Icons.Default.CompareArrows,
                            contentDescription = "Compare",
                            tint = if (isInComparison) BrandCharcoalDark else Color.White
                        )
                    }

                    if (onEditProperty != null) {
                        OutlinedButton(
                            onClick = onEditProperty,
                            modifier = Modifier.height(44.dp),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AscendGold)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Edit", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    Button(
                        onClick = onShareWhatsApp,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AscendGold,
                            contentColor = BrandCharcoalDark
                        )
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Share WhatsApp", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BrandCharcoalDark)
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .testTag("property_detail_screen")
        ) {
            // Header Image Gallery
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clickable {
                        if (property.images.isNotEmpty()) {
                            showFullScreenGallery = true
                        }
                    }
            ) {
                if (property.images.isNotEmpty()) {
                    AsyncImage(
                        model = property.images.getOrElse(selectedImageIndex) { property.images.first() },
                        contentDescription = property.projectName,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF1E2530)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.Apartment,
                                contentDescription = null,
                                tint = AscendGold.copy(alpha = 0.6f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "ASCEND & AUREA EXCLUSIVE",
                                color = AscendGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "No Photo Uploaded Yet",
                                color = TextMutedDark,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // Top navigation overlay
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.6f))
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (property.images.isNotEmpty()) {
                            IconButton(
                                onClick = { showFullScreenGallery = true },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.6f))
                            ) {
                                Icon(Icons.Default.Fullscreen, contentDescription = "View Fullscreen", tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                        }

                        if (onEditProperty != null) {
                            IconButton(
                                onClick = onEditProperty,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(AscendGold)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Property", tint = BrandCharcoalDark, modifier = Modifier.size(18.dp))
                            }
                        }

                        if (onDeleteProperty != null) {
                            IconButton(
                                onClick = { showDeleteConfirmationDialog = true },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFDC2626))
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Property", tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(BrandCharcoalDark.copy(alpha = 0.85f))
                                .padding(horizontal = 10.dp, vertical = 7.dp)
                        ) {
                            Text(
                                text = property.propertyCode,
                                color = AscendGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // Photo Counter & Cover Badge
                if (property.images.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(10.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.75f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (selectedImageIndex == 0) "COVER PHOTO • ${selectedImageIndex + 1}/${property.images.size}" else "PHOTO ${selectedImageIndex + 1}/${property.images.size}",
                            color = AscendGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Image Thumbnails Selector
                if (property.images.size > 1) {
                    LazyRow(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp)
                    ) {
                        items(property.images.indices.toList()) { idx ->
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(
                                        width = if (selectedImageIndex == idx) 2.dp else 0.8.dp,
                                        color = if (selectedImageIndex == idx) AscendGold else Color.White.copy(alpha = 0.5f),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable { selectedImageIndex = idx }
                            ) {
                                AsyncImage(
                                    model = property.images[idx],
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }
                }
            }

            // Body Specs
            Column(modifier = Modifier.padding(16.dp)) {
                // Tab & Availability Badges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(AscendGold.copy(alpha = 0.15f))
                            .border(0.8.dp, AscendGold, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = property.tab.title.uppercase(),
                            color = AscendGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    val statusColor = when (property.status) {
                        AvailabilityStatus.AVAILABLE -> StatusAvailable
                        AvailabilityStatus.NOT_AVAILABLE -> StatusNotAvailable
                        AvailabilityStatus.NOT_CONFIRMED -> StatusUnconfirmed
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(statusColor)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = property.status.label.uppercase(),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Project & Unit
                Text(
                    text = property.projectName,
                    color = TextPrimaryDark,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${property.unitNumber} • ${property.location}",
                        color = TextSecondaryDark,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )

                    if (onViewOnMap != null) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(BrandCharcoalCard)
                                .border(0.8.dp, AscendGold, RoundedCornerShape(6.dp))
                                .clickable { onViewOnMap(property) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("view_on_map_btn")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Map, contentDescription = "View on Map", tint = AscendGold, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("View on Map", color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Commercials Banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (property.tab.isRental) "MONTHLY RENT" else "OUTRIGHT PRICE",
                                color = TextMutedDark,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = CalculationUtils.formatIndianCurrency(property.priceOrRent, property.tab.isRental),
                                color = TextPrimaryDark,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        if (property.deposit != null) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "SECURITY DEPOSIT",
                                    color = TextMutedDark,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = CalculationUtils.formatIndianCurrency(property.deposit),
                                    color = AscendGold,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Key Specifications Grid
                Text(
                    text = "SPECIFICATIONS",
                    color = AscendGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandCharcoalSurface)
                        .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DetailRow(label = "Carpet Area", value = "${property.carpetAreaSqFt.toInt()} sq.ft")
                    if (property.builtUpAreaSqFt != null) {
                        DetailRow(label = "Built-Up Area", value = "${property.builtUpAreaSqFt.toInt()} sq.ft")
                        val loading = CalculationUtils.calculateLoadingPercentage(property.carpetAreaSqFt, property.builtUpAreaSqFt)
                        if (loading != null) {
                            DetailRow(label = "Loading %", value = String.format("%.1f%% (Indicative)", loading))
                        }
                    }
                    DetailRow(label = "Furnishing", value = property.furnishing.label)
                    DetailRow(label = "Possession", value = property.possession)
                    DetailRow(label = "Parking Allocation", value = property.parking)
                    if (property.workstations != null) {
                        DetailRow(label = "Workstations / Cabins", value = "${property.workstations} Seats / ${property.cabins ?: 0} Cabins")
                    }
                    if (property.bhk != null) {
                        DetailRow(label = "Configuration", value = property.bhk)
                    }
                    if (property.frontageFeet != null) {
                        DetailRow(label = "Shop Frontage", value = "${property.frontageFeet.toInt()} Feet")
                    }
                }

                // Indicative Calculations Section
                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = "FINANCIAL CALCULATIONS (INDICATIVE)",
                    color = AscendGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandCharcoalSurface)
                        .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (property.tab.isRental) {
                        val rentSqft = CalculationUtils.calculateRentPerCarpet(property.priceOrRent, property.carpetAreaSqFt)
                        if (rentSqft != null) {
                            DetailRow(label = "Rent / Carpet sq.ft", value = "₹${rentSqft.toInt()}/sq.ft")
                        }
                        DetailRow(label = "Annualized Rent", value = CalculationUtils.formatIndianCurrency(CalculationUtils.calculateAnnualRent(property.priceOrRent)))
                    } else {
                        val rateSqft = CalculationUtils.calculateRatePerCarpet(property.priceOrRent, property.carpetAreaSqFt)
                        if (rateSqft != null) {
                            DetailRow(label = "Sale Rate / Carpet sq.ft", value = "₹${rateSqft.toInt()}/sq.ft")
                        }
                    }

                    // Pre-Leased Yield
                    if (property.tab == InventoryTab.PRE_LEASED && property.monthlyRentalIncome != null) {
                        val yield = CalculationUtils.calculateGrossYield(property.monthlyRentalIncome, property.priceOrRent, isMonthly = true)
                        if (yield != null) {
                            DetailRow(label = "Gross Rental Yield", value = String.format("%.2f%% per annum", yield))
                        }
                        DetailRow(label = "Current Tenant", value = property.tenantName ?: "Corporate Tenant")
                        if (property.leaseDurationYears != null) {
                            DetailRow(label = "Lease / Lock-In Period", value = "${property.leaseDurationYears} Yrs (${property.lockInPeriodYears ?: 0} Yrs Lock-in)")
                        }
                    }
                }

                // ATTACHED DOCUMENTS, PDF BROCHURES, FLOOR PLANS & VIDEOS
                val hasAnyAttachments = property.attachments.isNotEmpty() ||
                    !property.floorPlanUrl.isNullOrBlank() ||
                    !property.brochureUrl.isNullOrBlank() ||
                    !property.videoUrl.isNullOrBlank()

                if (hasAnyAttachments) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "ATTACHED DOCUMENTS & MEDIA",
                        color = AscendGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(0.8.dp, BrandCharcoalBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (!property.floorPlanUrl.isNullOrBlank()) {
                                AttachmentItemRow(
                                    title = "Architectural Floor Plan",
                                    typeLabel = "Floor Plan",
                                    badgeColor = Color(0xFF3B82F6),
                                    icon = Icons.Default.Architecture,
                                    onOpen = {
                                        val uri = FileStorageManager.getShareableUri(context, property.floorPlanUrl)
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, "image/*")
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        try {
                                            context.startActivity(intent)
                                        } catch (_: Exception) {
                                            try { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                                        }
                                    }
                                )
                            }

                            if (!property.brochureUrl.isNullOrBlank()) {
                                AttachmentItemRow(
                                    title = "Official Project Brochure",
                                    typeLabel = "PDF Brochure",
                                    badgeColor = Color(0xFFEF4444),
                                    icon = Icons.Default.PictureAsPdf,
                                    onOpen = {
                                        val uri = FileStorageManager.getShareableUri(context, property.brochureUrl)
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, "application/pdf")
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        try {
                                            context.startActivity(intent)
                                        } catch (_: Exception) {
                                            try { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                                        }
                                    }
                                )
                            }

                            if (!property.videoUrl.isNullOrBlank()) {
                                AttachmentItemRow(
                                    title = "Property Walkthrough Video",
                                    typeLabel = "Video Attachment",
                                    badgeColor = Color(0xFF8B5CF6),
                                    icon = Icons.Default.PlayCircle,
                                    onOpen = {
                                        val raw = property.videoUrl
                                        val uri = if (raw.startsWith("http://") || raw.startsWith("https://")) {
                                            Uri.parse(raw)
                                        } else {
                                            FileStorageManager.getShareableUri(context, raw)
                                        }
                                        try {
                                            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Cannot open video: ${e.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            }

                            property.attachments.forEach { att ->
                                val (icon, badgeColor) = when (att.type) {
                                    AttachmentType.PDF_BROCHURE -> Pair(Icons.Default.PictureAsPdf, Color(0xFFEF4444))
                                    AttachmentType.FLOOR_PLAN -> Pair(Icons.Default.Architecture, Color(0xFF3B82F6))
                                    AttachmentType.DOCUMENT -> Pair(Icons.Default.Description, Color(0xFFD4AF37))
                                    AttachmentType.VIDEO -> Pair(Icons.Default.PlayCircle, Color(0xFF8B5CF6))
                                }
                                val sizeText = if (att.fileSizeBytes > 0) " • ${FileStorageManager.formatFileSize(att.fileSizeBytes)}" else ""

                                AttachmentItemRow(
                                    title = att.name,
                                    typeLabel = "${att.type.displayName}$sizeText",
                                    badgeColor = badgeColor,
                                    icon = icon,
                                    onOpen = {
                                        val uri = FileStorageManager.getShareableUri(context, att.localUriOrPath)
                                        val mime = att.mimeType.ifBlank { "*/*" }
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, mime)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        try {
                                            context.startActivity(intent)
                                        } catch (_: Exception) {
                                            try {
                                                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                            } catch (_: Exception) {
                                                Toast.makeText(context, "No app available to open this file", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                // Verified Google Maps Link
                Spacer(modifier = Modifier.height(18.dp))
                OutlinedButton(
                    onClick = {
                        val geoUri = if (property.lat != null && property.lng != null) {
                            Uri.parse("geo:${property.lat},${property.lng}?q=${property.lat},${property.lng}(${Uri.encode(property.projectName)})")
                        } else {
                            Uri.parse("geo:0,0?q=${Uri.encode("${property.projectName}, ${property.location}")}")
                        }
                        context.startActivity(Intent(Intent.ACTION_VIEW, geoUri))
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AscendGold),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold.copy(alpha = 0.6f))
                ) {
                    Icon(Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Open Verified Google Maps Location")
                }

                // INTERNAL MANAGEMENT PANEL (Visible only to authorized staff)
                if (isInternalMode) {
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "INTERNAL MANAGEMENT & CONFIDENTIAL OWNER DATA",
                        color = AscendGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1710)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            DetailRow(label = "Owner / Landlord", value = property.ownerName ?: "Direct")
                            DetailRow(label = "Owner Contact", value = property.ownerContact ?: "N/A")
                            DetailRow(label = "Source / Broker", value = "${property.sourceInfo ?: "Direct"} (${property.brokerName ?: "-"})")
                            DetailRow(label = "Verification Status", value = property.verificationStatus.label)
                            DetailRow(label = "Last Verified Date", value = property.lastVerifiedDateClean.ifBlank { property.lastVerificationDate })
                            DetailRow(label = "Verified By", value = property.verifiedBy ?: "System / Team")
                            DetailRow(label = "Internal Remarks", value = property.internalRemarks ?: "None")
                            DetailRow(label = "Spreadsheet Row #", value = "Row ${property.rowNumber}")

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { showVerifyConfirmationDialog = true },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable, contentColor = Color.White)
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Verify Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        val nextStatus = when (property.status) {
                                            AvailabilityStatus.AVAILABLE -> AvailabilityStatus.NOT_AVAILABLE
                                            AvailabilityStatus.NOT_AVAILABLE -> AvailabilityStatus.NOT_CONFIRMED
                                            AvailabilityStatus.NOT_CONFIRMED -> AvailabilityStatus.AVAILABLE
                                        }
                                        onStatusChange(nextStatus)
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandCharcoalCard, contentColor = TextPrimaryDark)
                                ) {
                                    Text("Change Status", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                } else {
                    // CLIENT VIEW CONTACT NOTICE
                    Spacer(modifier = Modifier.height(20.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "OFFICIAL BUSINESS CONTACT",
                                color = AscendGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "For scheduling viewing appointments, floor plans and mandates:",
                                color = TextSecondaryDark,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "📞 9766880099 | 9766668099",
                                color = TextPrimaryDark,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                if (isInternalMode) {
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedButton(
                        onClick = { showClientSuggestions = true },
                        modifier = Modifier.fillMaxWidth().testTag("property_client_suggestions_button")
                    ) {
                        Icon(Icons.Default.Groups, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Suggest Matching CRM Clients")
                    }
                }

                // Verified-coordinate nearby listings, ranked by straight-line distance.
                if (nearbyProperties.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        "NEARBY AVAILABLE PROPERTIES (WITHIN 5 KM)",
                        color = AscendGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Straight-line distance from saved coordinates; confirm site location before sharing.",
                        color = TextSecondaryDark,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    nearbyProperties.forEach { (nearby, distanceKm) ->
                        Surface(
                            onClick = { onPropertySelect(nearby) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            color = BrandCharcoalSurface,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(nearby.projectName.ifBlank { nearby.propertyCode }, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold)
                                    Text("${nearby.location} • ${nearby.propertyCode}", color = TextSecondaryDark, fontSize = 11.sp)
                                }
                                Text(String.format(Locale.US, "%.1f km", distanceKm), color = AscendGold, fontSize = 12.sp)
                                Icon(Icons.Default.ChevronRight, contentDescription = "Open property", tint = AscendGold)
                            }
                        }
                    }
                }

                // Similar Properties
                if (similarProperties.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "SIMILAR INVENTORY",
                        color = AscendGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        similarProperties.forEach { simProp ->
                            PropertyCard(
                                property = simProp,
                                isInternalMode = isInternalMode,
                                isFavorite = false,
                                isInComparison = false,
                                onCardClick = { onPropertySelect(simProp) },
                                onToggleFavorite = {},
                                onToggleCompare = {},
                                onShareWhatsApp = onShareWhatsApp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }

        if (showClientSuggestions && isInternalMode) {
            val suggestions = remember(property) { suggestClientsForProperty(context, property) }
            AlertDialog(
                onDismissRequest = { showClientSuggestions = false },
                title = { Text("Potential Clients (${suggestions.size})") },
                text = {
                    Column {
                        Text(
                            "Preliminary matches based on location, segment, transaction, property type and BHK when supplied. Confirm budget, area and client interest before contacting.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(8.dp))
                        androidx.compose.foundation.lazy.LazyColumn(
                            modifier = Modifier.heightIn(max = 380.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(suggestions) { lead ->
                                Card {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(lead.name, fontWeight = FontWeight.Bold)
                                        Text("${lead.status} • ${lead.requirement}", style = MaterialTheme.typography.bodySmall)
                                        Text("Preferred: ${lead.location}", style = MaterialTheme.typography.bodySmall)
                                        Text(lead.reasons, style = MaterialTheme.typography.labelSmall)
                                        if (lead.phone.isNotBlank() && lead.phone != "0000000000") {
                                            TextButton(onClick = {
                                                val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(lead.phone)))
                                                runCatching { context.startActivity(dial) }
                                            }) { Text("Call client") }
                                        }
                                    }
                                }
                            }
                            if (suggestions.isEmpty()) item {
                                Text("No matching CRM leads found. Add lead requirements and preferred locations to improve suggestions.")
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showClientSuggestions = false }) { Text("Close") } }
            )
        }

        if (showFullScreenGallery && property.images.isNotEmpty()) {
            FullScreenPhotoGalleryDialog(
                images = property.images,
                initialIndex = selectedImageIndex,
                projectName = property.projectName,
                onDismiss = { showFullScreenGallery = false }
            )
        }

        if (showDeleteConfirmationDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirmationDialog = false },
                title = { Text("Delete Listing", color = Color(0xFFEF4444), fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                text = { Text("Are you sure you want to delete property '${property.propertyCode}' (${property.projectName})? This action cannot be undone.", color = TextPrimaryDark, fontSize = 13.sp) },
                confirmButton = {
                    Button(
                        onClick = {
                            showDeleteConfirmationDialog = false
                            onDeleteProperty?.invoke()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White)
                    ) {
                        Text("Delete", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirmationDialog = false }) {
                        Text("Cancel", color = TextSecondaryDark)
                    }
                },
                containerColor = BrandCharcoalCard,
                shape = RoundedCornerShape(12.dp)
            )
        }

        if (showVerifyConfirmationDialog) {
            AlertDialog(
                onDismissRequest = { showVerifyConfirmationDialog = false },
                title = { Text("Confirm Property Verification", color = AscendGold, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                text = { Text("Please confirm that you have checked the property information, specs, rent/price, and current availability status. This will mark the listing as Verified with today's date.", color = TextPrimaryDark, fontSize = 13.sp) },
                confirmButton = {
                    Button(
                        onClick = {
                            showVerifyConfirmationDialog = false
                            onVerifyProperty()
                            Toast.makeText(context, "Property successfully verified!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable, contentColor = Color.White)
                    ) {
                        Text("Confirm & Verify", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showVerifyConfirmationDialog = false }) {
                        Text("Cancel", color = TextSecondaryDark)
                    }
                },
                containerColor = BrandCharcoalCard,
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

@Composable
fun FullScreenPhotoGalleryDialog(
    images: List<String>,
    initialIndex: Int,
    projectName: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var currentIndex by remember { mutableStateOf(initialIndex) }
    val currentImage = images.getOrElse(currentIndex) { images.first() }

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = Color.Black,
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Main Fullscreen Photo
                AsyncImage(
                    model = currentImage,
                    contentDescription = projectName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )

                // Top Header Overlay: Close & Title & Counter
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(Color.Black.copy(alpha = 0.7f))
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = projectName,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (currentIndex == 0) "COVER PHOTO • ${currentIndex + 1} of ${images.size}" else "PHOTO ${currentIndex + 1} of ${images.size}",
                            color = AscendGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            val clip = android.content.ClipData.newPlainText("Photo URL", currentImage)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Photo link copied to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(Color.Black.copy(alpha = 0.7f))
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy Link", tint = AscendGold, modifier = Modifier.size(18.dp))
                    }
                }

                // Previous Photo Button
                if (images.size > 1 && currentIndex > 0) {
                    IconButton(
                        onClick = { currentIndex-- },
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(12.dp)
                            .size(48.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(Color.Black.copy(alpha = 0.75f))
                    ) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Photo", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }

                // Next Photo Button
                if (images.size > 1 && currentIndex < images.size - 1) {
                    IconButton(
                        onClick = { currentIndex++ },
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(12.dp)
                            .size(48.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(Color.Black.copy(alpha = 0.75f))
                    ) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Next Photo", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }

                // Bottom Thumbnails Strip
                if (images.size > 1) {
                    LazyRow(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(horizontal = 20.dp)
                    ) {
                        items(images.indices.toList()) { idx ->
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        width = if (currentIndex == idx) 2.dp else 1.dp,
                                        color = if (currentIndex == idx) AscendGold else Color.White.copy(alpha = 0.4f),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { currentIndex = idx }
                            ) {
                                AsyncImage(
                                    model = images[idx],
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextSecondaryDark, fontSize = 12.sp)
        Text(text = value, color = TextPrimaryDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AttachmentItemRow(
    title: String,
    typeLabel: String,
    badgeColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onOpen: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(BrandCharcoalCard)
            .border(0.8.dp, BrandCharcoalBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onOpen)
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(badgeColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    color = TextPrimaryDark,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                Text(
                    text = typeLabel,
                    color = TextSecondaryDark,
                    fontSize = 10.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))
        Button(
            onClick = onOpen,
            colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
            shape = RoundedCornerShape(6.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
            modifier = Modifier.height(30.dp)
        ) {
            Text("Open", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}
