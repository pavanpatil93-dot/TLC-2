package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.theme.*
import java.util.Locale

private fun dialSavedContact(context: android.content.Context, rawPhone: String?) {
    val cleaned = rawPhone
        ?.split("/", "|", ",")
        ?.firstOrNull()
        ?.replace(Regex("[^0-9+]"), "")
        ?.trim()
        .orEmpty()
    if (cleaned.isNotBlank()) {
        val uri = Uri.parse("tel:$cleaned")
        runCatching { context.startActivity(Intent(Intent.ACTION_DIAL, uri)) }
    }
}

/**
 * Computes the display status label and semantic pill colors according to the TLC-1 specification:
 * - Available: Green
 * - Pending Verification / On Hold: Amber
 * - Rented / Leased / Sold / Not Available: Red
 * - Archived: Neutral Grey
 */
internal fun resolveCardStatusStyle(property: PropertyItem): Triple<String, Color, Color> {
    if (property.archiveStatus == ArchiveStatus.ARCHIVED) {
        return Triple("Archived", StatusArchivedGrey, Color.White)
    }
    return when (property.status) {
        AvailabilityStatus.AVAILABLE -> Triple("Available", StatusAvailable, Color.White)
        AvailabilityStatus.NOT_AVAILABLE -> {
            val label = if (property.tab.isRental) "Rented" else "Sold"
            Triple(label, StatusNotAvailable, Color.White)
        }
        AvailabilityStatus.NOT_CONFIRMED -> Triple("Pending Verification", StatusUnconfirmed, Color.White)
    }
}

/**
 * Resolves the data completion color (Red / Yellow / Green) from the 0..100 completion percentage.
 */
internal fun resolveCompletionBarColor(scorePercent: Int): Color = when {
    scorePercent >= 80 -> CompletionHighGreen
    scorePercent >= 50 -> CompletionMidYellow
    else -> CompletionLowRed
}

@Composable
fun PropertyCard(
    property: PropertyItem,
    isInternalMode: Boolean,
    isFavorite: Boolean,
    isInComparison: Boolean,
    onCardClick: () -> Unit,
    onEditClick: (() -> Unit)? = null,
    onToggleFavorite: () -> Unit,
    onToggleCompare: () -> Unit,
    onShareWhatsApp: () -> Unit,
    onStatusChange: (AvailabilityStatus) -> Unit = {},
    canEdit: Boolean = true
) {
    val context = LocalContext.current
    var showOverflowMenu by remember { mutableStateOf(false) }

    val (statusLabel, statusBgColor, statusTextColor) = remember(property.status, property.archiveStatus, property.tab) {
        resolveCardStatusStyle(property)
    }

    val completionPercent = remember(property) {
        CalculationUtils.computeCompletenessScore(property)
    }
    val completionColor = remember(completionPercent) {
        resolveCompletionBarColor(completionPercent)
    }

    val isCommercial = remember(property) { property.isCommercial() }
    val brandBadgeLabel = if (isCommercial) "Ascend" else "Aurea"
    val transactionLabel = remember(property.tab, property.transactionType) {
        if (property.transactionType.isNotBlank()) property.transactionType
        else if (property.tab == InventoryTab.PRE_LEASED) "Pre-Leased"
        else if (property.tab.isRental) "Lease"
        else "Sale"
    }

    val effectivePrice = remember(property) {
        when {
            property.priceOrRent > 0.0 -> property.priceOrRent
            property.tab.isRental && property.rent != null && property.rent > 0.0 -> property.rent
            !property.tab.isRental && property.priceSale != null && property.priceSale > 0.0 -> property.priceSale
            else -> 0.0
        }
    }

    val rentPerSqFt = remember(property, effectivePrice) {
        if (property.tab.isRental && effectivePrice > 0.0 && property.carpetAreaSqFt > 0.0) {
            CalculationUtils.calculateRentPerCarpet(effectivePrice, property.carpetAreaSqFt)
        } else null
    }

    val saleRateOnBuiltUp = remember(property, effectivePrice) {
        if (!property.tab.isRental && effectivePrice > 0.0 && property.builtUpAreaSqFt != null && property.builtUpAreaSqFt > 0.0) {
            CalculationUtils.calculateRatePerBuiltUp(effectivePrice, property.builtUpAreaSqFt)
        } else null
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = if (isInComparison) 1.5.dp else 1.dp,
                color = if (isInComparison) PremiumTeal else CardDividerBorder,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onCardClick() }
            .semantics { contentDescription = "Property Card ${property.propertyCode}" }
            .testTag("property_card_${property.propertyCode}"),
        colors = CardDefaults.cardColors(containerColor = PureWhiteCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {

            // =========================================================================
            // MAIN HORIZONTAL ROW: Left Compact Image + Right Structured Details
            // Matches TLC-1 Property Card Visualisation Reference
            // =========================================================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                // A. Compact Property Image Thumbnail (104dp x 122dp)
                Box(
                    modifier = Modifier
                        .width(104.dp)
                        .height(122.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfacePlaceholder)
                        .border(0.8.dp, CardDividerBorder, RoundedCornerShape(12.dp))
                        .clickable { onCardClick() }
                        .testTag("property_card_image_${property.propertyCode}"),
                    contentAlignment = Alignment.Center
                ) {
                    if (property.images.isNotEmpty()) {
                        AsyncImage(
                            model = property.images.first(),
                            contentDescription = "${property.projectName} photograph",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        if (property.images.size > 1) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(6.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(DeepNavy.copy(alpha = 0.8f))
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "+${property.images.size - 1}",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        // Neutral Placeholder when no photograph exists (Never fabricate photos)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(6.dp)
                        ) {
                            Icon(
                                imageVector = if (isCommercial) Icons.Default.Business else Icons.Default.Apartment,
                                contentDescription = "No property photograph",
                                tint = SlateSecondaryText,
                                modifier = Modifier.size(30.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "No Photo",
                                color = SlateSecondaryText,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // B & C. Right Column: Status + Star, Code + Project, Location, Metrics, Category/Brand Pills
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    // Row 1: Availability Status Pill (Left) + Favourite Star Icon (Right)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(statusBgColor)
                                .padding(horizontal = 10.dp, vertical = 3.dp)
                                .testTag("status_badge_${property.propertyCode}")
                        ) {
                            Text(
                                text = statusLabel,
                                color = statusTextColor,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(
                            onClick = onToggleFavorite,
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("favorite_btn_${property.propertyCode}")
                        ) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                contentDescription = if (isFavorite) "Remove from favourites" else "Add to favourites",
                                tint = if (isFavorite) Color(0xFFF59E0B) else SlateSecondaryText,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    // Row 2: Existing Legacy Property Code (Bold Navy)
                    if (property.propertyCode.isNotBlank()) {
                        Text(
                            text = property.propertyCode,
                            color = NavyPrimaryText,
                            fontSize = 15.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("code_text_${property.propertyCode}")
                        )
                    }

                    // Row 3: Project / Building Name (when available)
                    if (property.projectName.isNotBlank()) {
                        Text(
                            text = property.projectName,
                            color = NavyPrimaryText,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Row 4: Location / Micro-market with Pin Icon
                    if (property.location.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = SlateSecondaryText,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = property.location,
                                color = SlateSecondaryText,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Row 5: Category-Specific Key Metrics (Commercial vs. Residential)
                    if (isCommercial) {
                        // Commercial Primary Metrics: Carpet / Built-up Area | Rent or Sale Price
                        val metricParts = mutableListOf<String>()
                        if (property.carpetAreaSqFt > 0.0) {
                            val areaStr = if (property.builtUpAreaSqFt != null && property.builtUpAreaSqFt > 0.0) {
                                "${CalculationUtils.formatAreaNumber(property.carpetAreaSqFt)} / ${CalculationUtils.formatAreaNumber(property.builtUpAreaSqFt)} sq.ft"
                            } else {
                                "${CalculationUtils.formatAreaNumber(property.carpetAreaSqFt)} sq.ft"
                            }
                            metricParts.add(areaStr)
                        }
                        if (effectivePrice > 0.0) {
                            metricParts.add(CalculationUtils.formatIndianCurrency(effectivePrice, property.tab.isRental))
                        }

                        if (metricParts.isNotEmpty()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (property.carpetAreaSqFt > 0.0) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.OpenInFull,
                                            contentDescription = "Area",
                                            tint = DeepNavy,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = metricParts.first(),
                                            color = NavyPrimaryText,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }
                                if (property.carpetAreaSqFt > 0.0 && effectivePrice > 0.0) {
                                    Text("|", color = CardDividerBorder, fontSize = 12.sp)
                                }
                                if (effectivePrice > 0.0) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.CurrencyRupee,
                                            contentDescription = "Price or Rent",
                                            tint = DeepNavy,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Text(
                                            text = CalculationUtils.formatIndianCurrency(effectivePrice, property.tab.isRental),
                                            color = NavyPrimaryText,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }

                        // Commercial Secondary Specs: Rent/sq.ft, Sale Rate/BU, Furnishing, Floor (Only available values)
                        val secondaryComm = buildList {
                            if (rentPerSqFt != null && rentPerSqFt > 0.0) {
                                add("₹${rentPerSqFt.toInt()}/sq.ft")
                            }
                            if (saleRateOnBuiltUp != null && saleRateOnBuiltUp > 0.0) {
                                add("₹${saleRateOnBuiltUp.toInt()}/sq.ft BU")
                            }
                            if (property.furnishing.label.isNotBlank()) {
                                add(property.furnishing.label)
                            }
                            val floorVal = property.floorLevel?.ifBlank { property.floor } ?: property.floor
                            if (floorVal.isNotBlank()) {
                                add(floorVal)
                            }
                        }
                        if (secondaryComm.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = secondaryComm.joinToString(" • "),
                                color = SlateSecondaryText,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    } else {
                        // Residential Primary Metrics: Configuration (2 BHK / 3 BHK) | Carpet Area | Asking Price
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!property.bhk.isNullOrBlank()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Bed,
                                        contentDescription = "Configuration",
                                        tint = DeepNavy,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = property.bhk,
                                        color = NavyPrimaryText,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }
                            if (property.carpetAreaSqFt > 0.0) {
                                if (!property.bhk.isNullOrBlank()) {
                                    Text("|", color = CardDividerBorder, fontSize = 12.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.OpenInFull,
                                        contentDescription = "Carpet Area",
                                        tint = DeepNavy,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "${CalculationUtils.formatAreaNumber(property.carpetAreaSqFt)} sq.ft",
                                        color = NavyPrimaryText,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }
                        }

                        // Residential Price & Possession line
                        val resiSubParts = buildList {
                            if (effectivePrice > 0.0) {
                                add(CalculationUtils.formatIndianCurrency(effectivePrice, property.tab.isRental))
                            }
                            if (property.possession.isNotBlank()) {
                                add("Possession: ${property.possession}")
                            }
                        }
                        if (resiSubParts.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = resiSubParts.joinToString(" • "),
                                color = SlateSecondaryText,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Row 6: Bottom Pill Tags — Property Type | Transaction Type | Business Brand (Ascend / Aurea)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val typeLabel = property.propertyType.ifBlank { property.tab.code }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(PillCategoryBlueBg)
                                .padding(horizontal = 10.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = typeLabel,
                                color = PillCategoryBlueText,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(SurfacePlaceholder)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = transactionLabel,
                                color = NavyPrimaryText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(PillBrandPurpleBg)
                                .padding(horizontal = 10.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = brandBadgeLabel,
                                color = PillBrandPurpleText,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // =========================================================================
            // D. DATA COMPLETION INDICATOR (Thin Progress Bar + Label)
            // Distinct from Verification & Availability Status
            // =========================================================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Data Completion",
                        color = SlateSecondaryText,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "$completionPercent%",
                        color = completionColor,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                LinearProgressIndicator(
                    progress = { completionPercent / 100f },
                    color = completionColor,
                    trackColor = SurfacePlaceholder,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.5.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .testTag("completion_bar_${property.propertyCode}")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = CardDividerBorder, thickness = 0.7.dp)

            // =========================================================================
            // PART 3 — COMPACT CARD ACTIONS ROW
            // View | Call | WhatsApp | Edit (Permission-guarded) | Favourite | More (⋮)
            // =========================================================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SoftWhiteBg.copy(alpha = 0.6f))
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. View Details
                TextButton(
                    onClick = onCardClick,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier
                        .defaultMinSize(minHeight = 36.dp)
                        .testTag("action_view_${property.propertyCode}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Visibility,
                        contentDescription = "View Details",
                        tint = PremiumTeal,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("View", color = NavyPrimaryText, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                }

                // 2. Call Owner / POC (Explicit user action)
                val hasPhone = !property.ownerContact.isNullOrBlank()
                TextButton(
                    onClick = { dialSavedContact(context, property.ownerContact) },
                    enabled = hasPhone,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier
                        .defaultMinSize(minHeight = 36.dp)
                        .testTag("action_call_${property.propertyCode}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Call,
                        contentDescription = "Call Owner or POC",
                        tint = if (hasPhone) PremiumTeal else SlateSecondaryText.copy(alpha = 0.4f),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Call",
                        color = if (hasPhone) NavyPrimaryText else SlateSecondaryText.copy(alpha = 0.4f),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // 3. WhatsApp Share Preview (Privacy-Safe)
                TextButton(
                    onClick = onShareWhatsApp,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier
                        .defaultMinSize(minHeight = 36.dp)
                        .testTag("action_whatsapp_${property.propertyCode}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share via WhatsApp",
                        tint = StatusAvailable,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share", color = NavyPrimaryText, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                }

                // 4. Edit (Subject to employee permissions)
                if (onEditClick != null && canEdit) {
                    TextButton(
                        onClick = onEditClick,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .defaultMinSize(minHeight = 36.dp)
                            .testTag("action_edit_${property.propertyCode}")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Edit,
                            contentDescription = "Edit Property",
                            tint = DeepNavy,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit", color = NavyPrimaryText, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                // 6. More Overflow Menu (Compare, Status Update, Archive, History)
                Box {
                    IconButton(
                        onClick = { showOverflowMenu = true },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("action_more_${property.propertyCode}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More property actions",
                            tint = SlateSecondaryText,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showOverflowMenu,
                        onDismissRequest = { showOverflowMenu = false },
                        modifier = Modifier.background(PureWhiteCard)
                    ) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    if (isInComparison) "Remove from Comparison" else "Add to Comparison",
                                    color = NavyPrimaryText,
                                    fontSize = 13.sp
                                )
                            },
                            leadingIcon = {
                                Icon(Icons.Default.CompareArrows, contentDescription = null, tint = PremiumTeal, modifier = Modifier.size(18.dp))
                            },
                            onClick = {
                                showOverflowMenu = false
                                onToggleCompare()
                            }
                        )
                        DropdownMenuItem(
                            text = {
                                Text(
                                    if (isFavorite) "Remove from Favourites" else "Save to Favourites",
                                    color = NavyPrimaryText,
                                    fontSize = 13.sp
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                    contentDescription = null,
                                    tint = Color(0xFFF59E0B),
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            onClick = {
                                showOverflowMenu = false
                                onToggleFavorite()
                            }
                        )
                        if (canEdit) {
                            HorizontalDivider(color = CardDividerBorder)
                            DropdownMenuItem(
                                text = { Text("Mark Available", color = StatusAvailable, fontSize = 13.sp) },
                                leadingIcon = {
                                    Icon(Icons.Default.CheckCircleOutline, contentDescription = null, tint = StatusAvailable, modifier = Modifier.size(18.dp))
                                },
                                onClick = {
                                    showOverflowMenu = false
                                    onStatusChange(AvailabilityStatus.AVAILABLE)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Mark Pending Verification", color = StatusUnconfirmed, fontSize = 13.sp) },
                                leadingIcon = {
                                    Icon(Icons.Default.Schedule, contentDescription = null, tint = StatusUnconfirmed, modifier = Modifier.size(18.dp))
                                },
                                onClick = {
                                    showOverflowMenu = false
                                    onStatusChange(AvailabilityStatus.NOT_CONFIRMED)
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        if (property.tab.isRental) "Mark Rented / Leased" else "Mark Sold",
                                        color = StatusNotAvailable,
                                        fontSize = 13.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Block, contentDescription = null, tint = StatusNotAvailable, modifier = Modifier.size(18.dp))
                                },
                                onClick = {
                                    showOverflowMenu = false
                                    onStatusChange(AvailabilityStatus.NOT_AVAILABLE)
                                }
                            )
                        }
                        HorizontalDivider(color = CardDividerBorder)
                        DropdownMenuItem(
                            text = { Text("Attachments & History", color = NavyPrimaryText, fontSize = 13.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.History, contentDescription = null, tint = DeepNavy, modifier = Modifier.size(18.dp))
                            },
                            onClick = {
                                showOverflowMenu = false
                                onCardClick()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PropertyGridCard(
    property: PropertyItem,
    isInternalMode: Boolean,
    isFavorite: Boolean,
    isInComparison: Boolean,
    onCardClick: () -> Unit,
    onEditClick: (() -> Unit)? = null,
    onToggleFavorite: () -> Unit,
    onToggleCompare: () -> Unit,
    onShareWhatsApp: () -> Unit,
    onStatusChange: (AvailabilityStatus) -> Unit = {},
    canEdit: Boolean = true
) {
    val (statusLabel, statusBgColor, statusTextColor) = remember(property.status, property.archiveStatus, property.tab) {
        resolveCardStatusStyle(property)
    }
    val completionPercent = remember(property) { CalculationUtils.computeCompletenessScore(property) }
    val completionColor = remember(completionPercent) { resolveCompletionBarColor(completionPercent) }
    val isCommercial = remember(property) { property.isCommercial() }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, CardDividerBorder, RoundedCornerShape(14.dp))
            .clickable { onCardClick() }
            .testTag("property_grid_card_${property.propertyCode}"),
        colors = CardDefaults.cardColors(containerColor = PureWhiteCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(105.dp)
                    .background(SurfacePlaceholder),
                contentAlignment = Alignment.Center
            ) {
                if (property.images.isNotEmpty()) {
                    AsyncImage(
                        model = property.images.first(),
                        contentDescription = property.projectName,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = if (isCommercial) Icons.Default.Business else Icons.Default.Apartment,
                        contentDescription = null,
                        tint = SlateSecondaryText,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .padding(6.dp)
                        .align(Alignment.TopStart)
                        .clip(RoundedCornerShape(50))
                        .background(statusBgColor)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = statusLabel,
                        color = statusTextColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .size(28.dp)
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .background(PureWhiteCard.copy(alpha = 0.85f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Favourite",
                        tint = if (isFavorite) Color(0xFFF59E0B) else SlateSecondaryText,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = property.propertyCode,
                    color = NavyPrimaryText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1
                )
                if (property.projectName.isNotBlank()) {
                    Text(
                        text = property.projectName,
                        color = NavyPrimaryText,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (property.location.isNotBlank()) {
                    Text(
                        text = property.location,
                        color = SlateSecondaryText,
                        fontSize = 10.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = buildString {
                        if (!isCommercial && !property.bhk.isNullOrBlank()) {
                            append(property.bhk).append(" • ")
                        }
                        if (property.carpetAreaSqFt > 0.0) {
                            append("${CalculationUtils.formatAreaNumber(property.carpetAreaSqFt)} sq.ft")
                        }
                    },
                    color = NavyPrimaryText,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )

                if (property.priceOrRent > 0.0) {
                    Text(
                        text = CalculationUtils.formatIndianCurrency(property.priceOrRent, property.tab.isRental),
                        color = PremiumTeal,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { completionPercent / 100f },
                    color = completionColor,
                    trackColor = SurfacePlaceholder,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                )
            }
        }
    }
}

@Composable
fun SpecTag(icon: ImageVector, label: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(PillCategoryBlueBg)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                icon,
                contentDescription = null,
                tint = PillCategoryBlueText,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = PillCategoryBlueText,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
