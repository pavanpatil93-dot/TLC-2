package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Brand
import com.example.model.BrandLogos
import com.example.ui.theme.*

@Composable
fun PortalTopBar(
    selectedBrand: Brand?,
    onSelectBrand: (Brand?) -> Unit,
    brandLogos: BrandLogos,
    onOpenDrawer: () -> Unit,
    onOpenAddProperty: () -> Unit,
    onOpenImport: () -> Unit,
    comparisonCount: Int,
    onOpenComparison: () -> Unit,
    onNavigateHome: () -> Unit
) {
    var showBrandDropdown by remember { mutableStateOf(false) }

    Surface(
        color = BrandCharcoalDark,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth().testTag("portal_top_bar")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            // Main Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Hamburger Menu Button to open Left Sliding Sidebar
                    IconButton(
                        onClick = onOpenDrawer,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(BrandCharcoalSurface)
                            .border(0.8.dp, BrandCharcoalBorder, RoundedCornerShape(8.dp))
                            .testTag("hamburger_menu_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Open Navigation Sidebar",
                            tint = AscendGold,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    // Brand Logo dynamically matching selected portfolio
                    val customLogo = when (selectedBrand) {
                        Brand.ASCEND_COMMERCIAL -> brandLogos.ascendLogoUri
                        Brand.AUREA_LIVING -> brandLogos.aureaLogoUri
                        null -> null
                    }

                    Box(modifier = Modifier.clickable { onNavigateHome() }) {
                        BrandLogoView(
                            brand = selectedBrand,
                            customLogoUri = customLogo,
                            size = 36.dp
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    // Title & Subtitle
                    Column(
                        modifier = Modifier
                            .clickable { onNavigateHome() }
                            .padding(vertical = 2.dp)
                    ) {
                        Text(
                            text = when (selectedBrand) {
                                Brand.ASCEND_COMMERCIAL -> "COMMERCIAL"
                                Brand.AUREA_LIVING -> "RESIDENTIAL"
                                null -> "REAL ESTATE INVENTORY"
                            },
                            color = when (selectedBrand) {
                                Brand.ASCEND_COMMERCIAL -> AscendGold
                                Brand.AUREA_LIVING -> Color(0xFF6EE7B7)
                                null -> TextPrimaryDark
                            },
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.6.sp
                        )
                        Text(
                            text = when (selectedBrand) {
                                Brand.ASCEND_COMMERCIAL -> "ASCEND COMMERCIAL"
                                Brand.AUREA_LIVING -> "AUREA LIVING"
                                null -> "INVENTORY DASHBOARD"
                            },
                            color = TextSecondaryDark,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Portfolio Switcher Dropdown in Header
                Box {
                    val switcherBorderColor = when (selectedBrand) {
                        Brand.ASCEND_COMMERCIAL -> AscendGold
                        Brand.AUREA_LIVING -> Color(0xFF10B981)
                        null -> AscendGold.copy(alpha = 0.5f)
                    }
                    val switcherTextColor = when (selectedBrand) {
                        Brand.ASCEND_COMMERCIAL -> AscendGold
                        Brand.AUREA_LIVING -> Color(0xFF6EE7B7)
                        null -> AscendGold
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(BrandCharcoalSurface)
                            .border(1.dp, switcherBorderColor, RoundedCornerShape(8.dp))
                            .clickable { showBrandDropdown = true }
                            .padding(horizontal = 9.dp, vertical = 6.dp)
                            .testTag("brand_selector_btn")
                    ) {
                        Text(
                            text = when (selectedBrand) {
                                Brand.ASCEND_COMMERCIAL -> "COMMERCIAL"
                                Brand.AUREA_LIVING -> "RESIDENTIAL"
                                null -> "ALL BUSINESSES"
                            },
                            color = switcherTextColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Switch Business",
                            tint = switcherTextColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showBrandDropdown,
                        onDismissRequest = { showBrandDropdown = false },
                        modifier = Modifier.background(BrandCharcoalSurface)
                    ) {
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text("ALL INVENTORY", color = TextPrimaryDark, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    Text("Combined Commercial & Residential", color = TextSecondaryDark, fontSize = 9.5.sp)
                                }
                            },
                            onClick = {
                                onSelectBrand(null)
                                showBrandDropdown = false
                            }
                        )
                        HorizontalDivider(color = BrandCharcoalBorder, thickness = 0.5.dp)
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text("COMMERCIAL", color = AscendGold, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    Text("Offices, Shops, Showrooms, Pre-Leased & Land", color = TextSecondaryDark, fontSize = 9.5.sp)
                                }
                            },
                            onClick = {
                                onSelectBrand(Brand.ASCEND_COMMERCIAL)
                                showBrandDropdown = false
                            }
                        )
                        HorizontalDivider(color = BrandCharcoalBorder, thickness = 0.5.dp)
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text("RESIDENTIAL", color = Color(0xFF6EE7B7), fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    Text("Rent, Resale, Under Const, Villas & Plots", color = TextSecondaryDark, fontSize = 9.5.sp)
                                }
                            },
                            onClick = {
                                onSelectBrand(Brand.AUREA_LIVING)
                                showBrandDropdown = false
                            }
                        )
                    }
                }
            }

            val isDesktop = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 600

            if (isDesktop || comparisonCount > 0) {
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Comparison Badge
                        if (comparisonCount > 0) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(BrandCharcoalCard)
                                    .border(0.8.dp, AscendGold.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                    .clickable { onOpenComparison() }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                    .testTag("topbar_compare_badge")
                            ) {
                                Text("Compare ($comparisonCount)", color = AscendGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (isDesktop) {
                            // Master Sheet Sync Button (Desktop only)
                            Button(
                                onClick = onOpenImport,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BrandCharcoalCard,
                                    contentColor = TextPrimaryDark
                                ),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(28.dp)
                                    .border(0.8.dp, BrandCharcoalBorder, RoundedCornerShape(6.dp))
                                    .testTag("upload_inventory_top_btn")
                            ) {
                                Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(13.dp), tint = AscendGold)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Sync", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }

                            // + Add Property Button (Desktop only)
                            Button(
                                onClick = onOpenAddProperty,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AscendGold,
                                    contentColor = BrandCharcoalDark
                                ),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp),
                                modifier = Modifier.height(28.dp).testTag("add_property_top_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("Add", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
