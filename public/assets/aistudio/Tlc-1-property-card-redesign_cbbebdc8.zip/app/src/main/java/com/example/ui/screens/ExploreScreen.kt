package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

enum class VerificationFilterTab(val label: String) {
    ALL("All Active"),
    VERIFIED("Verified"),
    PENDING("Pending"),
    ARCHIVE("Archive")
}

sealed interface CategoryFilterOption {
    data object AllCommercial : CategoryFilterOption
    data object AllResidential : CategoryFilterOption
    data class TabCategory(val tab: InventoryTab) : CategoryFilterOption
    data class TypeCategory(val typeName: String, val label: String) : CategoryFilterOption
}

fun getCategoryDisplayName(tab: InventoryTab): String = when (tab) {
    InventoryTab.OFF_LEASE -> "Office Lease"
    InventoryTab.OFF_OUT -> "Office Sale"
    InventoryTab.SHOP_LEASE -> "Shop Lease"
    InventoryTab.SHOP_OUT -> "Shop Sale"
    InventoryTab.PRE_LEASED -> "Pre-Leased Commercial"
    InventoryTab.RESI_RENT -> "Residential Rent"
    InventoryTab.RESI_RESALE -> "Residential Resale"
    InventoryTab.UND_CONST -> "Under Construction"
}

fun getCategoriesForBrand(brand: Brand?): List<CategoryFilterOption> {
    return when (brand) {
        Brand.ASCEND_COMMERCIAL -> listOf(
            CategoryFilterOption.AllCommercial,
            CategoryFilterOption.TabCategory(InventoryTab.OFF_LEASE),
            CategoryFilterOption.TabCategory(InventoryTab.OFF_OUT),
            CategoryFilterOption.TabCategory(InventoryTab.SHOP_LEASE),
            CategoryFilterOption.TabCategory(InventoryTab.SHOP_OUT),
            CategoryFilterOption.TypeCategory("showroom", "Showroom"),
            CategoryFilterOption.TabCategory(InventoryTab.PRE_LEASED),
            CategoryFilterOption.TypeCategory("warehouse", "Warehouse"),
            CategoryFilterOption.TypeCategory("commercial land", "Commercial Land")
        )
        Brand.AUREA_LIVING -> listOf(
            CategoryFilterOption.AllResidential,
            CategoryFilterOption.TabCategory(InventoryTab.RESI_RENT),
            CategoryFilterOption.TabCategory(InventoryTab.RESI_RESALE),
            CategoryFilterOption.TabCategory(InventoryTab.UND_CONST),
            CategoryFilterOption.TypeCategory("apartment", "Ready-to-Move"),
            CategoryFilterOption.TypeCategory("villa", "Villas / Bungalows"),
            CategoryFilterOption.TypeCategory("plot", "Residential Plots")
        )
        null -> listOf(
            CategoryFilterOption.AllCommercial,
            CategoryFilterOption.AllResidential
        )
    }
}

fun categoryMatches(property: PropertyItem, option: CategoryFilterOption): Boolean {
    val type = property.propertyType.lowercase()
    return when (option) {
        is CategoryFilterOption.AllCommercial -> property.isCommercial()
        is CategoryFilterOption.AllResidential -> property.isResidential()
        is CategoryFilterOption.TabCategory -> property.tab == option.tab
        is CategoryFilterOption.TypeCategory -> {
            when (option.typeName) {
                "showroom" -> type.contains("showroom") || property.tab == InventoryTab.SHOP_LEASE
                "warehouse" -> type.contains("warehouse") || type.contains("godown")
                "commercial land" -> type.contains("commercial land") || type.contains("land")
                "apartment" -> type.contains("apartment") || type.contains("flat") || type.contains("ready")
                "villa" -> type.contains("villa") || type.contains("bungalow")
                "plot" -> type.contains("plot") || type.contains("residential plot")
                else -> type.contains(option.typeName)
            }
        }
    }
}

@Composable
fun ExploreScreen(
    properties: List<PropertyItem>,
    selectedBrand: Brand?,
    onSelectBrand: (Brand?) -> Unit,
    isInternalMode: Boolean,
    favoriteIds: Set<String>,
    comparisonIds: List<String>,
    onPropertyClick: (PropertyItem) -> Unit,
    onEditProperty: (PropertyItem) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onToggleCompare: (String) -> Unit,
    onShareWhatsApp: (PropertyItem) -> Unit,
    onStatusChange: (String, AvailabilityStatus) -> Unit,
    onOpenAddProperty: () -> Unit,
    onOpenImport: () -> Unit,
    isLiveConnected: Boolean = false,
    lastSyncTimestamp: String = "",
    showUnclassifiedOnly: Boolean = false,
    onClearUnclassifiedOnly: (() -> Unit)? = null
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedVerificationTab by remember { mutableStateOf(VerificationFilterTab.ALL) }
    var selectedCategoryOption by remember { mutableStateOf<CategoryFilterOption?>(null) }
    var showFilterSheet by remember { mutableStateOf(false) }
    var filterState by remember { mutableStateOf(FilterState()) }
    var sortBy by remember { mutableStateOf("Default") }
    var isGridView by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val gridState = rememberLazyGridState()

    var previousIndex by remember { mutableStateOf(0) }
    var previousScrollOffset by remember { mutableStateOf(0) }
    val isHeaderExpanded by remember {
        derivedStateOf {
            val currentIndex = if (isGridView) gridState.firstVisibleItemIndex else listState.firstVisibleItemIndex
            val currentOffset = if (isGridView) gridState.firstVisibleItemScrollOffset else listState.firstVisibleItemScrollOffset
            val scrollingUp = if (currentIndex != previousIndex) {
                currentIndex < previousIndex
            } else {
                currentOffset <= previousScrollOffset
            }
            previousIndex = currentIndex
            previousScrollOffset = currentOffset
            currentIndex == 0 || scrollingUp
        }
    }

    // Portfolio base pool
    val portfolioProperties = remember(properties, selectedBrand, showUnclassifiedOnly) {
        if (showUnclassifiedOnly) {
            properties.filter { it.isUnclassified() }
        } else {
            when (selectedBrand) {
                Brand.ASCEND_COMMERCIAL -> properties.filter { it.isCommercial() }
                Brand.AUREA_LIVING -> properties.filter { it.isResidential() }
                null -> properties
            }
        }
    }

    // Verification tab counts for current portfolio
    val verifiedCount = remember(portfolioProperties) {
        portfolioProperties.count { it.verificationStatus == VerificationStatus.VERIFIED && it.archiveStatus != ArchiveStatus.ARCHIVED }
    }
    val pendingCount = remember(portfolioProperties) {
        portfolioProperties.count { it.verificationStatus == VerificationStatus.PENDING && it.archiveStatus != ArchiveStatus.ARCHIVED }
    }
    val archiveCount = remember(portfolioProperties) {
        portfolioProperties.count { it.archiveStatus == ArchiveStatus.ARCHIVED }
    }
    val activeTotalCount = remember(portfolioProperties) {
        portfolioProperties.count { it.archiveStatus != ArchiveStatus.ARCHIVED }
    }
    val unclassifiedCount = remember(properties) { properties.count { it.isUnclassified() } }

    // Filter properties based on verification tab, category option, search query, and filterState
    val filteredProperties = remember(portfolioProperties, selectedVerificationTab, selectedCategoryOption, searchQuery, filterState, sortBy, showUnclassifiedOnly) {
        var list = portfolioProperties

        if (!showUnclassifiedOnly) {
            // Verification Tab filter
            list = when (selectedVerificationTab) {
                VerificationFilterTab.ALL -> list.filter { it.archiveStatus != ArchiveStatus.ARCHIVED }
                VerificationFilterTab.VERIFIED -> list.filter { it.verificationStatus == VerificationStatus.VERIFIED && it.archiveStatus != ArchiveStatus.ARCHIVED }
                VerificationFilterTab.PENDING -> list.filter { it.verificationStatus == VerificationStatus.PENDING && it.archiveStatus != ArchiveStatus.ARCHIVED }
                VerificationFilterTab.ARCHIVE -> list.filter { it.archiveStatus == ArchiveStatus.ARCHIVED }
            }

            // Category filter
            if (selectedCategoryOption != null) {
                list = list.filter { categoryMatches(it, selectedCategoryOption!!) }
            }
        }

        // Search text
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.projectName.lowercase().contains(q) ||
                it.location.lowercase().contains(q) ||
                it.propertyCode.lowercase().contains(q) ||
                (it.unitNumber.lowercase().contains(q)) ||
                (it.bhk != null && it.bhk.lowercase().contains(q)) ||
                it.furnishing.label.lowercase().contains(q) ||
                (it.ownerName != null && it.ownerName.lowercase().contains(q)) ||
                (it.remarks != null && it.remarks.lowercase().contains(q))
            }
        }

        // Advanced filter sheet
        if (filterState.tab != null) {
            list = list.filter { it.tab == filterState.tab }
        }
        if (filterState.status != null) {
            list = list.filter { it.status == filterState.status }
        }
        if (filterState.furnishing != null) {
            list = list.filter { it.furnishing == filterState.furnishing }
        }
        if (filterState.minCarpet > 0) {
            list = list.filter { it.carpetAreaSqFt >= filterState.minCarpet }
        }

        // Sorting
        when (sortBy) {
            "PriceAsc" -> list.sortedBy { it.priceOrRent }
            "PriceDesc" -> list.sortedByDescending { it.priceOrRent }
            "AreaDesc" -> list.sortedByDescending { it.carpetAreaSqFt }
            "CodeAsc" -> list.sortedBy { it.propertyCode }
            else -> list
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandCharcoalDark)
            .testTag("explore_screen")
    ) {
        // Sticky Header: Portfolio Indicator & Search Bar & Action Buttons
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BrandCharcoalDark)
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            // Business Context Switcher Pills: Commercial (Ascend) | Residential (Aurea)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val isCommSelected = selectedBrand == Brand.ASCEND_COMMERCIAL
                val isResiSelected = selectedBrand == Brand.AUREA_LIVING
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(if (isCommSelected) PremiumTeal else PureWhiteCard)
                        .border(1.dp, if (isCommSelected) PremiumTeal else CardDividerBorder, RoundedCornerShape(50))
                        .clickable {
                            onSelectBrand(if (isCommSelected) null else Brand.ASCEND_COMMERCIAL)
                        }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Commercial (Ascend)",
                        color = if (isCommSelected) Color.White else NavyPrimaryText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(50))
                        .background(if (isResiSelected) PremiumTeal else PureWhiteCard)
                        .border(1.dp, if (isResiSelected) PremiumTeal else CardDividerBorder, RoundedCornerShape(50))
                        .clickable {
                            onSelectBrand(if (isResiSelected) null else Brand.AUREA_LIVING)
                        }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Residential (Aurea)",
                        color = if (isResiSelected) Color.White else NavyPrimaryText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            // Search Input Row & Filter Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text("Search Kharadi, Baner, WTC, code, project...", color = TextMutedDark, fontSize = 12.sp)
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = AscendGold, modifier = Modifier.size(18.dp))
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMutedDark, modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = BrandCharcoalSurface,
                        unfocusedContainerColor = BrandCharcoalSurface,
                        focusedBorderColor = AscendGold,
                        unfocusedBorderColor = BrandCharcoalBorder,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("search_text_input")
                )

                // Filter Sheet Button
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (filterState.tab != null || filterState.status != null) AscendGold else BrandCharcoalSurface)
                        .border(1.dp, if (filterState.tab != null) AscendGold else BrandCharcoalBorder, RoundedCornerShape(10.dp))
                        .clickable { showFilterSheet = true }
                        .testTag("filter_sheet_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Filters",
                        tint = if (filterState.tab != null || filterState.status != null) BrandCharcoalDark else AscendGold,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Grid/List View Toggle
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(BrandCharcoalSurface)
                        .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(10.dp))
                        .clickable { isGridView = !isGridView }
                        .testTag("grid_list_toggle_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isGridView) Icons.Default.ViewAgenda else Icons.Default.GridView,
                        contentDescription = "Toggle View",
                        tint = TextSecondaryDark,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            AnimatedVisibility(visible = isHeaderExpanded) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                Text("Active: $activeTotalCount", color = TextSecondaryDark, fontSize = 11.sp)
                Text("Verified: $verifiedCount", color = TextSecondaryDark, fontSize = 11.sp)
                Text("Pending: $pendingCount", color = TextSecondaryDark, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onOpenAddProperty, contentPadding = PaddingValues(0.dp)) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text("Add", fontSize = 11.sp)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))

            // Verification Status Tabs (All Active, Verified, Pending, Archive)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                VerificationTabChip(
                    label = "Active ($activeTotalCount)",
                    isSelected = selectedVerificationTab == VerificationFilterTab.ALL && !showUnclassifiedOnly,
                    onClick = {
                        selectedVerificationTab = VerificationFilterTab.ALL
                        onClearUnclassifiedOnly?.invoke()
                    },
                    modifier = Modifier.weight(1f)
                )
                VerificationTabChip(
                    label = "Verified ($verifiedCount)",
                    isSelected = selectedVerificationTab == VerificationFilterTab.VERIFIED && !showUnclassifiedOnly,
                    onClick = {
                        selectedVerificationTab = VerificationFilterTab.VERIFIED
                        onClearUnclassifiedOnly?.invoke()
                    },
                    modifier = Modifier.weight(1f),
                    badgeColor = StatusAvailable
                )
                VerificationTabChip(
                    label = "Pending ($pendingCount)",
                    isSelected = selectedVerificationTab == VerificationFilterTab.PENDING && !showUnclassifiedOnly,
                    onClick = {
                        selectedVerificationTab = VerificationFilterTab.PENDING
                        onClearUnclassifiedOnly?.invoke()
                    },
                    modifier = Modifier.weight(1f),
                    badgeColor = StatusUnconfirmed
                )
                VerificationTabChip(
                    label = "Archive ($archiveCount)",
                    isSelected = selectedVerificationTab == VerificationFilterTab.ARCHIVE && !showUnclassifiedOnly,
                    onClick = {
                        selectedVerificationTab = VerificationFilterTab.ARCHIVE
                        onClearUnclassifiedOnly?.invoke()
                    },
                    modifier = Modifier.weight(1f),
                    badgeColor = TextMutedDark
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Portfolio-Aware Category Filter Chips Row
            val categoryOptions = remember(selectedBrand) { getCategoriesForBrand(selectedBrand) }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // "All Categories" Chip
                item {
                    val isAllSelected = selectedCategoryOption == null && !showUnclassifiedOnly
                    CategoryChip(
                        label = "All ${if (selectedBrand == Brand.ASCEND_COMMERCIAL) "Commercial" else if (selectedBrand == Brand.AUREA_LIVING) "Residential" else "Properties"} ($activeTotalCount)",
                        isSelected = isAllSelected,
                        onClick = {
                            selectedCategoryOption = null
                            onClearUnclassifiedOnly?.invoke()
                        }
                    )
                }

                items(categoryOptions) { option ->
                    val isSelected = selectedCategoryOption == option && !showUnclassifiedOnly
                    val count = portfolioProperties.count { categoryMatches(it, option) && it.archiveStatus != ArchiveStatus.ARCHIVED }
                    val label = when (option) {
                        is CategoryFilterOption.AllCommercial -> "All Commercial ($count)"
                        is CategoryFilterOption.AllResidential -> "All Residential ($count)"
                        is CategoryFilterOption.TabCategory -> "${getCategoryDisplayName(option.tab)} ($count)"
                        is CategoryFilterOption.TypeCategory -> "${option.label} ($count)"
                    }
                    CategoryChip(
                        label = label,
                        isSelected = isSelected,
                        onClick = {
                            selectedCategoryOption = if (isSelected) null else option
                            onClearUnclassifiedOnly?.invoke()
                        }
                    )
                }

                if (unclassifiedCount > 0) {
                    item {
                        CategoryChip(
                            label = "Unclassified ($unclassifiedCount)",
                            isSelected = showUnclassifiedOnly,
                            onClick = {
                                if (showUnclassifiedOnly) {
                                    onClearUnclassifiedOnly?.invoke()
                                } else {
                                    selectedCategoryOption = null
                                }
                            }
                        )
                    }
                }
            }

                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Sort & Results Count Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredProperties.size} Properties Found",
                    color = TextSecondaryDark,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )

                // Quick Sort Dropdown
                var sortExpanded by remember { mutableStateOf(false) }
                Box {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { sortExpanded = true }
                            .padding(4.dp)
                    ) {
                        Text(
                            text = when (sortBy) {
                                "PriceAsc" -> "Price: Low to High"
                                "PriceDesc" -> "Price: High to Low"
                                "AreaDesc" -> "Carpet Area: Highest"
                                "CodeAsc" -> "Property Code"
                                else -> "Sort: Default"
                            },
                            color = AscendGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = AscendGold, modifier = Modifier.size(16.dp))
                    }

                    DropdownMenu(
                        expanded = sortExpanded,
                        onDismissRequest = { sortExpanded = false },
                        modifier = Modifier.background(BrandCharcoalSurface)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Default Sorting", color = TextPrimaryDark, fontSize = 12.sp) },
                            onClick = { sortBy = "Default"; sortExpanded = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Price: Low to High", color = TextPrimaryDark, fontSize = 12.sp) },
                            onClick = { sortBy = "PriceAsc"; sortExpanded = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Price: High to Low", color = TextPrimaryDark, fontSize = 12.sp) },
                            onClick = { sortBy = "PriceDesc"; sortExpanded = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Carpet Area: Largest", color = TextPrimaryDark, fontSize = 12.sp) },
                            onClick = { sortBy = "AreaDesc"; sortExpanded = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Property Code: A-Z", color = TextPrimaryDark, fontSize = 12.sp) },
                            onClick = { sortBy = "CodeAsc"; sortExpanded = false }
                        )
                    }
                }
            }
        }

        HorizontalDivider(color = BrandCharcoalBorder, thickness = 0.8.dp)

        // Main Property Content: Grid or List
        if (properties.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(AscendGold.copy(alpha = 0.5f))
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(32.dp))
                                .background(AscendGold.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = null,
                                tint = AscendGold,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Inventory Master Connected",
                            color = TextPrimaryDark,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Ascend Commercial Solutions & Aurea Living are ready for your master records.",
                            color = TextSecondaryDark,
                            fontSize = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = onOpenImport,
                                colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sync Google Sheet", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            OutlinedButton(
                                onClick = onOpenAddProperty,
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold.copy(alpha = 0.6f)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = AscendGold, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add Property", color = TextPrimaryDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        } else if (filteredProperties.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SearchOff,
                        contentDescription = null,
                        tint = TextMutedDark,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No properties match your filter",
                        color = TextPrimaryDark,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Try clearing your search query or switching verification tab",
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            searchQuery = ""
                            selectedCategoryOption = null
                            selectedVerificationTab = VerificationFilterTab.ALL
                            filterState = FilterState()
                            onClearUnclassifiedOnly?.invoke()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Reset Filters", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else if (isGridView) {
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredProperties, key = { it.id }) { property ->
                    PropertyGridCard(
                        property = property,
                        isInternalMode = isInternalMode,
                        isFavorite = favoriteIds.contains(property.id),
                        isInComparison = comparisonIds.contains(property.id),
                        onCardClick = { onPropertyClick(property) },
                        onEditClick = { onEditProperty(property) },
                        onToggleFavorite = { onToggleFavorite(property.id) },
                        onToggleCompare = { onToggleCompare(property.id) },
                        onShareWhatsApp = { onShareWhatsApp(property) },
                        onStatusChange = { newStatus -> onStatusChange(property.id, newStatus) }
                    )
                }
            }
        } else {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredProperties, key = { it.id }) { property ->
                    PropertyCard(
                        property = property,
                        isInternalMode = isInternalMode,
                        isFavorite = favoriteIds.contains(property.id),
                        isInComparison = comparisonIds.contains(property.id),
                        onCardClick = { onPropertyClick(property) },
                        onEditClick = { onEditProperty(property) },
                        onToggleFavorite = { onToggleFavorite(property.id) },
                        onToggleCompare = { onToggleCompare(property.id) },
                        onShareWhatsApp = { onShareWhatsApp(property) },
                        onStatusChange = { newStatus -> onStatusChange(property.id, newStatus) }
                    )
                }
            }
        }
    }

    // Filter Bottom Sheet
    if (showFilterSheet) {
        FilterSheet(
            filterState = filterState,
            onFilterChange = { newState ->
                filterState = newState
                showFilterSheet = false
            },
            onDismiss = { showFilterSheet = false }
        )
    }
}

@Composable
fun VerificationTabChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badgeColor: Color = AscendGold
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) badgeColor else BrandCharcoalSurface)
            .border(
                1.dp,
                if (isSelected) badgeColor else BrandCharcoalBorder,
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 6.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) BrandCharcoalDark else TextSecondaryDark,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
fun CategoryChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) AscendGold else BrandCharcoalSurface)
            .border(
                1.dp,
                if (isSelected) AscendGoldLight else BrandCharcoalBorder,
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) BrandCharcoalDark else TextSecondaryDark,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
