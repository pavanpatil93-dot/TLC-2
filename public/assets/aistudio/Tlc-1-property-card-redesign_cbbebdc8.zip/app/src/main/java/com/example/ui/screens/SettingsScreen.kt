package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.SheetsRepository
import com.example.data.UserSettingsManager
import com.example.model.*
import com.example.ui.components.BrandLogoView
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    userSettingsManager: UserSettingsManager,
    repository: SheetsRepository,
    properties: List<PropertyItem> = emptyList(),
    onBack: () -> Unit,
    onOpenMasterSync: () -> Unit,
    onPropertySelect: (PropertyItem) -> Unit = {},
    onVerifyProperty: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val userProfile by userSettingsManager.userProfile.collectAsState()
    val brandLogos by userSettingsManager.brandLogos.collectAsState()
    val ascendCompanyProfile by userSettingsManager.ascendCompanyProfile.collectAsState()
    val aureaCompanyProfile by userSettingsManager.aureaCompanyProfile.collectAsState()
    val validityDays by userSettingsManager.verificationValidityDays.collectAsState()

    val isLiveConnected by repository.isLiveConnected.collectAsState()
    val connectionStatus by repository.connectionStatus.collectAsState()
    val lastSyncTimestamp by repository.lastSyncTimestamp.collectAsState()
    val lastDiagnostic by repository.lastDiagnostic.collectAsState()
    val syncLogs by repository.syncLogs.collectAsState()

    // Active Section Tab (0: Company, 1: User, 2: Google Sheet, 3: Import/Export, 4: Verification, 5: Media, 6: Backup, 7: System)
    var activeSectionTab by remember { mutableStateOf(0) }

    // Company Profile Edit state
    var selectedCompanyIndex by remember { mutableStateOf(0) } // 0: Ascend, 1: Aurea
    var ascendNameInput by remember(ascendCompanyProfile) { mutableStateOf(ascendCompanyProfile.companyName) }
    var ascendContact1Input by remember(ascendCompanyProfile) { mutableStateOf(ascendCompanyProfile.contact1) }
    var ascendContact2Input by remember(ascendCompanyProfile) { mutableStateOf(ascendCompanyProfile.contact2) }
    var ascendEmailInput by remember(ascendCompanyProfile) { mutableStateOf(ascendCompanyProfile.email) }
    var ascendAddressInput by remember(ascendCompanyProfile) { mutableStateOf(ascendCompanyProfile.officeAddress) }
    var ascendFooterInput by remember(ascendCompanyProfile) { mutableStateOf(ascendCompanyProfile.whatsappFooter) }

    var aureaNameInput by remember(aureaCompanyProfile) { mutableStateOf(aureaCompanyProfile.companyName) }
    var aureaContact1Input by remember(aureaCompanyProfile) { mutableStateOf(aureaCompanyProfile.contact1) }
    var aureaContact2Input by remember(aureaCompanyProfile) { mutableStateOf(aureaCompanyProfile.contact2) }
    var aureaEmailInput by remember(aureaCompanyProfile) { mutableStateOf(aureaCompanyProfile.email) }
    var aureaAddressInput by remember(aureaCompanyProfile) { mutableStateOf(aureaCompanyProfile.officeAddress) }
    var aureaFooterInput by remember(aureaCompanyProfile) { mutableStateOf(aureaCompanyProfile.whatsappFooter) }

    // User Profile Edit state
    var usernameInput by remember(userProfile) { mutableStateOf(userProfile.username) }
    var userMobileInput by remember(userProfile) { mutableStateOf(userProfile.mobileNumber) }
    var userEmailInput by remember(userProfile) { mutableStateOf(userProfile.email) }
    var selectedRole by remember(userProfile) { mutableStateOf(userProfile.role) }

    // Dialog & Workflow state
    var showAuditReportDialog by remember { mutableStateOf(false) }
    var showSchemaValidationDialog by remember { mutableStateOf(false) }
    var schemaResult by remember { mutableStateOf<SchemaValidationResult?>(null) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportModeIsClient by remember { mutableStateOf(true) }
    var exportFilterType by remember { mutableStateOf("ALL") }
    var exportedText by remember { mutableStateOf("") }

    var showBackupDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var restoreJsonInput by remember { mutableStateOf("") }
    var restoreStatusText by remember { mutableStateOf<String?>(null) }
    var isRestoring by remember { mutableStateOf(false) }

    val activeProperties = remember(properties) { properties.filter { it.archiveStatus != ArchiveStatus.ARCHIVED } }
    val totalProps = activeProperties.size
    val currentProps = remember(activeProperties, validityDays) {
        activeProperties.count { getVerificationAgeState(it, validityDays) == VerificationAgeState.CURRENT }
    }
    val dueProps = remember(activeProperties, validityDays) {
        activeProperties.count { getVerificationAgeState(it, validityDays) == VerificationAgeState.DUE }
    }
    val pendingProps = remember(activeProperties, validityDays) {
        activeProperties.count { getVerificationAgeState(it, validityDays) == VerificationAgeState.PENDING }
    }

    // Photo pickers for Brand Logos & User Profile Photo
    val ascendLogoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            userSettingsManager.saveAscendLogo(uri)
            Toast.makeText(context, "Ascend Commercial logo updated & saved.", Toast.LENGTH_SHORT).show()
        }
    }

    val aureaLogoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            userSettingsManager.saveAureaLogo(uri)
            Toast.makeText(context, "Aurea Living logo updated & saved.", Toast.LENGTH_SHORT).show()
        }
    }

    val userPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            userSettingsManager.saveProfilePhoto(uri)
            Toast.makeText(context, "User profile photo updated.", Toast.LENGTH_SHORT).show()
        }
    }

    // Restore Backup File Picker
    val backupFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isRestoring = true
                restoreStatusText = "Reading backup JSON file..."
                try {
                    val jsonStr = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    if (jsonStr.isNotBlank()) {
                        restoreJsonInput = jsonStr
                        val (success, msg) = repository.restoreFromBackupJson(jsonStr, userSettingsManager)
                        restoreStatusText = msg
                        if (success) {
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        }
                    } else {
                        restoreStatusText = "Selected backup file was empty."
                    }
                } catch (e: Exception) {
                    restoreStatusText = "Failed to parse backup: ${e.localizedMessage}"
                } finally {
                    isRestoring = false
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandCharcoalDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .padding(bottom = 60.dp)
            .testTag("settings_screen")
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(BrandCharcoalSurface)
                    .border(0.8.dp, BrandCharcoalBorder, RoundedCornerShape(8.dp))
                    .size(38.dp)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = AscendGold)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "SETTINGS & ADMINISTRATION",
                    color = AscendGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "System Configuration & Profiles",
                    color = TextPrimaryDark,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SECTION TABS SCROLLER
        val sectionTabs = listOf(
            "Companies", "User Profile", "Google Sheet", "Verification",
            "Media Storage", "Backups", "System Info"
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(sectionTabs.indices.toList()) { idx ->
                val isSelected = activeSectionTab == idx
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) AscendGold else BrandCharcoalSurface)
                        .border(0.8.dp, if (isSelected) AscendGold else BrandCharcoalBorder, RoundedCornerShape(8.dp))
                        .clickable { activeSectionTab = idx }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("settings_tab_$idx")
                ) {
                    Text(
                        text = sectionTabs[idx],
                        color = if (isSelected) BrandCharcoalDark else TextPrimaryDark,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // =====================================================================
        // SECTION 1: COMPANY PROFILES (ASCEND & AUREA)
        // =====================================================================
        if (activeSectionTab == 0) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(AscendGold.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Business, contentDescription = null, tint = AscendGold, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "COMPANY PROFILES & BRANDING",
                                color = AscendGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "Ascend Commercial & Aurea Living Settings",
                                color = TextPrimaryDark,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Company Selector Pills
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selectedCompanyIndex == 0) AscendGold else BrandCharcoalSurface)
                                .border(0.8.dp, AscendGold, RoundedCornerShape(8.dp))
                                .clickable { selectedCompanyIndex = 0 }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Commercial",
                                color = if (selectedCompanyIndex == 0) BrandCharcoalDark else TextPrimaryDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selectedCompanyIndex == 1) AscendGold else BrandCharcoalSurface)
                                .border(0.8.dp, AscendGold, RoundedCornerShape(8.dp))
                                .clickable { selectedCompanyIndex = 1 }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Residential",
                                color = if (selectedCompanyIndex == 1) BrandCharcoalDark else TextPrimaryDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (selectedCompanyIndex == 0) {
                        // ASCEND COMMERCIAL FORM
                        OutlinedTextField(
                            value = ascendNameInput,
                            onValueChange = { ascendNameInput = it },
                            label = { Text("Company Name", color = TextSecondaryDark, fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = ascendContact1Input,
                                onValueChange = { ascendContact1Input = it },
                                label = { Text("Contact 1", color = TextSecondaryDark, fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = ascendContact2Input,
                                onValueChange = { ascendContact2Input = it },
                                label = { Text("Contact 2", color = TextSecondaryDark, fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = ascendEmailInput,
                            onValueChange = { ascendEmailInput = it },
                            label = { Text("Official Email", color = TextSecondaryDark, fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = ascendAddressInput,
                            onValueChange = { ascendAddressInput = it },
                            label = { Text("Office Address", color = TextSecondaryDark, fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = ascendFooterInput,
                            onValueChange = { ascendFooterInput = it },
                            label = { Text("WhatsApp Marketing Footer", color = TextSecondaryDark, fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 70.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Logo Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BrandLogoView(
                                    brand = Brand.ASCEND_COMMERCIAL,
                                    customLogoUri = brandLogos.ascendLogoUri,
                                    size = 32.dp,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (brandLogos.ascendLogoUri != null) "Custom Logo Uploaded" else "Default Commercial Monogram",
                                    color = TextSecondaryDark,
                                    fontSize = 11.sp
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { ascendLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                    colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Upload Logo", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                if (brandLogos.ascendLogoUri != null) {
                                    OutlinedButton(
                                        onClick = { userSettingsManager.resetAscendLogo() },
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("Reset", fontSize = 10.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                userSettingsManager.updateAscendCompanyProfile(
                                    ascendNameInput, ascendContact1Input, ascendContact2Input,
                                    ascendEmailInput, ascendAddressInput, ascendFooterInput
                                )
                                Toast.makeText(context, "Commercial profile saved permanently!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().height(42.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Commercial Profile", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    } else {
                        // AUREA LIVING FORM
                        OutlinedTextField(
                            value = aureaNameInput,
                            onValueChange = { aureaNameInput = it },
                            label = { Text("Company Name", color = TextSecondaryDark, fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = aureaContact1Input,
                                onValueChange = { aureaContact1Input = it },
                                label = { Text("Contact 1", color = TextSecondaryDark, fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = aureaContact2Input,
                                onValueChange = { aureaContact2Input = it },
                                label = { Text("Contact 2", color = TextSecondaryDark, fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = aureaEmailInput,
                            onValueChange = { aureaEmailInput = it },
                            label = { Text("Official Email", color = TextSecondaryDark, fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = aureaAddressInput,
                            onValueChange = { aureaAddressInput = it },
                            label = { Text("Office Address", color = TextSecondaryDark, fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = aureaFooterInput,
                            onValueChange = { aureaFooterInput = it },
                            label = { Text("WhatsApp Marketing Footer", color = TextSecondaryDark, fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 70.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Logo Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BrandLogoView(
                                    brand = Brand.AUREA_LIVING,
                                    customLogoUri = brandLogos.aureaLogoUri,
                                    size = 32.dp,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (brandLogos.aureaLogoUri != null) "Custom Logo Uploaded" else "Default Residential Monogram",
                                    color = TextSecondaryDark,
                                    fontSize = 11.sp
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { aureaLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                    colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Upload Logo", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                if (brandLogos.aureaLogoUri != null) {
                                    OutlinedButton(
                                        onClick = { userSettingsManager.resetAureaLogo() },
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("Reset", fontSize = 10.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                userSettingsManager.updateAureaCompanyProfile(
                                    aureaNameInput, aureaContact1Input, aureaContact2Input,
                                    aureaEmailInput, aureaAddressInput, aureaFooterInput
                                )
                                Toast.makeText(context, "Residential profile saved permanently!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().height(42.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Residential Profile", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // =====================================================================
        // SECTION 2: USER PROFILE CONFIGURATION
        // =====================================================================
        if (activeSectionTab == 1) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(AscendGold.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (userProfile.profilePhotoUri != null) {
                                    AsyncImage(
                                        model = userProfile.profilePhotoUri,
                                        contentDescription = "User Photo",
                                        modifier = Modifier.fillMaxSize().clip(CircleShape)
                                    )
                                } else {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = AscendGold, modifier = Modifier.size(20.dp))
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "USER PROFILE",
                                    color = AscendGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.8.sp
                                )
                                Text(
                                    text = "Display Identity & Verification Tag",
                                    color = TextPrimaryDark,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { userPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Change Photo", fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = usernameInput,
                        onValueChange = { usernameInput = it },
                        label = { Text("Display Name (Used for Verified By)", color = TextSecondaryDark, fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("settings_username_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = userMobileInput,
                            onValueChange = { userMobileInput = it },
                            label = { Text("Mobile Number", color = TextSecondaryDark, fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = userEmailInput,
                            onValueChange = { userEmailInput = it },
                            label = { Text("Email Address", color = TextSecondaryDark, fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "ROLE (INFORMATIONAL LABEL)",
                        color = TextSecondaryDark,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        UserRole.values().forEach { role ->
                            val isSelected = selectedRole == role
                            val roleColor = when (role) {
                                UserRole.ADMIN -> AscendGold
                                UserRole.BROKER -> Color(0xFF3B82F6)
                                UserRole.OWNER -> Color(0xFF10B981)
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) roleColor.copy(alpha = 0.2f) else BrandCharcoalSurface)
                                    .border(1.dp, if (isSelected) roleColor else BrandCharcoalBorder, RoundedCornerShape(8.dp))
                                    .clickable { selectedRole = role }
                                    .padding(vertical = 8.dp)
                                    .testTag("role_option_${role.label.lowercase()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = role.label,
                                    color = if (isSelected) roleColor else TextSecondaryDark,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(BrandCharcoalSurface)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "ℹ️ Note: Unauthenticated session. Role labels alone are UI indicators and do not enforce server-side access control.",
                            color = TextMutedDark,
                            fontSize = 10.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            userSettingsManager.updateProfile(usernameInput, userMobileInput, userEmailInput, selectedRole)
                            Toast.makeText(context, "User profile saved persistently!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(42.dp).testTag("save_profile_btn")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save User Profile", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // =====================================================================
        // SECTION 3: MASTER GOOGLE SHEET CONNECTION
        // =====================================================================
        if (activeSectionTab == 2) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF3B82F6).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CloudSync, contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "MASTER GOOGLE SHEET INTEGRATION",
                                color = AscendGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "ASCEND_AUREA_MASTER_INVENTORY",
                                color = TextPrimaryDark,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Status Overview Card
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BrandCharcoalSurface)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DetailRow(label = "Spreadsheet Name", value = "ASCEND_AUREA_MASTER_INVENTORY")
                        DetailRow(label = "Connection Status", value = connectionStatus)
                        DetailRow(label = "Last Successful Sync", value = lastSyncTimestamp)
                        DetailRow(label = "Total Active Properties", value = "$totalProps Loaded")
                        DetailRow(label = "Last Diagnostic Error", value = lastDiagnostic?.message ?: "None (All Healthy)")
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val diag = repository.testGoogleSheetConnection()
                                    schemaResult = repository.validateMasterSheetSchema(MASTER_PROPERTY_35_COLUMNS)
                                    showSchemaValidationDialog = true
                                    Toast.makeText(context, diag.message, Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(40.dp)
                        ) {
                            Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test Connection", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val count = repository.syncWithGoogleSheetNow()
                                    Toast.makeText(context, "Synced $count properties with Google Sheet!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.White),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(40.dp)
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sync Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = onOpenMasterSync,
                        border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(38.dp)
                    ) {
                        Icon(Icons.Default.Launch, contentDescription = null, tint = AscendGold, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open Full Sync Portal & Apps Script Code", color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // =====================================================================
        // SECTION 4: VERIFICATION SETTINGS
        // =====================================================================
        if (activeSectionTab == 3) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(StatusAvailable.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = StatusAvailable, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "VERIFICATION & AUDIT SETTINGS",
                                color = AscendGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "Verification Validity Interval",
                                color = TextPrimaryDark,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("Configure Verification Period (Days):", color = TextSecondaryDark, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(15, 30, 45, 60).forEach { days ->
                            val isSelected = validityDays == days
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) AscendGold.copy(alpha = 0.2f) else BrandCharcoalSurface)
                                    .border(1.dp, if (isSelected) AscendGold else BrandCharcoalBorder, RoundedCornerShape(8.dp))
                                    .clickable {
                                        userSettingsManager.updateVerificationValidityDays(days)
                                        Toast.makeText(context, "Verification period set to $days days.", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$days Days",
                                    color = if (isSelected) AscendGold else TextSecondaryDark,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricBox(title = "Total", count = totalProps, color = AscendGold)
                        MetricBox(title = "Current", count = currentProps, color = Color(0xFF10B981))
                        MetricBox(title = "Due", count = dueProps, color = Color(0xFFF59E0B))
                        MetricBox(title = "Pending", count = pendingProps, color = Color(0xFFEF4444))
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { showAuditReportDialog = true },
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandCharcoalSurface, contentColor = AscendGold),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open Verification Audit Report", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // =====================================================================
        // SECTION 5: MEDIA STORAGE SETTINGS
        // =====================================================================
        if (activeSectionTab == 4) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF8B5CF6).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PermMedia, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "MEDIA STORAGE & ASSET SETTINGS",
                                color = AscendGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "Persistent Storage Provider",
                                color = TextPrimaryDark,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BrandCharcoalSurface)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DetailRow(label = "Storage Provider", value = "Internal Disk & Cache Storage")
                        DetailRow(label = "Connection Status", value = "Active & Available")
                        DetailRow(label = "Max Photos / Property", value = "20 Photos (Auto-compressed)")
                        DetailRow(label = "Video Walkthroughs", value = "Supported (MP4 / Web Links)")
                        DetailRow(label = "Storage Error Log", value = "None (0 Errors)")
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(BrandCharcoalSurface)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "🔒 Security: Storage keys are securely handled via build configuration. No secret keys or private credentials are stored in publicly accessible code.",
                            color = TextMutedDark,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // =====================================================================
        // SECTION 6: BACKUP & RESTORE
        // =====================================================================
        if (activeSectionTab == 5) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(AscendGold.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Backup, contentDescription = null, tint = AscendGold, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "BACKUP & RESTORE MANAGEMENT",
                                color = AscendGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "Inventory Snapshot & Recovery",
                                color = TextPrimaryDark,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val snap = repository.createBackupNow(notes = "Manual Backup", userSettingsManager = userSettingsManager)
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Backup JSON", snap.dataJson)
                                clipboard.setPrimaryClip(clip)
                                showBackupDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(42.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Create Backup", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Button(
                            onClick = { showRestoreDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = BrandCharcoalSurface, contentColor = TextPrimaryDark),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).height(42.dp)
                        ) {
                            Icon(Icons.Default.Restore, contentDescription = null, tint = AscendGold, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Restore Backup", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // =====================================================================
        // SECTION 7: SYSTEM INFORMATION
        // =====================================================================
        if (activeSectionTab == 6) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(AscendGold.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = AscendGold, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SYSTEM INFORMATION",
                                color = AscendGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = "Real Runtime Diagnostics",
                                color = TextPrimaryDark,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(BrandCharcoalSurface)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DetailRow(label = "Application Version", value = "12.0.0 (Step 12 Administration)")
                        DetailRow(label = "Database Status", value = "Active (Local JSON DB + Storage)")
                        DetailRow(label = "Master Sheet Connection", value = connectionStatus)
                        DetailRow(label = "Total Active Properties", value = "$totalProps Records")
                        DetailRow(label = "Businesses Supported", value = "Commercial (Ascend) & Residential (Aurea)")
                        DetailRow(label = "Media Storage Status", value = "Active (Persistent Local Disk)")
                        DetailRow(label = "AI Property Search Status", value = "Gemini API Ready")
                        DetailRow(label = "Google Maps Status", value = "Geo Intents & Lat/Lng Enabled")
                    }
                }
            }
        }
    }



    // Schema Validation Dialog
    if (showSchemaValidationDialog && schemaResult != null) {
        val res = schemaResult!!
        AlertDialog(
            onDismissRequest = { showSchemaValidationDialog = false },
            title = { Text("Master Sheet Schema Diagnostic", color = AscendGold, fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(res.detailedMessage, color = TextPrimaryDark, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(res.correctionGuidance, color = TextSecondaryDark, fontSize = 11.sp)
                }
            },
            confirmButton = {
                Button(onClick = { showSchemaValidationDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark)) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            },
            containerColor = BrandCharcoalCard
        )
    }

    // Backup Dialog
    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text("Backup Snapshot Created", color = AscendGold, fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("✅ Backup snapshot saved to system memory and copied to clipboard as JSON format.", color = TextPrimaryDark, fontSize = 12.sp)
                    Text("Includes: $totalProps Master Inventory records, Company Profiles, User Profile, Verification Settings, and Media References.", color = TextSecondaryDark, fontSize = 11.sp)
                }
            },
            confirmButton = {
                Button(onClick = { showBackupDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark)) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            },
            containerColor = BrandCharcoalCard
        )
    }

    // Restore Dialog
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Restore Master Inventory Backup", color = AscendGold, fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select a backup JSON file or paste backup content below:", color = TextSecondaryDark, fontSize = 11.sp)

                    Button(
                        onClick = { backupFilePicker.launch("application/json") },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandCharcoalSurface, contentColor = AscendGold),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().height(40.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pick Backup File from Mobile Storage", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Text("OR PASTE BACKUP JSON:", color = TextMutedDark, fontSize = 9.sp, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = restoreJsonInput,
                        onValueChange = { restoreJsonInput = it },
                        placeholder = { Text("Paste JSON backup string...", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp)
                    )

                    if (restoreStatusText != null) {
                        Text(restoreStatusText ?: "", color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (restoreJsonInput.isNotBlank()) {
                            val (success, msg) = repository.restoreFromBackupJson(restoreJsonInput, userSettingsManager)
                            restoreStatusText = msg
                            if (success) {
                                showRestoreDialog = false
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            }
                        } else {
                            Toast.makeText(context, "Please select or paste backup JSON first.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark)
                ) {
                    Text("Confirm & Restore", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("Cancel", color = TextSecondaryDark)
                }
            },
            containerColor = BrandCharcoalCard
        )
    }

    // Data Quality Audit Report Dialog
    if (showAuditReportDialog) {
        val auditList = activeProperties.filter { getVerificationAgeState(it, validityDays) != VerificationAgeState.CURRENT }
        AlertDialog(
            onDismissRequest = { showAuditReportDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = AscendGold, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Data Quality & Verification Audit", color = AscendGold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 400.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Properties requiring verification (${auditList.size} of $totalProps total active):",
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    if (auditList.isEmpty()) {
                        Text(
                            text = "🎉 All active properties are fully verified and current!",
                            color = Color(0xFF10B981),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        auditList.forEach { prop ->
                            val st = getVerificationAgeState(prop, validityDays)
                            val badgeColor = Color(st.badgeColor)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface),
                                border = androidx.compose.foundation.BorderStroke(1.dp, badgeColor.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text(text = prop.propertyCode, color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(badgeColor.copy(alpha = 0.2f))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(text = st.label, color = badgeColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(text = "${prop.projectName} (${prop.location})", color = TextPrimaryDark, fontSize = 12.sp, maxLines = 1)
                                        Text(text = "Last verified: ${prop.lastVerifiedDateClean.ifBlank { prop.lastVerificationDate }}", color = TextSecondaryDark, fontSize = 10.sp)
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Button(
                                            onClick = {
                                                onVerifyProperty(prop.id)
                                                Toast.makeText(context, "Verified ${prop.propertyCode}", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.White),
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Text("Verify", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                showAuditReportDialog = false
                                                onPropertySelect(prop)
                                            },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AscendGold),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold.copy(alpha = 0.5f)),
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Text("View", fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAuditReportDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark)
                ) {
                    Text("Close", fontWeight = FontWeight.Bold)
                }
            },
            containerColor = BrandCharcoalCard,
            shape = RoundedCornerShape(12.dp)
        )
    }
}

@Composable
fun MetricBox(title: String, count: Int, color: Color) {
    Column(
        modifier = Modifier
            .width(70.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(BrandCharcoalSurface)
            .border(0.8.dp, BrandCharcoalBorder, RoundedCornerShape(8.dp))
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = title, color = TextSecondaryDark, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = count.toString(), color = color, fontSize = 16.sp, fontWeight = FontWeight.Black)
    }
}
