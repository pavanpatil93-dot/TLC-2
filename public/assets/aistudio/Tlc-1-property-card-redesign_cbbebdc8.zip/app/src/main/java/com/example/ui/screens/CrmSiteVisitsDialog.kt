package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private data class CrmVisit(
    val id: String,
    val property: String,
    val date: String,
    val status: String,
    val outcome: String
)

private fun readVisits(context: Context, leadId: String): List<CrmVisit> = runCatching {
    val raw = context.getSharedPreferences("crm_site_visits_v1", Context.MODE_PRIVATE)
        .getString(leadId, "[]") ?: "[]"
    val arr = JSONArray(raw)
    (0 until arr.length()).map { i ->
        val v = arr.getJSONObject(i)
        CrmVisit(v.optString("id"), v.optString("property"), v.optString("date"),
            v.optString("status", "Scheduled"), v.optString("outcome"))
    }
}.getOrDefault(emptyList())

private fun saveVisits(context: Context, leadId: String, visits: List<CrmVisit>) {
    val arr = JSONArray()
    visits.forEach { visit ->
        arr.put(JSONObject().apply {
            put("id", visit.id); put("property", visit.property); put("date", visit.date)
            put("status", visit.status); put("outcome", visit.outcome)
        })
    }
    context.getSharedPreferences("crm_site_visits_v1", Context.MODE_PRIVATE)
        .edit().putString(leadId, arr.toString()).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrmSiteVisitsDialog(leadId: String, clientName: String, onClose: () -> Unit) {
    val context = LocalContext.current
    var visits by remember(leadId) { mutableStateOf(readVisits(context, leadId)) }
    var editing by remember { mutableStateOf<CrmVisit?>(null) }
    var editingOpen by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Site visits • $clientName") },
        text = {
            Column {
                Text("Scheduled: ${visits.count { it.status == "Scheduled" }}  •  Completed: ${visits.count { it.status == "Completed" }}")
                Spacer(Modifier.height(8.dp))
                Button(onClick = { editing = null; editingOpen = true }) { Text("Schedule visit") }
                LazyColumn(Modifier.heightIn(max = 360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(visits, key = { it.id }) { visit ->
                        Card(onClick = { editing = visit; editingOpen = true }) {
                            Column(Modifier.padding(10.dp)) {
                                Text(visit.property, style = MaterialTheme.typography.titleSmall)
                                Text("${visit.date} • ${visit.status}")
                                if (visit.outcome.isNotBlank()) Text(visit.outcome)
                                Text("Tap to edit", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    if (visits.isEmpty()) item { Text("No site visits recorded.") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
    if (editingOpen) {
        var property by remember(editing) { mutableStateOf(editing?.property.orEmpty()) }
        var date by remember(editing) { mutableStateOf(editing?.date.orEmpty()) }
        var status by remember(editing) { mutableStateOf(editing?.status ?: "Scheduled") }
        var outcome by remember(editing) { mutableStateOf(editing?.outcome.orEmpty()) }
        val dateValid = date.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) &&
            runCatching { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                .apply { isLenient = false }.parse(date) != null }.getOrDefault(false)
        AlertDialog(
            onDismissRequest = { editingOpen = false },
            title = { Text(if (editing == null) "Schedule site visit" else "Edit site visit") },
            text = {
                Column(Modifier.heightIn(max = 420.dp)) {
                    OutlinedTextField(property, { property = it }, label = { Text("Property / project") })
                    OutlinedTextField(date, { date = it }, label = { Text("Visit date (YYYY-MM-DD)") })
                    Text("Status", style = MaterialTheme.typography.labelMedium)
                    listOf("Scheduled", "Completed", "Cancelled").forEach { choice ->
                        FilterChip(selected = status == choice, onClick = { status = choice },
                            label = { Text(choice) })
                    }
                    OutlinedTextField(outcome, { outcome = it }, label = { Text("Visit outcome / next step") })
                }
            },
            confirmButton = {
                TextButton(enabled = property.isNotBlank() && dateValid, onClick = {
                    val record = CrmVisit(editing?.id ?: UUID.randomUUID().toString(),
                        property.trim(), date, status, outcome.trim())
                    visits = if (editing == null) visits + record else visits.map {
                        if (it.id == record.id) record else it
                    }
                    saveVisits(context, leadId, visits)
                    editingOpen = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editingOpen = false }) { Text("Cancel") } }
        )
    }
}
