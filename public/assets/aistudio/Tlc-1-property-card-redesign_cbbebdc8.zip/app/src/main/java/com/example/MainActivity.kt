package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SheetsRepository
import com.example.data.UserSettingsManager
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppPortal()
            }
        }
    }
}

@Composable
fun MainAppPortal() {
    val context = androidx.compose.ui.platform.LocalContext.current.applicationContext
    val repository = remember(context) { SheetsRepository(context) }
    val userSettingsManager = remember(context) { UserSettingsManager(context) }

    val allProperties by repository.properties.collectAsState()
    val allUnderConstProjects by repository.underConstProjects.collectAsState()
    val favoriteIds by repository.favoriteIds.collectAsState()
    val comparisonIds by repository.comparisonIds.collectAsState()
    val isLiveConnected by repository.isLiveConnected.collectAsState()
    val lastSyncTimestamp by repository.lastSyncTimestamp.collectAsState()

    val userProfile by userSettingsManager.userProfile.collectAsState()
    val brandLogos by userSettingsManager.brandLogos.collectAsState()

    // Navigation and Drawer State
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    var currentDestination by remember { mutableStateOf(DrawerDestination.CRM_WORKSPACE) }
    var crmWorkspaceSelected by remember { mutableStateOf(true) }
    var selectedBrand by remember { mutableStateOf<Brand?>(null) }
    var showUnclassifiedReview by remember { mutableStateOf(false) }

    var isInternalMode by remember { mutableStateOf(true) } // Internal view by default for staff
    var activeDetailProperty by remember { mutableStateOf<PropertyItem?>(null) }
    var activeDetailProject by remember { mutableStateOf<UnderConstProject?>(null) }
    var editingPropertyTarget by remember { mutableStateOf<PropertyItem?>(null) }
    var showComparisonScreen by remember { mutableStateOf(false) }
    var mapTargetProperty by remember { mutableStateOf<PropertyItem?>(null) }
    var clientMatcherInitialRequirement by remember { mutableStateOf<String?>(null) }

    // Dialogs & WhatsApp Sharing
    var showWhatsAppShareDialog by remember { mutableStateOf(false) }
    var shareTargetProperty by remember { mutableStateOf<PropertyItem?>(null) }
    var shareTargetProject by remember { mutableStateOf<UnderConstProject?>(null) }
    var customShareMessage by remember { mutableStateOf<String?>(null) }

    // Real-time counts
    val commercialCount = remember(allProperties) { allProperties.count { it.isCommercial() } }
    val residentialCount = remember(allProperties, allUnderConstProjects) {
        allProperties.count { it.isResidential() } + allUnderConstProjects.size
    }
    val unclassifiedCount = remember(allProperties) { allProperties.count { it.isUnclassified() } }

    // Handle back button for sub-screens & drawer
    BackHandler(
        enabled = drawerState.isOpen ||
                activeDetailProperty != null ||
                activeDetailProject != null ||
                showComparisonScreen ||
                showUnclassifiedReview ||
                currentDestination != DrawerDestination.INVENTORY_DASHBOARD
    ) {
        when {
            drawerState.isOpen -> coroutineScope.launch { drawerState.close() }
            activeDetailProperty != null -> activeDetailProperty = null
            activeDetailProject != null -> activeDetailProject = null
            showComparisonScreen -> showComparisonScreen = false
            showUnclassifiedReview -> showUnclassifiedReview = false
            currentDestination != DrawerDestination.SEARCH_PROPERTIES -> currentDestination = DrawerDestination.SEARCH_PROPERTIES
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            AppDrawerContent(
                currentDestination = currentDestination,
                selectedBrand = selectedBrand,
                brandLogos = brandLogos,
                userProfile = userProfile,
                commercialCount = commercialCount,
                residentialCount = residentialCount,
                comparisonCount = comparisonIds.size,
                savedCount = favoriteIds.size,
                unclassifiedCount = unclassifiedCount,
                onNavigate = { destination ->
                    currentDestination = destination
                    when (destination) {
                        DrawerDestination.CRM_WORKSPACE -> crmWorkspaceSelected = true
                        DrawerDestination.SEARCH_PROPERTIES, DrawerDestination.INVENTORY_DASHBOARD,
                        DrawerDestination.ASCEND_COMMERCIAL, DrawerDestination.AUREA_RESIDENTIAL,
                        DrawerDestination.ADD_PROPERTY, DrawerDestination.SAVED_PROPERTIES,
                        DrawerDestination.COMPARE_PROPERTIES, DrawerDestination.MASTER_SYNC,
                        DrawerDestination.AI_SEARCH, DrawerDestination.FIND_ON_MAP -> crmWorkspaceSelected = false
                        else -> Unit
                    }
                    when (destination) {
                        DrawerDestination.ASCEND_COMMERCIAL -> {
                            selectedBrand = Brand.ASCEND_COMMERCIAL
                            showUnclassifiedReview = false
                        }
                        DrawerDestination.AUREA_RESIDENTIAL -> {
                            selectedBrand = Brand.AUREA_LIVING
                            showUnclassifiedReview = false
                        }
                        DrawerDestination.INVENTORY_DASHBOARD -> {
                            selectedBrand = null
                            showUnclassifiedReview = false
                        }
                        DrawerDestination.COMPARE_PROPERTIES -> {
                            showComparisonScreen = true
                        }
                        else -> {
                            showUnclassifiedReview = false
                        }
                    }
                },
                onCloseDrawer = {
                    coroutineScope.launch { drawerState.close() }
                },
                crmMode = crmWorkspaceSelected
            )
        }
    ) {
        Scaffold(
            topBar = {
                if (activeDetailProperty == null && activeDetailProject == null && !showComparisonScreen) {
                    val activeBrand = when (currentDestination) {
                        DrawerDestination.ASCEND_COMMERCIAL -> Brand.ASCEND_COMMERCIAL
                        DrawerDestination.AUREA_RESIDENTIAL -> Brand.AUREA_LIVING
                        else -> selectedBrand
                    }

                    PortalTopBar(
                        selectedBrand = activeBrand,
                        onSelectBrand = { brand ->
                            selectedBrand = brand
                            when (brand) {
                                Brand.ASCEND_COMMERCIAL -> currentDestination = DrawerDestination.ASCEND_COMMERCIAL
                                Brand.AUREA_LIVING -> currentDestination = DrawerDestination.AUREA_RESIDENTIAL
                                null -> currentDestination = DrawerDestination.SEARCH_PROPERTIES
                            }
                            showUnclassifiedReview = false
                        },
                        brandLogos = brandLogos,
                        onOpenDrawer = {
                            coroutineScope.launch { drawerState.open() }
                        },
                        onOpenAddProperty = { currentDestination = DrawerDestination.ADD_PROPERTY },
                        onOpenImport = { currentDestination = DrawerDestination.MASTER_SYNC },
                        comparisonCount = comparisonIds.size,
                        onOpenComparison = { showComparisonScreen = true },
                        onNavigateHome = {
                            currentDestination = DrawerDestination.INVENTORY_DASHBOARD
                            selectedBrand = null
                            showUnclassifiedReview = false
                        }
                    )
                }
            },
            bottomBar = {
                val isDesktop = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 600
                if (!isDesktop && activeDetailProperty == null && activeDetailProject == null && !showComparisonScreen) {
                    val currentTab = when (currentDestination) {
                        DrawerDestination.INVENTORY_DASHBOARD -> PortalNavTab.INVENTORY
                        DrawerDestination.CRM_WORKSPACE -> PortalNavTab.AI_MATCH
                        DrawerDestination.SEARCH_PROPERTIES, DrawerDestination.ASCEND_COMMERCIAL, DrawerDestination.AUREA_RESIDENTIAL -> PortalNavTab.SEARCH
                        DrawerDestination.ADD_PROPERTY -> PortalNavTab.ADD
                        DrawerDestination.CLIENT_MATCHER -> PortalNavTab.AI_MATCH
                        DrawerDestination.SAVED_PROPERTIES -> PortalNavTab.SAVED
                        else -> PortalNavTab.INVENTORY
                    }
                    if (crmWorkspaceSelected) {
                        NavigationBar {
                            NavigationBarItem(
                                selected = currentDestination == DrawerDestination.CRM_WORKSPACE,
                                onClick = { crmWorkspaceSelected = true; currentDestination = DrawerDestination.CRM_WORKSPACE },
                                icon = { Icon(Icons.Default.Groups, contentDescription = null) },
                                label = { Text("Clients") }
                            )
                            NavigationBarItem(
                                selected = currentDestination == DrawerDestination.CRM_CALLS,
                                onClick = { crmWorkspaceSelected = true; currentDestination = DrawerDestination.CRM_CALLS },
                                icon = {
                                    val unlinked = remember { com.example.crm.CrmCallManager.readCalls(context).count { !it.isLinked } }
                                    if (unlinked > 0) {
                                        BadgedBox(badge = { Badge { Text("$unlinked") } }) {
                                            Icon(Icons.Default.Call, contentDescription = null)
                                        }
                                    } else {
                                        Icon(Icons.Default.Call, contentDescription = null)
                                    }
                                },
                                label = { Text("Calls") }
                            )
                            NavigationBarItem(
                                selected = currentDestination == DrawerDestination.CLIENT_MATCHER,
                                onClick = { crmWorkspaceSelected = true; currentDestination = DrawerDestination.CLIENT_MATCHER },
                                icon = { Icon(Icons.Default.PersonSearch, contentDescription = null) },
                                label = { Text("Matches") }
                            )
                            NavigationBarItem(
                                selected = false,
                                onClick = { crmWorkspaceSelected = false; selectedBrand = null; currentDestination = DrawerDestination.SEARCH_PROPERTIES },
                                icon = { Icon(Icons.Default.SwapHoriz, contentDescription = null) },
                                label = { Text("Inventory") }
                            )
                        }
                    } else Column {
                        Row(
                            modifier = Modifier.fillMaxWidth().background(BrandCharcoalDark).padding(horizontal = 12.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { crmWorkspaceSelected = true; currentDestination = DrawerDestination.CRM_WORKSPACE }) {
                                Icon(Icons.Default.SwapHoriz, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Switch to CRM")
                            }
                        }
                        PortalBottomNavBar(
                        selectedTab = currentTab,
                        onTabSelected = { tab ->
                            when (tab) {
                                PortalNavTab.INVENTORY -> {
                                    currentDestination = DrawerDestination.SEARCH_PROPERTIES
                                    selectedBrand = null
                                }
                                PortalNavTab.SEARCH -> {
                                    currentDestination = DrawerDestination.SEARCH_PROPERTIES
                                }
                                PortalNavTab.ADD -> {
                                    currentDestination = DrawerDestination.ADD_PROPERTY
                                }
                                PortalNavTab.AI_MATCH -> {
                                    currentDestination = DrawerDestination.CLIENT_MATCHER
                                }
                                PortalNavTab.SAVED -> {
                                    currentDestination = DrawerDestination.SAVED_PROPERTIES
                                }
                            }
                        },
                        savedCount = favoriteIds.size
                        )
                    }
                }
            },
            containerColor = BrandCharcoalDark,
            contentWindowInsets = WindowInsets(0, 0, 0, 0)
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(BrandCharcoalDark)
            ) {
                when {
                    // Active Property Detail Screen
                    activeDetailProperty != null -> {
                        PropertyDetailScreen(
                            property = activeDetailProperty!!,
                            allProperties = allProperties,
                            isInternalMode = isInternalMode,
                            isFavorite = favoriteIds.contains(activeDetailProperty!!.id),
                            isInComparison = comparisonIds.contains(activeDetailProperty!!.id),
                            onBack = { activeDetailProperty = null },
                            onToggleFavorite = { repository.toggleFavorite(activeDetailProperty!!.id) },
                            onToggleCompare = { repository.toggleCompare(activeDetailProperty!!.id) },
                            onShareWhatsApp = {
                                shareTargetProperty = activeDetailProperty
                                shareTargetProject = null
                                customShareMessage = null
                                showWhatsAppShareDialog = true
                            },
                            onVerifyProperty = {
                                repository.updateVerificationStatus(activeDetailProperty!!.id, VerificationStatus.VERIFIED, userProfile.username)
                                activeDetailProperty = allProperties.find { it.id == activeDetailProperty!!.id }
                            },
                            onStatusChange = { newStatus ->
                                repository.updateAvailability(activeDetailProperty!!.id, newStatus)
                                activeDetailProperty = allProperties.find { it.id == activeDetailProperty!!.id }
                            },
                            onPropertySelect = { selected ->
                                repository.markViewed(selected.id)
                                activeDetailProperty = selected
                            },
                            onEditProperty = {
                                editingPropertyTarget = activeDetailProperty
                            },
                            onDeleteProperty = {
                                val id = activeDetailProperty?.id
                                if (id != null) {
                                    repository.deleteProperty(id)
                                    activeDetailProperty = null
                                    Toast.makeText(context, "Property deleted.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onViewOnMap = { prop ->
                                mapTargetProperty = prop
                                activeDetailProperty = null
                                currentDestination = DrawerDestination.FIND_ON_MAP
                            }
                        )
                    }

                    // Active Project Detail Screen (Under Construction)
                    activeDetailProject != null -> {
                        ProjectDetailScreen(
                            project = activeDetailProject!!,
                            isInternalMode = isInternalMode,
                            onBack = { activeDetailProject = null },
                            onShareWhatsApp = {
                                shareTargetProperty = null
                                shareTargetProject = activeDetailProject
                                customShareMessage = null
                                showWhatsAppShareDialog = true
                            }
                        )
                    }

                    // Comparison Screen Modal
                    showComparisonScreen -> {
                        val compProps = remember(allProperties, comparisonIds) {
                            allProperties.filter { comparisonIds.contains(it.id) }
                        }
                        ComparisonScreen(
                            comparisonProperties = compProps,
                            onRemoveProperty = { repository.toggleCompare(it) },
                            onClearAll = { repository.clearComparison() },
                            onShareComparisonWhatsApp = {
                                if (compProps.isNotEmpty()) {
                                    shareTargetProperty = compProps.first()
                                    shareTargetProject = null
                                    customShareMessage = "Ascend & Aurea Property Comparison:\n" + compProps.joinToString("\n\n") {
                                        "${it.propertyCode}: ${it.projectName} (${it.location}) - ${it.carpetAreaSqFt.toInt()} sq.ft, ₹${CalculationUtils.formatIndianCurrency(it.priceOrRent)}"
                                    }
                                    showWhatsAppShareDialog = true
                                }
                            }
                        )
                    }

                    // Primary Navigation Screens
                    else -> {
                        when (currentDestination) {
                            DrawerDestination.CRM_WORKSPACE -> {
                                CrmFoundationScreen(
                                    inventory = allProperties,
                                    onNavigateToCalls = { currentDestination = DrawerDestination.CRM_CALLS }
                                )
                            }

                            DrawerDestination.CRM_CALLS -> {
                                CrmCallsScreen(
                                    inventory = allProperties,
                                    onAddPropertyToInventory = { newProp ->
                                        repository.addProperty(newProp)
                                    },
                                    onNavigateToClients = { currentDestination = DrawerDestination.CRM_WORKSPACE }
                                )
                            }

                            DrawerDestination.INVENTORY_DASHBOARD -> {
                                DashboardScreen(
                                    properties = allProperties,
                                    underConstProjects = allUnderConstProjects,
                                    initialBrand = selectedBrand,
                                    userProfile = userProfile,
                                    onPropertyClick = { prop ->
                                        repository.markViewed(prop.id)
                                        activeDetailProperty = prop
                                    },
                                    onEditProperty = { prop ->
                                        editingPropertyTarget = prop
                                    },
                                    onVerifyProperty = { id ->
                                        repository.updateVerificationStatus(id, VerificationStatus.VERIFIED, userProfile.username)
                                    },
                                    onOpenMasterSync = {
                                        currentDestination = DrawerDestination.MASTER_SYNC
                                    }
                                )
                            }

                            DrawerDestination.SEARCH_PROPERTIES,
                            DrawerDestination.ASCEND_COMMERCIAL,
                            DrawerDestination.AUREA_RESIDENTIAL -> {
                                val targetBrand = when (currentDestination) {
                                    DrawerDestination.ASCEND_COMMERCIAL -> Brand.ASCEND_COMMERCIAL
                                    DrawerDestination.AUREA_RESIDENTIAL -> Brand.AUREA_LIVING
                                    else -> selectedBrand
                                }

                                ExploreScreen(
                                    properties = allProperties,
                                    selectedBrand = targetBrand,
                                    onSelectBrand = { brand ->
                                        selectedBrand = brand
                                        when (brand) {
                                            Brand.ASCEND_COMMERCIAL -> currentDestination = DrawerDestination.ASCEND_COMMERCIAL
                                            Brand.AUREA_LIVING -> currentDestination = DrawerDestination.AUREA_RESIDENTIAL
                                            null -> currentDestination = DrawerDestination.SEARCH_PROPERTIES
                                        }
                                        showUnclassifiedReview = false
                                    },
                                    isInternalMode = isInternalMode,
                                    favoriteIds = favoriteIds,
                                    comparisonIds = comparisonIds,
                                    onPropertyClick = { prop ->
                                        repository.markViewed(prop.id)
                                        activeDetailProperty = prop
                                    },
                                    onEditProperty = { prop ->
                                        editingPropertyTarget = prop
                                    },
                                    onToggleFavorite = { repository.toggleFavorite(it) },
                                    onToggleCompare = { repository.toggleCompare(it) },
                                    onShareWhatsApp = { prop ->
                                        shareTargetProperty = prop
                                        shareTargetProject = null
                                        customShareMessage = null
                                        showWhatsAppShareDialog = true
                                    },
                                    onStatusChange = { id, st -> repository.updateAvailability(id, st) },
                                    onOpenAddProperty = { currentDestination = DrawerDestination.ADD_PROPERTY },
                                    onOpenImport = { currentDestination = DrawerDestination.MASTER_SYNC },
                                    isLiveConnected = isLiveConnected,
                                    lastSyncTimestamp = lastSyncTimestamp,
                                    showUnclassifiedOnly = showUnclassifiedReview,
                                    onClearUnclassifiedOnly = { showUnclassifiedReview = false }
                                )
                            }

                            DrawerDestination.SAVED_PROPERTIES -> {
                                val savedProperties = remember(allProperties, favoriteIds) {
                                    allProperties.filter { favoriteIds.contains(it.id) }
                                }
                                ExploreScreen(
                                    properties = savedProperties,
                                    selectedBrand = null,
                                    onSelectBrand = { },
                                    isInternalMode = isInternalMode,
                                    favoriteIds = favoriteIds,
                                    comparisonIds = comparisonIds,
                                    onPropertyClick = { prop ->
                                        repository.markViewed(prop.id)
                                        activeDetailProperty = prop
                                    },
                                    onEditProperty = { prop ->
                                        editingPropertyTarget = prop
                                    },
                                    onToggleFavorite = { repository.toggleFavorite(it) },
                                    onToggleCompare = { repository.toggleCompare(it) },
                                    onShareWhatsApp = { prop ->
                                        shareTargetProperty = prop
                                        shareTargetProject = null
                                        customShareMessage = null
                                        showWhatsAppShareDialog = true
                                    },
                                    onStatusChange = { id, st -> repository.updateAvailability(id, st) },
                                    onOpenAddProperty = { currentDestination = DrawerDestination.ADD_PROPERTY },
                                    onOpenImport = { currentDestination = DrawerDestination.MASTER_SYNC },
                                    isLiveConnected = isLiveConnected,
                                    lastSyncTimestamp = lastSyncTimestamp
                                )
                            }

                            DrawerDestination.ADD_PROPERTY -> {
                                AddPropertyScreen(
                                    onSaveProperty = { newProp ->
                                        repository.addProperty(newProp)
                                        currentDestination = DrawerDestination.INVENTORY_DASHBOARD
                                    },
                                    onCheckDuplicates = { code, proj, unit ->
                                        repository.findPotentialDuplicates(code, proj, unit)
                                    },
                                    onGenerateCode = { tab ->
                                        repository.generateNextCode(tab)
                                    },
                                    onCancel = {
                                        currentDestination = DrawerDestination.INVENTORY_DASHBOARD
                                    }
                                )
                            }

                            DrawerDestination.CLIENT_MATCHER -> {
                                ClientMatchScreen(
                                    tenantInventory = allProperties,
                                    isInternalMode = isInternalMode,
                                    initialRequirement = clientMatcherInitialRequirement,
                                    onPropertyClick = { prop ->
                                        activeDetailProperty = prop
                                    },
                                    onShareWhatsApp = { prop ->
                                        shareTargetProperty = prop
                                        shareTargetProject = null
                                        customShareMessage = null
                                        showWhatsAppShareDialog = true
                                    },
                                    onViewMatchesOnMap = { matchedList ->
                                        mapTargetProperty = matchedList.firstOrNull()
                                        currentDestination = DrawerDestination.FIND_ON_MAP
                                    }
                                )
                            }

                            DrawerDestination.AI_SEARCH -> {
                                AiAssistantScreen(
                                    inventory = allProperties,
                                    isInternalMode = isInternalMode,
                                    onSaveNewProperty = { newProp ->
                                        repository.addProperty(newProp)
                                    },
                                    onPropertyClick = { prop ->
                                        activeDetailProperty = prop
                                    },
                                    onShareWhatsApp = { prop ->
                                        shareTargetProperty = prop
                                        shareTargetProject = null
                                        customShareMessage = null
                                        showWhatsAppShareDialog = true
                                    },
                                    onOpenClientMatcher = { reqText ->
                                        clientMatcherInitialRequirement = reqText
                                        currentDestination = DrawerDestination.CLIENT_MATCHER
                                    }
                                )
                            }

                            DrawerDestination.FIND_ON_MAP -> {
                                MapSearchScreen(
                                    allProperties = allProperties,
                                    initialTargetProperty = mapTargetProperty,
                                    initialPortfolio = selectedBrand,
                                    onPropertyClick = { prop ->
                                        activeDetailProperty = prop
                                    },
                                    onShareWhatsApp = { prop ->
                                        shareTargetProperty = prop
                                        shareTargetProject = null
                                        customShareMessage = null
                                        showWhatsAppShareDialog = true
                                    },
                                    onBack = {
                                        currentDestination = DrawerDestination.INVENTORY_DASHBOARD
                                        mapTargetProperty = null
                                    }
                                )
                            }

                            DrawerDestination.COMPARE_PROPERTIES -> {
                                val compProps = remember(allProperties, comparisonIds) {
                                    allProperties.filter { comparisonIds.contains(it.id) }
                                }
                                ComparisonScreen(
                                    comparisonProperties = compProps,
                                    onRemoveProperty = { repository.toggleCompare(it) },
                                    onClearAll = { repository.clearComparison() },
                                    onShareComparisonWhatsApp = {
                                        if (compProps.isNotEmpty()) {
                                            shareTargetProperty = compProps.first()
                                            shareTargetProject = null
                                            customShareMessage = "Real Estate Property Comparison:\n" + compProps.joinToString("\n\n") {
                                                "${it.propertyCode}: ${it.projectName} (${it.location}) - ${it.carpetAreaSqFt.toInt()} sq.ft, ₹${CalculationUtils.formatIndianCurrency(it.priceOrRent)}"
                                            }
                                            showWhatsAppShareDialog = true
                                        }
                                    }
                                )
                            }

                            DrawerDestination.MASTER_SYNC -> {
                                ImportAndSyncScreen(
                                    repository = repository,
                                    onBackToInventory = { currentDestination = DrawerDestination.INVENTORY_DASHBOARD }
                                )
                            }

                            DrawerDestination.SETTINGS -> {
                                SettingsScreen(
                                    userSettingsManager = userSettingsManager,
                                    repository = repository,
                                    properties = allProperties,
                                    onBack = { currentDestination = DrawerDestination.INVENTORY_DASHBOARD },
                                    onOpenMasterSync = { currentDestination = DrawerDestination.MASTER_SYNC },
                                    onPropertySelect = { prop ->
                                        activeDetailProperty = prop
                                    },
                                    onVerifyProperty = { id ->
                                        repository.updateVerificationStatus(id, VerificationStatus.VERIFIED, userProfile.username)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Full Property Editing Dialog
    if (editingPropertyTarget != null) {
        FullEditPropertyDialog(
            property = editingPropertyTarget!!,
            onSave = { updated, auditText ->
                repository.updateProperty(updated, auditText)
                if (activeDetailProperty?.id == updated.id) {
                    activeDetailProperty = updated
                }
                editingPropertyTarget = null
            },
            onDismiss = { editingPropertyTarget = null }
        )
    }

    // WhatsApp Share Dialog
    if (showWhatsAppShareDialog) {
        WhatsAppShareDialog(
            property = shareTargetProperty,
            project = shareTargetProject,
            customMessage = customShareMessage,
            userSettingsManager = userSettingsManager,
            onDismiss = {
                showWhatsAppShareDialog = false
                shareTargetProperty = null
                shareTargetProject = null
                customShareMessage = null
            }
        )
    }
}

@Composable
fun FindPropertiesOnMapComingSoon(onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandCharcoalDark)
            .padding(24.dp)
            .testTag("find_on_map_coming_soon"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(AscendGold.copy(alpha = 0.15f))
                .border(1.5.dp, AscendGold, RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Map, contentDescription = null, tint = AscendGold, modifier = Modifier.size(36.dp))
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = "FIND PROPERTIES ON MAP",
            color = AscendGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Interactive Map Explorer",
            color = TextPrimaryDark,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Map-based geo-cluster discovery for Pune prime commercial & residential corridors (Baner, Kharadi, Hinjewadi, Kalyani Nagar, Viman Nagar) is arriving in the next release.",
            color = TextSecondaryDark,
            fontSize = 12.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 18.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onBack,
            colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.height(40.dp)
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Back to Home Dashboard", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}
