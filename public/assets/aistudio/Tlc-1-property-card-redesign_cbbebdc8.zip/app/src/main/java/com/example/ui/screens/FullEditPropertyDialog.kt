package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun FullEditPropertyDialog(
    property: PropertyItem,
    onSave: (PropertyItem, String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    var project by remember { mutableStateOf(property.projectName) }
    var location by remember { mutableStateOf(property.location) }
    var unitNumber by remember { mutableStateOf(property.unitNumber) }
    var floor by remember { mutableStateOf(property.floor) }
    var carpetArea by remember { mutableStateOf(property.carpetAreaSqFt.toInt().toString()) }
    var builtUpArea by remember { mutableStateOf(property.builtUpAreaSqFt?.toInt()?.toString() ?: "") }
    var priceSale by remember { mutableStateOf(property.priceSale?.toInt()?.toString() ?: if (!property.tab.isRental) property.priceOrRent.toInt().toString() else "") }
    var rent by remember { mutableStateOf(property.rent?.toInt()?.toString() ?: if (property.tab.isRental) property.priceOrRent.toInt().toString() else "") }
    var deposit by remember { mutableStateOf(property.deposit?.toInt()?.toString() ?: "") }
    var roiPercent by remember { mutableStateOf(property.roiPercent?.toString() ?: "") }
    var furnishing by remember { mutableStateOf(property.furnishing) }
    var possession by remember { mutableStateOf(property.possession) }
    var status by remember { mutableStateOf(property.status) }
    var ownerName by remember { mutableStateOf(property.ownerName ?: "") }
    var ownerContact by remember { mutableStateOf(property.ownerContact ?: "") }
    var source by remember { mutableStateOf(property.sourceInfo ?: "") }
    var remarks by remember { mutableStateOf(property.remarks ?: "") }
    var listingLink by remember { mutableStateOf(property.listingLink ?: "") }

    // Photos & Attachments state
    var photosList by remember { mutableStateOf(property.images) }
    var attachmentsList by remember { mutableStateOf(property.attachments) }
    var videoUrlState by remember { mutableStateOf(property.videoUrl) }
    var floorPlanUrlState by remember { mutableStateOf(property.floorPlanUrl) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(16.dp))
                .testTag("full_edit_property_dialog"),
            colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Edit Listing: ${property.propertyCode}", color = TextPrimaryDark, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("Mobile Photo, Camera & Document Upload Supported", color = AscendGold, fontSize = 10.sp)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryDark)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Mobile Photos & Document Upload Component
                com.example.ui.components.PropertyMediaUploadSection(
                    photosList = photosList,
                    onPhotosChange = { photosList = it },
                    attachments = attachmentsList,
                    onAttachmentsChange = { attachmentsList = it },
                    videoUrl = videoUrlState,
                    onVideoUrlChange = { videoUrlState = it },
                    floorPlanUrl = floorPlanUrlState,
                    onFloorPlanUrlChange = { floorPlanUrlState = it }
                )

                Spacer(modifier = Modifier.height(16.dp))


                // Standard Fields
                Text("SPECIFICATIONS & PRICING:", color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))

                EditFieldItem("Project / Building", project) { project = it }
                EditFieldItem("Location", location) { location = it }
                EditFieldItem("Unit / Shop / Office No", unitNumber) { unitNumber = it }
                EditFieldItem("Floor", floor) { floor = it }
                EditFieldItem("Carpet Area (sq.ft)", carpetArea) { carpetArea = it }
                EditFieldItem("Built-up Area (sq.ft)", builtUpArea) { builtUpArea = it }
                EditFieldItem("Monthly Rent (₹)", rent) { rent = it }
                EditFieldItem("Sale / Outright Price (₹)", priceSale) { priceSale = it }
                EditFieldItem("Security Deposit (₹)", deposit) { deposit = it }
                EditFieldItem("ROI %", roiPercent) { roiPercent = it }
                EditFieldItem("Possession", possession) { possession = it }

                Spacer(modifier = Modifier.height(10.dp))
                Text("CONFIDENTIAL INTERNAL DETAILS:", color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))

                EditFieldItem("Owner / Contact Person", ownerName) { ownerName = it }
                EditFieldItem("Contact Number", ownerContact) { ownerContact = it }
                EditFieldItem("Source", source) { source = it }
                EditFieldItem("Remarks", remarks) { remarks = it }
                EditFieldItem("Listing Link", listingLink) { listingLink = it }

                // Availability Status Selector
                Spacer(modifier = Modifier.height(8.dp))
                Text("Availability Status:", color = TextSecondaryDark, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AvailabilityStatus.values().forEach { st ->
                        val isSel = status == st
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSel) AscendGold else BrandCharcoalCard)
                                .clickable { status = st }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(st.label, color = if (isSel) BrandCharcoalDark else TextSecondaryDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Save Changes Button
                Button(
                    onClick = {
                        val carpetVal = carpetArea.toDoubleOrNull() ?: property.carpetAreaSqFt
                        val rentVal = rent.toDoubleOrNull()
                        val saleVal = priceSale.toDoubleOrNull()
                        val primaryPrice = if (property.tab.isRental) (rentVal ?: property.priceOrRent) else (saleVal ?: property.priceOrRent)

                        val changeLog = "Details updated: Carpet=$carpetVal, Price=$primaryPrice, Status=${status.label}"

                        val updated = property.copy(
                            projectName = project.trim(),
                            location = location.trim(),
                            unitNumber = unitNumber.trim(),
                            floor = floor.trim(),
                            carpetAreaSqFt = carpetVal,
                            builtUpAreaSqFt = builtUpArea.toDoubleOrNull(),
                            priceOrRent = primaryPrice,
                            priceSale = saleVal,
                            rent = rentVal,
                            deposit = deposit.toDoubleOrNull(),
                            roiPercent = roiPercent.toDoubleOrNull(),
                            possession = possession.trim(),
                            status = status,
                            ownerName = ownerName.trim(),
                            ownerContact = ownerContact.trim(),
                            sourceInfo = source.trim(),
                            remarks = remarks.trim(),
                            listingLink = listingLink.trim(),
                            images = photosList,
                            attachments = attachmentsList,
                            videoUrl = videoUrlState,
                            floorPlanUrl = floorPlanUrlState
                        )
                        onSave(updated, changeLog)

                        Toast.makeText(context, "Saved changes to ${property.propertyCode}!", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Save & Log Audit Trail", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun EditFieldItem(label: String, value: String, onValueChange: (String) -> Unit) {
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Text(label, color = TextSecondaryDark, fontSize = 10.sp)
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(6.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = BrandCharcoalDark,
                unfocusedContainerColor = BrandCharcoalDark,
                focusedBorderColor = AscendGold,
                unfocusedBorderColor = BrandCharcoalBorder,
                focusedTextColor = TextPrimaryDark,
                unfocusedTextColor = TextPrimaryDark
            ),
            singleLine = true
        )
    }
}
