package com.example.ui.screens

import android.content.Context
import com.example.model.PropertyItem
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.filled.Phone
import com.example.ui.theme.AscendGold
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val crmPipelineStages = listOf(
    "New", "Contacted", "Details Shared", "Exploring Market",
    "Site Visit Pending", "Site Visit Done", "Negotiation", "Closed Won", "Closed Lost"
)

private data class CrmLead(
    val id: String,
    val name: String,
    val phone: String,
    val segment: String,
    val requirement: String,
    val location: String,
    val budget: String,
    val status: String,
    val nextFollowUp: String,
    val notes: String,
    val assignedTo: String = ""
)

private fun CrmLead.toJson() = JSONObject().apply {
    put("id", id); put("name", name); put("phone", phone); put("segment", segment)
    put("requirement", requirement); put("location", location); put("budget", budget)
    put("status", status); put("nextFollowUp", nextFollowUp); put("notes", notes); put("assignedTo", assignedTo)
}

private fun readCrmLeads(context: Context): List<CrmLead> {
    val prefs = context.getSharedPreferences("crm_development_v1", Context.MODE_PRIVATE)
    val raw = prefs.getString("leads", "[]") ?: "[]"
    val array = JSONArray(raw)
    if (array.length() == 0) {
        val defaults = demoCrmLeads()
        saveCrmLeads(context, defaults)
        return defaults
    }
    return runCatching {
        (0 until array.length()).map { index ->
            val item = array.getJSONObject(index)
            CrmLead(
                item.optString("id"), item.optString("name"), item.optString("phone"),
                item.optString("segment", "Commercial"), item.optString("requirement"),
                item.optString("location"), item.optString("budget"),
                item.optString("status", "New"), item.optString("nextFollowUp"),
                item.optString("notes"), item.optString("assignedTo")
            )
        }
    }.getOrDefault(emptyList())
}

internal data class PropertyClientSuggestion(
    val name: String,
    val phone: String,
    val requirement: String,
    val location: String,
    val status: String,
    val reasons: String
)

// Read-only recommendations from local CRM. Never mutate lead data during matching.
internal fun suggestClientsForProperty(context: Context, property: PropertyItem): List<PropertyClientSuggestion> {
    if (property.archiveStatus != com.example.model.ArchiveStatus.ACTIVE ||
        property.status != com.example.model.AvailabilityStatus.AVAILABLE) return emptyList()
    return readCrmLeads(context).mapNotNull { lead ->
        if (lead.status.equals("Closed Lost", true) || lead.status.equals("Closed Won", true)) return@mapNotNull null
        if (property.tab.isCommercial != lead.segment.equals("Commercial", true)) return@mapNotNull null
        val terms = lead.location.split(",", "/", ";", "|").map { it.trim() }.filter { it.length >= 3 }
        if (terms.isEmpty() || terms.none {
            property.location.contains(it, true) || property.projectName.contains(it, true)
        }) return@mapNotNull null
        val request = lead.requirement.lowercase()
        val wantsRent = request.contains("rent") || request.contains("lease")
        val wantsBuy = request.contains("buy") || request.contains("purchase") || request.contains("sale")
        if (wantsRent && !wantsBuy && !property.tab.isRental) return@mapNotNull null
        if (wantsBuy && !wantsRent && property.tab.isRental) return@mapNotNull null
        val type = when {
            request.contains("showroom") -> "showroom"
            request.contains("office") -> "office"
            request.contains("shop") || request.contains("retail") -> "shop"
            request.contains("warehouse") -> "warehouse"
            else -> ""
        }
        if (type.isNotEmpty() && !property.propertyType.contains(type, true) &&
            !(type == "shop" && property.tab.name.startsWith("SHOP")) &&
            !(type == "office" && property.tab.name.startsWith("OFF_"))) return@mapNotNull null
        val bhk = Regex("""(\d+)\s*BHK""", RegexOption.IGNORE_CASE).find(lead.requirement)?.groupValues?.getOrNull(1)
        if (bhk != null && property.bhk?.contains(bhk) != true) return@mapNotNull null
        PropertyClientSuggestion(
            lead.name, lead.phone, lead.requirement, lead.location, lead.status,
            "Location • Business" + (if (type.isNotBlank()) " • Property type" else "") +
                (if (wantsRent || wantsBuy) " • Transaction" else "") +
                (if (bhk != null) " • BHK" else "")
        )
    }.sortedBy {
        when (it.status.lowercase()) {
            "hot" -> 0
            "site visit pending" -> 1
            "details shared" -> 2
            else -> 3
        }
    }.take(15)
}

private fun saveCrmLeads(context: Context, leads: List<CrmLead>) {
    val array = JSONArray()
    leads.forEach { array.put(it.toJson()) }
    context.getSharedPreferences("crm_development_v1", Context.MODE_PRIVATE)
        .edit().putString("leads", array.toString()).apply()
}

// Synthetic records only. Never use real phone numbers or client information in demo mode.
private fun demoCrmLeads(): List<CrmLead> {
    val examples = listOf(
        listOf("Demo - Aarav Shah", "Commercial", "Office lease, 2,000 sq.ft", "Kharadi", "₹1.5 lakh/month", "Hot", "Call about site visit"),
        listOf("Demo - Neha Kulkarni", "Residential", "3 BHK purchase", "Keshav Nagar", "₹1.8 crore", "Warm", "Share project options"),
        listOf("Demo - Rohan Mehta", "Commercial", "Pre-leased shop purchase", "Viman Nagar", "₹2.5 crore", "New", "Discuss ROI expectations"),
        listOf("Demo - Priya Deshmukh", "Residential", "2 BHK purchase", "Kalyani Nagar", "₹1.4 crore", "Hot", "Arrange project visit"),
        listOf("Demo - Kabir Joshi", "Commercial", "Retail shop lease, 400 sq.ft", "Baner", "₹60,000/month", "Warm", "Send shortlist"),
        listOf("Demo - Sana Patil", "Residential", "4 BHK purchase", "Kharadi", "₹3 crore", "New", "Confirm possession preference")
    )
    val formatter = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    val firstNames = listOf("Aarav", "Neha", "Rohan", "Priya", "Kabir", "Sana", "Ishaan", "Meera", "Dev", "Ananya", "Vihaan", "Tara")
    val lastNames = listOf("Shah", "Kulkarni", "Mehta", "Deshmukh", "Joshi", "Patil", "Jain", "Rao", "Kapoor", "Nair")
    val markets = listOf("Kharadi", "Viman Nagar", "Baner", "Keshav Nagar", "Mundhwa", "Hadapsar", "Kalyani Nagar", "Wagholi")
    val requirements = listOf("Office lease, 1,000 sq.ft", "Shop purchase", "Pre-leased office purchase", "3 BHK purchase", "2 BHK purchase", "Retail shop lease, 500 sq.ft")
    val allExamples = (0 until 120).map { index ->
        val residential = index % 3 == 0
        listOf(
            "Demo - " + firstNames[index % firstNames.size] + " " + lastNames[(index / firstNames.size) % lastNames.size] + " #" + (index + 1),
            if (residential) "Residential" else "Commercial",
            if (residential) (if (index % 2 == 0) "3 BHK purchase" else "2 BHK purchase") else requirements[index % requirements.size],
            markets[index % markets.size],
            if (residential) "₹1.5 crore" else "₹80,000/month",
            listOf("New", "Warm", "Hot", "Contacted", "Details Shared", "Site Visit Pending")[index % 6],
            "Follow up with fictional sample client"
        )
    }
    return allExamples.mapIndexed { index, fields ->
        val calendar = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, index + 1) }
        CrmLead(
            id = "demo-lead-${index + 1}",
            name = fields[0],
            phone = "0000000000",
            segment = fields[1],
            requirement = fields[2],
            location = fields[3],
            budget = fields[4],
            status = fields[5],
            nextFollowUp = formatter.format(calendar.time),
            notes = "SAMPLE DATA ONLY — ${fields[6]}"
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrmFoundationScreen(
    inventory: List<PropertyItem> = emptyList(),
    onNavigateToCalls: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var leads by remember { mutableStateOf(readCrmLeads(context)) }
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    var followUpFilter by remember { mutableStateOf("All dates") }
    var assignedFilter by remember { mutableStateOf("All team") }
    var pipelineFilter by remember { mutableStateOf("All stages") }
    var editing by remember { mutableStateOf<CrmLead?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var profileLead by remember { mutableStateOf<CrmLead?>(null) }
    var visitLead by remember { mutableStateOf<CrmLead?>(null) }
    var matchLead by remember { mutableStateOf<CrmLead?>(null) }
    val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    val overdue = leads.count { it.nextFollowUp.isNotBlank() && it.nextFollowUp < today }
    val dueToday = leads.count { it.nextFollowUp == today }
    val upcoming = leads.count { it.nextFollowUp > today }
    val teamMembers = leads.map { it.assignedTo.trim() }.filter { it.isNotBlank() }.distinct().sorted()
    val filtered = leads.filter {
        (filter == "All" || it.segment == filter) &&
            (pipelineFilter == "All stages" || it.status == pipelineFilter) &&
            (assignedFilter == "All team" || (assignedFilter == "Unassigned" && it.assignedTo.isBlank()) || it.assignedTo == assignedFilter) &&
            (when (followUpFilter) {
                "Overdue" -> it.nextFollowUp.isNotBlank() && it.nextFollowUp < today
                "Today" -> it.nextFollowUp == today
                "Upcoming" -> it.nextFollowUp > today
                else -> true
            }) &&
            (search.isBlank() || listOf(it.name, it.phone, it.location, it.requirement)
                .any { value -> value.contains(search, ignoreCase = true) })
    }

    val priorityLeads = leads.filter { lead ->
        lead.status.equals("Hot", ignoreCase = true) ||
            (lead.nextFollowUp.isNotBlank() && lead.nextFollowUp <= today)
    }.sortedWith(
        compareBy<CrmLead> {
            when {
                it.nextFollowUp.isNotBlank() && it.nextFollowUp < today -> 0
                it.nextFollowUp == today -> 1
                it.status.equals("Hot", ignoreCase = true) -> 2
                else -> 3
            }
        }.thenBy { it.nextFollowUp.ifBlank { "9999-12-31" } }
    )
    var showAllLeads by remember { mutableStateOf(false) }
    var showAdvancedFilters by remember { mutableStateOf(false) }
    var showDemoTools by remember { mutableStateOf(false) }
    val displayedLeads = if (showAllLeads) filtered else filtered.filter { candidate ->
        priorityLeads.any { it.id == candidate.id }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Today's Work", style = MaterialTheme.typography.headlineSmall)
        Text("Prioritize calls, site visits and next actions before browsing the pipeline.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))

        val unlinkedCallsCount = remember { com.example.crm.CrmCallManager.readCalls(context).count { !it.isLinked } }
        if (unlinkedCallsCount > 0 && onNavigateToCalls != null) {
            Card(
                onClick = onNavigateToCalls,
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFFFFBEB)),
                border = androidx.compose.foundation.BorderStroke(0.8.dp, androidx.compose.ui.graphics.Color(0xFFFDE68A)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = null,
                            tint = androidx.compose.ui.graphics.Color(0xFFD97706),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "$unlinkedCallsCount Unlinked Calls awaiting opportunity conversion",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = androidx.compose.ui.graphics.Color(0xFFB45309)
                        )
                    }
                    Text("View Calls", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AscendGold)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Metric("Overdue", overdue.toString(), Modifier.weight(1f))
            Metric("Due today", dueToday.toString(), Modifier.weight(1f))
            Metric("Hot", leads.count { it.status.equals("Hot", true) }.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Text("Needs attention: ${priorityLeads.size}", style = MaterialTheme.typography.titleMedium)
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(priorityLeads.take(8), key = { it.id }) { lead ->
                Card(
                    onClick = { profileLead = lead },
                    modifier = Modifier.width(238.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(lead.name, style = MaterialTheme.typography.titleMedium)
                        Text(lead.status + " • " + lead.segment)
                        Text(lead.requirement, maxLines = 2)
                        Text(if (lead.nextFollowUp.isBlank()) "Hot lead: contact needed"
                            else if (lead.nextFollowUp < today) "OVERDUE: " + lead.nextFollowUp
                            else if (lead.nextFollowUp == today) "DUE TODAY"
                            else "Follow-up: " + lead.nextFollowUp)
                        Text("Owner: " + lead.assignedTo.ifBlank { "Unassigned" })
                    }
                }
            }
        }
        if (priorityLeads.isEmpty()) {
            Text("No hot clients or follow-ups due today. Select All clients to browse the pipeline.")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !showAllLeads, onClick = { showAllLeads = false },
                label = { Text("Today's priorities") })
            FilterChip(selected = showAllLeads, onClick = { showAllLeads = true },
                label = { Text("All clients (${leads.size})") })
        }

        Text("CRM data is stored on this device and is not synchronized.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { editing = null; showEditor = true }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Add Lead")
            }
            OutlinedButton(onClick = { showAllLeads = true; followUpFilter = "Today" }) {
                Text("Due Today")
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = search, onValueChange = { search = it },
            label = { Text("Search leads") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("All", "Commercial", "Residential").forEach { option ->
                FilterChip(selected = filter == option, onClick = { filter = option },
                    label = { Text(option) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("All dates", "Overdue", "Today", "Upcoming").forEach { option ->
                FilterChip(selected = followUpFilter == option,
                    onClick = { followUpFilter = option },
                    label = { Text(option) })
            }
        }
        TextButton(onClick = { showAdvancedFilters = !showAdvancedFilters }) {
            Spacer(Modifier.width(6.dp))
            Text(if (showAdvancedFilters) "Hide pipeline & team filters" else "More filters: pipeline & team")
        }
        if (showAdvancedFilters) {
        Text("Lead pipeline", style = MaterialTheme.typography.titleMedium)
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(listOf("All stages") + crmPipelineStages) { stage ->
                FilterChip(
                    selected = pipelineFilter == stage,
                    onClick = { pipelineFilter = stage },
                    label = { Text(if (stage == "All stages") "All stages" else "$stage (${leads.count { it.status == stage }})") }
                )
            }
        }
                Text("Team assignment", style = MaterialTheme.typography.labelMedium)
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(listOf("All team", "Unassigned") + teamMembers) { member ->
                FilterChip(selected = assignedFilter == member, onClick = { assignedFilter = member }, label = { Text(member) })
            }
        }
        }
        TextButton(onClick = { showDemoTools = !showDemoTools }) {
            Text(if (showDemoTools) "Hide sample data tools" else "Sample data tools")
        }
        if (showDemoTools) {
        if (leads.none { it.id.startsWith("demo-lead-") }) {
            OutlinedButton(onClick = {
                val existingIds = leads.map { it.id }.toSet()
                leads = leads + demoCrmLeads().filterNot { it.id in existingIds }
                saveCrmLeads(context, leads)
            }) { Text("Load 120 demo enquiries") }
        } else {
            TextButton(onClick = {
                leads = leads.filterNot { it.id.startsWith("demo-lead-") }
                saveCrmLeads(context, leads)
            }) { Text("Remove demo enquiries") }
        }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(displayedLeads, key = { it.id }) { lead ->
                Card(onClick = { editing = lead; showEditor = true },
                    shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(lead.name, style = MaterialTheme.typography.titleMedium)
                        Text("${lead.segment} • ${lead.status}")
                        Text("Assigned to: ${lead.assignedTo.ifBlank { "Unassigned" }}")
                        Text(lead.phone)
                        if (lead.requirement.isNotBlank()) Text(lead.requirement)
                        if (lead.location.isNotBlank()) Text("Location: ${lead.location}")
                        if (lead.nextFollowUp.isNotBlank()) {
                            val dueLabel = when {
                                lead.nextFollowUp < today -> "Overdue"
                                lead.nextFollowUp == today -> "Today"
                                else -> "Upcoming"
                            }
                            Text("Follow-up: ${lead.nextFollowUp} • $dueLabel")
                        }
                        TextButton(onClick = { profileLead = lead }) { Text("Client profile • Requirements • Activity") }
                        TextButton(onClick = { visitLead = lead }) { Text("Site visits") }
                        TextButton(onClick = { matchLead = lead }) { Text("Find matching properties") }
                    }
                }
            }
            if (displayedLeads.isEmpty()) item { Text("No clients in this view. Try All clients or adjust filters.") }
        }
    }
    matchLead?.let { selected ->
        CrmInventoryMatchesDialog(selected.segment, selected.requirement, selected.location, inventory) { matchLead = null }
    }
    visitLead?.let { selected ->
        CrmSiteVisitsDialog(leadId = selected.id, clientName = selected.name, onClose = { visitLead = null })
    }
    profileLead?.let { selected ->
        CrmClientProfile(leadId = selected.id, clientName = selected.name, onClose = { profileLead = null })
    }
    if (showEditor) {
        CrmLeadEditor(initial = editing, onDismiss = { showEditor = false }, onSave = { lead ->
            leads = if (editing == null) listOf(lead) + leads
                else leads.map { if (it.id == lead.id) lead else it }
            saveCrmLeads(context, leads)
            showEditor = false
        })
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge)
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CrmLeadEditor(
    initial: CrmLead?,
    onDismiss: () -> Unit,
    onSave: (CrmLead) -> Unit
) {
    var name by remember(initial) { mutableStateOf(initial?.name.orEmpty()) }
    var phone by remember(initial) { mutableStateOf(initial?.phone.orEmpty()) }
    var segment by remember(initial) { mutableStateOf(initial?.segment ?: "Commercial") }
    var requirement by remember(initial) { mutableStateOf(initial?.requirement.orEmpty()) }
    var location by remember(initial) { mutableStateOf(initial?.location.orEmpty()) }
    var budget by remember(initial) { mutableStateOf(initial?.budget.orEmpty()) }
    var status by remember(initial) { mutableStateOf(initial?.status ?: "New") }
    var followUp by remember(initial) { mutableStateOf(initial?.nextFollowUp.orEmpty()) }
    var notes by remember(initial) { mutableStateOf(initial?.notes.orEmpty()) }
    var assignedTo by remember(initial) { mutableStateOf(initial?.assignedTo.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add Lead" else "Edit Lead") },
        text = {
            Column {
                Text("Required: client name and phone", style = MaterialTheme.typography.bodySmall)
                Column(Modifier.heightIn(max = 440.dp)) {
                    androidx.compose.foundation.lazy.LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            com.example.crm.ReusableContactPickerField(
                                name = name,
                                onNameChange = { name = it },
                                phone = phone,
                                onPhoneChange = { phone = it },
                                labelPrefix = "Client"
                            )
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Commercial", "Residential").forEach {
                                    FilterChip(selected = segment == it, onClick = { segment = it }, label = { Text(it) })
                                }
                            }
                        }
                        item { OutlinedTextField(requirement, { requirement = it }, label = { Text("Requirement") }) }
                        item { OutlinedTextField(location, { location = it }, label = { Text("Preferred locations") }) }
                        item { OutlinedTextField(budget, { budget = it }, label = { Text("Budget") }) }
                        item {
                            Text("Status", style = MaterialTheme.typography.labelMedium)
                            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items((crmPipelineStages + listOf("Warm", "Hot")).distinct()) { stage ->
                                    FilterChip(selected = status == stage, onClick = { status = stage }, label = { Text(stage) })
                                }
                            }
                        }
                        item { OutlinedTextField(followUp, { followUp = it }, label = { Text("Next follow-up (YYYY-MM-DD)") }) }
                        item { OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }) }
                        item { OutlinedTextField(assignedTo, { assignedTo = it }, label = { Text("Assigned team member (optional)") }) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && phone.isNotBlank(), onClick = {
                onSave(CrmLead(initial?.id ?: UUID.randomUUID().toString(), name.trim(), phone.trim(),
                    segment, requirement.trim(), location.trim(), budget.trim(), status,
                    followUp.trim(), notes.trim(), assignedTo.trim()))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
