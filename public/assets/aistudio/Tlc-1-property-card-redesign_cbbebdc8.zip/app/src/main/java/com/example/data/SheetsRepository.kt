package com.example.data

import android.content.Context
import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class SheetsRepository(private val context: Context? = null) {

    private val _properties = MutableStateFlow<List<PropertyItem>>(
        if (context != null) PropertiesLocalDatabase.loadProperties(context) else emptyList()
    )
    val properties: StateFlow<List<PropertyItem>> = _properties.asStateFlow()
    private val httpClient = OkHttpClient()

    private fun persistChanges(candidateList: List<PropertyItem> = _properties.value): Boolean {
        return if (context != null) {
            PropertiesLocalDatabase.saveProperties(context, candidateList)
        } else {
            true
        }
    }

    private val _underConstProjects = MutableStateFlow<List<UnderConstProject>>(emptyList())
    val underConstProjects: StateFlow<List<UnderConstProject>> = _underConstProjects.asStateFlow()

    private val _favoriteIds = MutableStateFlow<Set<String>>(emptySet())
    val favoriteIds: StateFlow<Set<String>> = _favoriteIds.asStateFlow()

    private val _comparisonIds = MutableStateFlow<List<String>>(emptyList())
    val comparisonIds: StateFlow<List<String>> = _comparisonIds.asStateFlow()

    private val _backups = MutableStateFlow<List<BackupSnapshot>>(emptyList())
    val backups: StateFlow<List<BackupSnapshot>> = _backups.asStateFlow()

    companion object {
        const val DEFAULT_MASTER_SHEET_URL = ""
    }

    private val _sheetsScriptUrl = MutableStateFlow<String>("")
    val sheetsScriptUrl: StateFlow<String> = _sheetsScriptUrl.asStateFlow()

    private val _isLiveConnected = MutableStateFlow<Boolean>(false)
    val isLiveConnected: StateFlow<Boolean> = _isLiveConnected.asStateFlow()

    private val _connectionStatus = MutableStateFlow<String>("Not Connected - Ready for Google Sheet Setup")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private val _lastSyncTimestamp = MutableStateFlow<String>("Never")
    val lastSyncTimestamp: StateFlow<String> = _lastSyncTimestamp.asStateFlow()

    data class ConnectionDiagnostic(
        val isSuccess: Boolean,
        val readStatus: String,
        val writeStatus: String,
        val latencyMs: Long,
        val recordsCount: Int,
        val message: String,
        val checkedAt: String
    )

    private val _lastDiagnostic = MutableStateFlow<ConnectionDiagnostic?>(null)
    val lastDiagnostic: StateFlow<ConnectionDiagnostic?> = _lastDiagnostic.asStateFlow()

    private val _syncLogs = MutableStateFlow<List<SyncLogEntry>>(emptyList())
    val syncLogs: StateFlow<List<SyncLogEntry>> = _syncLogs.asStateFlow()

    private val _dataReviewQueue = MutableStateFlow<List<DataReviewRow>>(emptyList())
    val dataReviewQueue: StateFlow<List<DataReviewRow>> = _dataReviewQueue.asStateFlow()

    fun logSyncEvent(direction: String, status: String, recordCount: Int, details: String, triggeredBy: String = "User") {
        val entry = SyncLogEntry(
            timestamp = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.ENGLISH).format(Date()),
            direction = direction,
            status = status,
            recordCount = recordCount,
            details = details,
            triggeredBy = triggeredBy
        )
        _syncLogs.value = listOf(entry) + _syncLogs.value.take(49)
    }

    fun addReviewRow(sourceFile: String, rowNumber: Int, rawData: String, issueReason: String, suggestedCode: String? = null) {
        val row = DataReviewRow(
            sourceFile = sourceFile,
            rowNumber = rowNumber,
            rawData = rawData,
            issueReason = issueReason,
            suggestedCode = suggestedCode,
            createdAt = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date())
        )
        _dataReviewQueue.value = listOf(row) + _dataReviewQueue.value
    }

    fun dismissReviewRow(reviewId: String) {
        _dataReviewQueue.value = _dataReviewQueue.value.filter { it.reviewId != reviewId }
    }

    fun clearAllReviewRows() {
        _dataReviewQueue.value = emptyList()
    }

    fun clearSyncLogs() {
        _syncLogs.value = emptyList()
    }

    private val repoScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    init {
        if (context != null) {
            val prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            val savedUrl = prefs.getString("google_sheet_url", "") ?: ""
            _sheetsScriptUrl.value = savedUrl
            _isLiveConnected.value = savedUrl.isNotBlank()
            _connectionStatus.value = if (savedUrl.isNotBlank()) "Live Sheet Connected" else "Not Connected - Ready for Google Sheet Setup"
        }

        // Auto-sync Master Sheet on startup only when valid URL configured
        repoScope.launch {
            if (_sheetsScriptUrl.value.isNotBlank()) {
                try {
                    syncWithGoogleSheetNow()
                } catch (_: Exception) {}
            }
        }

        // Automatic Background Polling Loop: Auto-syncs Google Sheet every 60 seconds
        repoScope.launch {
            while (isActive) {
                if (_isLiveConnected.value && _sheetsScriptUrl.value.isNotBlank()) {
                    try {
                        syncWithGoogleSheetNow()
                    } catch (_: Exception) {}
                }
                delay(60000) // 60 seconds ticker
            }
        }
    }

    fun setGoogleSheetUrl(url: String) {
        val trimmed = url.trim()
        _sheetsScriptUrl.value = trimmed
        _isLiveConnected.value = trimmed.isNotBlank()
        if (context != null) {
            val prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("google_sheet_url", trimmed).apply()
        }
        if (trimmed.isNotBlank()) {
            repoScope.launch {
                syncWithGoogleSheetNow()
            }
        }
    }

    suspend fun testGoogleSheetConnection(): ConnectionDiagnostic = withContext(Dispatchers.IO) {
        val rawUrl = _sheetsScriptUrl.value.trim()
        val timestamp = SimpleDateFormat("dd MMM, hh:mm:ss a", Locale.ENGLISH).format(Date())
        if (rawUrl.isBlank()) {
            val result = ConnectionDiagnostic(
                isSuccess = false,
                readStatus = "Failed: No URL set",
                writeStatus = "Not tested",
                latencyMs = 0L,
                recordsCount = 0,
                message = "Please configure a valid Google Sheet or Google Apps Script URL first.",
                checkedAt = timestamp
            )
            _lastDiagnostic.value = result
            return@withContext result
        }

        val startTime = System.currentTimeMillis()
        var readSuccess = false
        var writeSuccess = false
        var recordsParsed = 0
        var diagnosticMessage = ""

        try {
            if (rawUrl.contains("script.google.com")) {
                val responseText = fetchUrlText(rawUrl)
                val latency = System.currentTimeMillis() - startTime
                val trimmed = responseText.trim()
                if (trimmed.startsWith("<!DOCTYPE", ignoreCase = true) || trimmed.startsWith("<html", ignoreCase = true)) {
                    val result = ConnectionDiagnostic(
                        isSuccess = false,
                        readStatus = "Error: Endpoint returned HTML",
                        writeStatus = "Access restricted",
                        latencyMs = latency,
                        recordsCount = 0,
                        message = "Your Google Apps Script Web App is deployed with restricted access. Fix: In Apps Script > Deploy > New Deployment > Web App > Set 'Who has access' to 'Anyone'.",
                        checkedAt = timestamp
                    )
                    _lastDiagnostic.value = result
                    return@withContext result
                }

                val parsedRows = parseAppsScriptJsonData(responseText)
                readSuccess = true
                recordsParsed = parsedRows.size

                try {
                    val pingPayload = JSONObject().apply {
                        put("action", "DIAGNOSTIC_PING")
                        put("timestamp", timestamp)
                        put("appBrand", "Real Estate Inventory")
                    }
                    val (postSuccess, postResp) = sendAppsScriptPost(rawUrl, pingPayload)
                    val postLatency = System.currentTimeMillis() - startTime
                    writeSuccess = postSuccess
                    diagnosticMessage = if (postSuccess) {
                        "Connection verified! Read access verified ($recordsParsed records found). 2-Way Write access verified (${postLatency}ms)."
                    } else {
                        "Read access verified ($recordsParsed records found), but write ping reported: $postResp."
                    }
                } catch (we: Exception) {
                    writeSuccess = false
                    diagnosticMessage = "Read access verified ($recordsParsed records), but write ping reported: ${we.localizedMessage ?: "timeout"}."
                }

                val finalResult = ConnectionDiagnostic(
                    isSuccess = readSuccess,
                    readStatus = if (readSuccess) "Verified (GET OK)" else "Read Failed",
                    writeStatus = if (writeSuccess) "Verified (POST OK)" else "Write Limited",
                    latencyMs = latency,
                    recordsCount = recordsParsed,
                    message = diagnosticMessage,
                    checkedAt = timestamp
                )
                _lastDiagnostic.value = finalResult
                logSyncEvent(
                    direction = "VERIFICATION_TEST",
                    status = if (finalResult.isSuccess) "SUCCESS" else "FAILED",
                    recordCount = finalResult.recordsCount,
                    details = finalResult.message,
                    triggeredBy = "Diagnostics Test"
                )
                return@withContext finalResult

            } else {
                val sheetId = extractSpreadsheetId(rawUrl)
                val testUrl = if (sheetId.isNotBlank()) {
                    "https://docs.google.com/spreadsheets/d/$sheetId/gviz/tq?tqx=out:csv"
                } else rawUrl

                val content = fetchUrlText(testUrl)
                val latency = System.currentTimeMillis() - startTime
                if (content.contains("<!DOCTYPE html>") || content.contains("<html", ignoreCase = true)) {
                    val result = ConnectionDiagnostic(
                        isSuccess = false,
                        readStatus = "Access Denied (HTML returned)",
                        writeStatus = "Read-Only Sheet",
                        latencyMs = latency,
                        recordsCount = 0,
                        message = "Google Sheet requires public sharing. Set sharing to 'Anyone with the link can view'.",
                        checkedAt = timestamp
                    )
                    _lastDiagnostic.value = result
                    logSyncEvent(
                        direction = "VERIFICATION_TEST",
                        status = "FAILED",
                        recordCount = 0,
                        details = result.message,
                        triggeredBy = "Diagnostics Test"
                    )
                    return@withContext result
                }

                val parsed = parseCsvOrTextData(content, "TestSheet")
                recordsParsed = parsed.size

                val finalResult = ConnectionDiagnostic(
                    isSuccess = true,
                    readStatus = "Verified ($recordsParsed records found)",
                    writeStatus = "Read-Only (Direct Google Sheet CSV - Use Apps Script for 2-way write sync)",
                    latencyMs = latency,
                    recordsCount = recordsParsed,
                    message = "Google Sheet is publicly readable! To enable 2-way reverse sync for additions and edits, deploy the included Google Apps Script.",
                    checkedAt = timestamp
                )
                _lastDiagnostic.value = finalResult
                logSyncEvent(
                    direction = "VERIFICATION_TEST",
                    status = "SUCCESS",
                    recordCount = recordsParsed,
                    details = finalResult.message,
                    triggeredBy = "Diagnostics Test"
                )
                return@withContext finalResult
            }

        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - startTime
            val result = ConnectionDiagnostic(
                isSuccess = false,
                readStatus = "Network Error: ${e.localizedMessage ?: "Failed"}",
                writeStatus = "Not reachable",
                latencyMs = latency,
                recordsCount = 0,
                message = "Could not reach endpoint: ${e.localizedMessage}. Check internet connection or sheet URL.",
                checkedAt = timestamp
            )
            _lastDiagnostic.value = result
            logSyncEvent(
                direction = "VERIFICATION_TEST",
                status = "FAILED",
                recordCount = 0,
                details = result.message,
                triggeredBy = "Diagnostics Test"
            )
            return@withContext result
        }
    }

    fun triggerSyncNow(): String {
        var resultMsg = "Initiating Google Sheet Auto-Sync..."
        repoScope.launch {
            resultMsg = syncWithGoogleSheetNow()
        }
        return resultMsg
    }

    suspend fun syncWithGoogleSheetNow(): String = withContext(Dispatchers.IO) {
        val rawUrl = _sheetsScriptUrl.value.trim()

        try {
            _connectionStatus.value = "Syncing with Google Sheet..."
            val allImportRows = mutableListOf<ImportPreviewRow>()

            if (rawUrl.isNotBlank()) {
                if (rawUrl.contains("script.google.com")) {
                    // Google Apps Script JSON Endpoint
                    val jsonText = fetchUrlText(rawUrl)
                    val trimmed = jsonText.trim()
                    if (trimmed.startsWith("<!DOCTYPE", ignoreCase = true) || trimmed.startsWith("<html", ignoreCase = true)) {
                        _connectionStatus.value = "Error: Endpoint returned HTML page"
                        val err = "Sync Failed: Google Apps Script URL returned HTML instead of JSON.\n\n" +
                                "Fix: In Google Apps Script > Deploy > New Deployment > Web App > Set 'Who has access' to 'Anyone'."
                        logSyncEvent("SHEET_TO_APP", "FAILED", 0, err, "Google Sheet Sync")
                        return@withContext err
                    }
                    val parsedRows = parseAppsScriptJsonData(jsonText)
                    allImportRows.addAll(parsedRows)
                } else {
                    // Google Sheet URL or Spreadsheet ID
                    val sheetId = extractSpreadsheetId(rawUrl)
                    if (sheetId.isNotBlank()) {
                        val tabNames = listOf(
                            "MASTER_PROPERTIES", "Master Properties", "Properties", "Master Inventory",
                            "Off Lease", "Office Lease", "Off Out", "Office Outright", "Office Sale",
                            "Shop Lease", "Retail Lease", "Shop Out", "Shop Outright", "Retail Sale",
                            "Pre - Leased", "Pre-Leased", "Pre Leased",
                            "Resi Rent", "Residential Rent", "Resi Resale", "Residential Resale",
                            "Und Const", "Under Construction", "Projects", "Sheet1"
                        )
                        for (tabName in tabNames) {
                            try {
                                val encodedTab = java.net.URLEncoder.encode(tabName, "UTF-8")
                                val csvUrl = "https://docs.google.com/spreadsheets/d/$sheetId/gviz/tq?tqx=out:csv&sheet=$encodedTab"
                                val csvContent = fetchUrlText(csvUrl)
                                if (csvContent.isNotBlank() && !csvContent.contains("<!DOCTYPE html>") && !csvContent.contains("<html", ignoreCase = true)) {
                                    val rows = parseCsvOrTextData(csvContent, tabName)
                                    allImportRows.addAll(rows)
                                }
                            } catch (_: Exception) {}
                        }

                        // Fallback: If tab-based gviz produced no rows, try direct CSV export
                        if (allImportRows.isEmpty()) {
                            try {
                                val exportUrl = "https://docs.google.com/spreadsheets/d/$sheetId/export?format=csv"
                                val csvContent = fetchUrlText(exportUrl)
                                if (csvContent.isNotBlank() && !csvContent.contains("<!DOCTYPE html>") && !csvContent.contains("<html", ignoreCase = true)) {
                                    val rows = parseCsvOrTextData(csvContent, "Google Sheet Master")
                                    allImportRows.addAll(rows)
                                }
                            } catch (_: Exception) {}
                        }
                    } else {
                        // Direct CSV URL
                        val csvContent = fetchUrlText(rawUrl)
                        if (csvContent.isNotBlank() && !csvContent.contains("<!DOCTYPE html>") && !csvContent.contains("<html", ignoreCase = true)) {
                            val rows = parseCsvOrTextData(csvContent, "Google Sheet Import")
                            allImportRows.addAll(rows)
                        }
                    }
                }
            } else {
                _connectionStatus.value = "URL Not Configured"
                val err = "No Master Google Sheet or Web App URL configured.\n\nPlease configure your Google Apps Script Web App URL or Google Sheet URL in the 'Master Sheet Sync' tab to enable live synchronization."
                logSyncEvent("SHEET_TO_APP", "WARNING", 0, err, "Manual Sync")
                return@withContext err
            }

            if (allImportRows.isNotEmpty()) {
                val stats = importRowsDetailed(allImportRows, duplicateHandling = "OVERWRITE")
                val nowStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
                _lastSyncTimestamp.value = nowStr
                _isLiveConnected.value = true
                _connectionStatus.value = "Live Auto-Sync Active (${_properties.value.size} Total Properties)"
                logSyncEvent(
                    direction = "SHEET_TO_APP",
                    status = "SUCCESS",
                    recordCount = stats.recordsFound,
                    details = "Synced from sheet: ${stats.addedCount} added, ${stats.updatedCount} updated, ${stats.skippedCount} skipped",
                    triggeredBy = "Google Sheet Sync"
                )
                return@withContext "Google Sheet Sync Complete!\n\n" +
                        "• Source Records Found: ${stats.recordsFound}\n" +
                        "• New Properties Added: ${stats.addedCount}\n" +
                        "• Existing Properties Updated: ${stats.updatedCount}\n" +
                        "• Duplicates Skipped: ${stats.skippedCount}\n" +
                        "• Failed Records: ${stats.failedCount}\n" +
                        "• Total Active Inventory: ${_properties.value.size} Properties\n" +
                        "• Last Successful Sync: $nowStr"
            } else {
                _connectionStatus.value = "Connected (0 records parsed)"
                logSyncEvent(
                    direction = "SHEET_TO_APP",
                    status = "WARNING",
                    recordCount = 0,
                    details = "Connected to sheet but 0 rows parsed",
                    triggeredBy = "Google Sheet Sync"
                )
                return@withContext "Connected to Google Sheet, but no valid property rows could be parsed.\n\n" +
                        "Ensure sheet sharing permissions are set to 'Anyone with the link can view'."
            }
        } catch (e: Exception) {
            val err = e.localizedMessage ?: "Network Error"
            _connectionStatus.value = "Sync Error: $err"
            logSyncEvent(
                direction = "SHEET_TO_APP",
                status = "FAILED",
                recordCount = 0,
                details = "Sync failed: $err",
                triggeredBy = "Google Sheet Sync"
            )
            return@withContext "Failed to sync Google Sheet: $err\n\nPlease check URL or ensure Apps Script is deployed to 'Anyone'."
        }
    }

    private fun extractSpreadsheetId(url: String): String {
        if (url.contains("/d/")) {
            return url.substringAfter("/d/").substringBefore("/")
        }
        if (!url.contains("http") && url.length in 20..60) {
            return url
        }
        return ""
    }

    private fun fetchUrlText(urlString: String): String {
        var currentUrl = java.net.URL(urlString)
        var conn = currentUrl.openConnection() as java.net.HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 12000
        conn.readTimeout = 12000
        conn.requestMethod = "GET"
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")

        var status = conn.responseCode
        var redirectCount = 0
        while ((status == java.net.HttpURLConnection.HTTP_MOVED_TEMP ||
                status == java.net.HttpURLConnection.HTTP_MOVED_PERM ||
                status == 307 || status == 308) && redirectCount < 5) {
            val newUrl = conn.getHeaderField("Location") ?: break
            currentUrl = java.net.URL(newUrl)
            conn = currentUrl.openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 12000
            conn.readTimeout = 12000
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            status = conn.responseCode
            redirectCount++
        }

        if (status in 200..299) {
            return conn.inputStream.bufferedReader().use { it.readText() }
        } else {
            throw java.io.IOException("HTTP error code $status")
        }
    }

    private fun parseAppsScriptJsonData(jsonString: String): List<ImportPreviewRow> {
        val trimmed = jsonString.trim()
        if (trimmed.startsWith("<!DOCTYPE", ignoreCase = true) || trimmed.startsWith("<html", ignoreCase = true)) {
            throw java.io.IOException("Received HTML response instead of JSON. Ensure your Google Apps Script Web App is deployed with Access set to 'Anyone'.")
        }

        val results = mutableListOf<ImportPreviewRow>()
        try {
            if (trimmed.startsWith("[")) {
                val rootArray = org.json.JSONArray(trimmed)
                val parsedRows = convertJsonArrayToRows(rootArray)
                if (parsedRows.isNotEmpty()) {
                    val worksheet = ParsedWorksheet(sheetName = "Master Inventory", rows = parsedRows)
                    results.addAll(parseWorksheets(listOf(worksheet)))
                }
            } else if (trimmed.startsWith("{")) {
                val root = org.json.JSONObject(trimmed)
                val dataObj = root.optJSONObject("data") ?: root.optJSONObject("properties") ?: root
                val keys = dataObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val sheetArray = dataObj.optJSONArray(key)
                    if (sheetArray != null) {
                        val parsedRows = convertJsonArrayToRows(sheetArray)
                        if (parsedRows.isNotEmpty()) {
                            val worksheet = ParsedWorksheet(sheetName = key, rows = parsedRows)
                            results.addAll(parseWorksheets(listOf(worksheet)))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("SheetsRepository", "Error parsing Apps Script JSON: ${e.message}", e)
        }
        return results
    }

    private fun convertJsonArrayToRows(jsonArray: org.json.JSONArray): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        if (jsonArray.length() == 0) return rows

        val firstItem = jsonArray.opt(0)
        if (firstItem is org.json.JSONArray) {
            for (i in 0 until jsonArray.length()) {
                val arr = jsonArray.optJSONArray(i) ?: continue
                val rowList = mutableListOf<String>()
                for (j in 0 until arr.length()) {
                    rowList.add(arr.optString(j, ""))
                }
                rows.add(rowList)
            }
        } else if (firstItem is org.json.JSONObject) {
            val headers = mutableListOf<String>()
            val keys = firstItem.keys()
            while (keys.hasNext()) {
                headers.add(keys.next())
            }
            rows.add(headers) // Header row

            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.optJSONObject(i) ?: continue
                val rowList = mutableListOf<String>()
                headers.forEach { h ->
                    rowList.add(obj.optString(h, ""))
                }
                rows.add(rowList)
            }
        }
        return rows
    }

    // Favorites & Compare
    fun toggleFavorite(propertyId: String) {
        val cur = _favoriteIds.value.toMutableSet()
        if (cur.contains(propertyId)) cur.remove(propertyId) else cur.add(propertyId)
        _favoriteIds.value = cur
    }

    fun toggleCompare(propertyId: String): Boolean {
        val cur = _comparisonIds.value.toMutableList()
        if (cur.contains(propertyId)) {
            cur.remove(propertyId)
            _comparisonIds.value = cur
            return true
        } else {
            if (cur.size >= 4) return false
            cur.add(propertyId)
            _comparisonIds.value = cur
            return true
        }
    }

    fun clearComparison() {
        _comparisonIds.value = emptyList()
    }

    fun markViewed(propertyId: String) {}

    // Delete Single Property
    fun deleteProperty(propertyId: String): Boolean {
        val initialCount = _properties.value.size
        _properties.value = _properties.value.filter { it.id != propertyId }
        val removed = _properties.value.size < initialCount
        if (removed) {
            persistChanges()
        }
        return removed
    }

    // Delete All Listings & Properties (Start from Scratch)
    fun deleteAllProperties() {
        _properties.value = emptyList()
        _underConstProjects.value = emptyList()
        _favoriteIds.value = emptySet()
        _comparisonIds.value = emptyList()
        if (context != null) {
            PropertiesLocalDatabase.clearAll(context)
        }
    }

    // Add Property — Persists to disk BEFORE updating visible application state; never modifies remote Google Sheet automatically
    fun addProperty(newItem: PropertyItem): Boolean {
        val propertyToSave = newItem.copy(isSyncedToSheet = false)
        val candidateList = listOf(propertyToSave) + _properties.value
        val savedOk = persistChanges(candidateList)
        if (!savedOk) return false
        _properties.value = candidateList
        return true
    }

    // Edit Property with Historical Snapshot for Undo / Restore
    fun updateProperty(updatedItem: PropertyItem, changeSummary: String) {
        val today = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        _properties.value = _properties.value.map { existing ->
            if (existing.id == updatedItem.id) {
                // Save previous snapshot in history
                val snapshot = PropertyItemSnapshot(
                    carpetAreaSqFt = existing.carpetAreaSqFt,
                    builtUpAreaSqFt = existing.builtUpAreaSqFt,
                    priceOrRent = existing.priceOrRent,
                    priceSale = existing.priceSale,
                    rent = existing.rent,
                    deposit = existing.deposit,
                    roiPercent = existing.roiPercent,
                    furnishing = existing.furnishing,
                    possession = existing.possession,
                    status = existing.status,
                    ownerName = existing.ownerName,
                    ownerContact = existing.ownerContact,
                    remarks = existing.remarks
                )
                val historyEntry = PropertyEditHistory(
                    historyId = "hist_${System.currentTimeMillis()}",
                    timestamp = today,
                    summary = changeSummary,
                    snapshot = snapshot
                )
                updatedItem.copy(
                    lastVerificationDate = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date()),
                    editHistory = listOf(historyEntry) + existing.editHistory,
                    isSyncedToSheet = false
                )
            } else existing
        }
        if (!persistChanges(_properties.value)) {
            return
        }
    }

    // Restore previous version from history
    fun restorePropertyHistory(propertyId: String, historyId: String): Boolean {
        var restored = false
        _properties.value = _properties.value.map { prop ->
            if (prop.id == propertyId) {
                val hist = prop.editHistory.find { it.historyId == historyId }
                if (hist != null) {
                    restored = true
                    val snap = hist.snapshot
                    prop.copy(
                        carpetAreaSqFt = snap.carpetAreaSqFt,
                        builtUpAreaSqFt = snap.builtUpAreaSqFt,
                        priceOrRent = snap.priceOrRent,
                        priceSale = snap.priceSale,
                        rent = snap.rent,
                        deposit = snap.deposit,
                        roiPercent = snap.roiPercent,
                        furnishing = snap.furnishing,
                        possession = snap.possession,
                        status = snap.status,
                        ownerName = snap.ownerName,
                        ownerContact = snap.ownerContact,
                        remarks = snap.remarks,
                        lastVerificationDate = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date())
                    )
                } else prop
            } else prop
        }
        if (restored) persistChanges()
        return restored
    }

    fun updateAvailability(propertyId: String, newStatus: AvailabilityStatus) {
        val today = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date())
        _properties.value = _properties.value.map { prop ->
            if (prop.id == propertyId) prop.copy(status = newStatus, lastVerificationDate = today) else prop
        }
        persistChanges()
    }

    fun updateVerificationStatus(propertyId: String, status: VerificationStatus, verifiedBy: String? = null) {
        val today = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date())
        _properties.value = _properties.value.map { prop ->
            if (prop.id == propertyId) {
                prop.copy(
                    verificationStatus = status,
                    lastVerifiedDateClean = today,
                    lastVerificationDate = today,
                    verifiedBy = verifiedBy ?: prop.verifiedBy
                )
            } else prop
        }
        persistChanges()
        if (_isLiveConnected.value) {
            _properties.value.find { it.id == propertyId }?.let { prop ->
                repoScope.launch { reverseSyncToSheet(prop, action = "UPDATE") }
            }
        }
    }

    fun updateArchiveStatus(propertyId: String, status: ArchiveStatus) {
        val today = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date())
        _properties.value = _properties.value.map { prop ->
            if (prop.id == propertyId) prop.copy(archiveStatus = status, lastVerifiedDateClean = today) else prop
        }
        persistChanges()
        if (_isLiveConnected.value) {
            _properties.value.find { it.id == propertyId }?.let { prop ->
                repoScope.launch { reverseSyncToSheet(prop, action = "UPDATE") }
            }
        }
    }

    fun verifyProperty(propertyId: String) {
        val today = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date())
        _properties.value = _properties.value.map { prop ->
            if (prop.id == propertyId) prop.copy(status = AvailabilityStatus.AVAILABLE, lastVerificationDate = today) else prop
        }
        persistChanges()
    }

    // Photo Management
    fun addPropertyPhoto(propertyId: String, photoUrl: String) {
        _properties.value = _properties.value.map { prop ->
            if (prop.id == propertyId) prop.copy(images = prop.images + photoUrl) else prop
        }
        persistChanges()
    }

    fun removePropertyPhoto(propertyId: String, photoIndex: Int) {
        _properties.value = _properties.value.map { prop ->
            if (prop.id == propertyId && photoIndex in prop.images.indices) {
                val list = prop.images.toMutableList()
                list.removeAt(photoIndex)
                prop.copy(images = list)
            } else prop
        }
        persistChanges()
    }

    fun setCoverPhoto(propertyId: String, photoIndex: Int) {
        _properties.value = _properties.value.map { prop ->
            if (prop.id == propertyId && photoIndex in prop.images.indices) {
                val item = prop.images[photoIndex]
                val list = prop.images.toMutableList()
                list.removeAt(photoIndex)
                list.add(0, item)
                prop.copy(images = list)
            } else prop
        }
        persistChanges()
    }

    // Document & Attachment Management
    fun addPropertyAttachment(propertyId: String, attachment: PropertyAttachment) {
        _properties.value = _properties.value.map { prop ->
            if (prop.id == propertyId) {
                prop.copy(attachments = prop.attachments + attachment)
            } else prop
        }
        persistChanges()
    }

    fun removePropertyAttachment(propertyId: String, attachmentId: String) {
        _properties.value = _properties.value.map { prop ->
            if (prop.id == propertyId) {
                prop.copy(attachments = prop.attachments.filter { it.id != attachmentId })
            } else prop
        }
        persistChanges()
    }


    // Header Recognition & Synonym Matching Engine (Step 1 Standard)
    fun recognizeHeader(sourceHeader: String): Pair<String, MappingConfidence> {
        val clean = sourceHeader.trim().lowercase()
            .replace("_", " ")
            .replace("-", " ")
            .replace(".", "")
            .replace(":", "")

        // Exact matches against 35 standard master columns
        MASTER_PROPERTY_35_COLUMNS.firstOrNull { it.lowercase() == clean }?.let {
            return Pair(it, MappingConfidence.EXACT)
        }

        // High Confidence Synonym Dictionary
        return when {
            clean in listOf("pcode", "code", "property code", "prop code", "listing code", "unit code", "flat code", "listing id", "property id", "asset code") ->
                Pair("Property Code", MappingConfidence.HIGH)
            clean in listOf("date", "entry date", "listed date", "created date", "record date", "listing date", "inventory date") ->
                Pair("Date", MappingConfidence.HIGH)
            clean in listOf("location", "locality", "area", "micro market", "city", "place", "address", "site address", "property address") ->
                Pair("Location", MappingConfidence.HIGH)
            clean in listOf("office name", "building name", "project name", "project", "building", "society", "tower", "complex", "commercial building", "property name") ->
                Pair("Project / Building", MappingConfidence.HIGH)
            clean in listOf("unit", "shop", "office no", "unit no", "shop no", "office number", "unit number", "flat no", "suite no", "room no", "door no", "shop / office no") ->
                Pair("Unit / Shop / Office No", MappingConfidence.HIGH)
            clean in listOf("floor", "floor no", "level", "storey", "floor number") ->
                Pair("Floor", MappingConfidence.HIGH)
            clean in listOf("property type", "asset type", "prop type", "category", "commercial/residential", "commercial or residential") ->
                Pair("Property Type", MappingConfidence.HIGH)
            clean in listOf("sub type", "subtype", "configuration", "inventory type", "tab", "deal category") ->
                Pair("Sub Type", MappingConfidence.HIGH)
            clean in listOf("carpet sq ft", "carpet area", "carpet", "usable area", "carpet sqft", "rwa", "net area", "carpet (sq ft)") ->
                Pair("Carpet Area", MappingConfidence.HIGH)
            clean in listOf("built-up area", "built up area", "builtup area", "builtup", "bua", "super built-up", "chargeable area", "saleable area", "built-up (sq ft)") ->
                Pair("Built-up Area", MappingConfidence.HIGH)
            clean in listOf("sale amount", "price / sale", "sale price", "cost", "total cost", "asking price", "expected price", "rate", "sale rate", "outright price") ->
                Pair("Price / Sale", MappingConfidence.HIGH)
            clean in listOf("monthly rental", "rent", "rental", "monthly rent", "lease rent", "asking rent", "rate per month", "rent pm") ->
                Pair("Rent", MappingConfidence.HIGH)
            clean in listOf("deposit", "security deposit", "deposit amount", "dep", "advance", "token deposit") ->
                Pair("Deposit", MappingConfidence.HIGH)
            clean in listOf("roi", "roi %", "yield", "gross yield", "rental yield", "return", "annual yield") ->
                Pair("ROI %", MappingConfidence.HIGH)
            clean in listOf("possession", "possession date", "available from", "possession status", "availability date", "handover") ->
                Pair("Possession", MappingConfidence.HIGH)
            clean in listOf("furnishing", "furnishing status", "fitout", "fitouts", "interior", "furnished status") ->
                Pair("Furnishing", MappingConfidence.HIGH)
            clean in listOf("status", "availability status", "avail status", "occupancy", "current status") ->
                Pair("Status", MappingConfidence.HIGH)
            clean in listOf("owner", "contact person", "owner name", "seller", "landlord", "broker name", "person", "client name", "point of contact") ->
                Pair("Owner / Contact Person", MappingConfidence.HIGH)
            clean in listOf("mobile number", "contact number", "phone", "mobile", "phone number", "cell", "contact no", "telephone", "mobile no") ->
                Pair("Contact Number", MappingConfidence.HIGH)
            clean in listOf("source", "listing source", "lead source", "channel", "broker source", "brokerage") ->
                Pair("Source", MappingConfidence.HIGH)
            clean in listOf("remarks", "description", "details", "comments", "property notes", "notes") ->
                Pair("Remarks", MappingConfidence.HIGH)
            clean in listOf("listing link", "link", "url", "web link", "photos link", "drive link") ->
                Pair("Listing Link", MappingConfidence.HIGH)
            clean in listOf("last updated", "updated at", "update date", "sync date", "audit date") ->
                Pair("Last Updated", MappingConfidence.HIGH)
            clean in listOf("remark", "internal remarks", "agent notes", "private remark", "internal remark", "confidential remark") ->
                Pair("Remark", MappingConfidence.HIGH)
            clean in listOf("portfolio", "brand", "division", "entity", "company") ->
                Pair("Portfolio", MappingConfidence.HIGH)
            clean in listOf("transaction type", "deal type", "trans type", "sale/lease", "transaction") ->
                Pair("Transaction Type", MappingConfidence.HIGH)
            clean in listOf("google maps url", "maps url", "map link", "gmap", "google maps", "location link") ->
                Pair("Google Maps URL", MappingConfidence.HIGH)
            clean in listOf("latitude", "lat") ->
                Pair("Latitude", MappingConfidence.HIGH)
            clean in listOf("longitude", "lng", "long") ->
                Pair("Longitude", MappingConfidence.HIGH)
            clean in listOf("verification status", "verified status", "verification", "audit status") ->
                Pair("Verification Status", MappingConfidence.HIGH)
            clean in listOf("last verified date", "verification date", "verified on", "audit date") ->
                Pair("Last Verified Date", MappingConfidence.HIGH)
            clean in listOf("verified by", "verifier", "audited by", "auditor", "checked by") ->
                Pair("Verified By", MappingConfidence.HIGH)
            clean in listOf("record id", "asset id", "internal id", "system id", "permanent id") ->
                Pair("Record ID", MappingConfidence.HIGH)
            clean in listOf("sync updated at", "synced at", "last sync", "sheet sync time") ->
                Pair("Sync Updated At", MappingConfidence.HIGH)
            clean in listOf("archive status", "archived", "is archived", "active/archived") ->
                Pair("Archive Status", MappingConfidence.HIGH)

            // Medium Confidence Substring heuristics
            clean.contains("carpet") -> Pair("Carpet Area", MappingConfidence.MEDIUM)
            clean.contains("built") -> Pair("Built-up Area", MappingConfidence.MEDIUM)
            clean.contains("sale") || clean.contains("price") -> Pair("Price / Sale", MappingConfidence.MEDIUM)
            clean.contains("rent") -> Pair("Rent", MappingConfidence.MEDIUM)
            clean.contains("phone") || clean.contains("mobile") -> Pair("Contact Number", MappingConfidence.MEDIUM)
            clean.contains("owner") -> Pair("Owner / Contact Person", MappingConfidence.MEDIUM)
            clean.contains("project") || clean.contains("building") -> Pair("Project / Building", MappingConfidence.MEDIUM)
            clean.contains("code") -> Pair("Property Code", MappingConfidence.MEDIUM)
            clean.contains("deposit") -> Pair("Deposit", MappingConfidence.MEDIUM)
            clean.contains("yield") || clean.contains("roi") -> Pair("ROI %", MappingConfidence.MEDIUM)
            clean.contains("furnish") -> Pair("Furnishing", MappingConfidence.MEDIUM)

            // Unmapped Column -> Preserved into Remarks
            else -> Pair("", MappingConfidence.UNMAPPED)
        }
    }

    // Interactive Header Analysis for UI Pre-Commit Review
    fun analyzeHeaders(headers: List<String>, sampleRow: List<String> = emptyList()): List<ColumnMappingItem> {
        return headers.mapIndexed { idx, header ->
            val sample = sampleRow.getOrElse(idx) { "" }
            val (matchedTarget, confidence) = recognizeHeader(header)
            ColumnMappingItem(
                sourceHeader = header,
                targetStandardHeader = matchedTarget,
                sampleValue = sample,
                confidence = confidence,
                isUnmapped = confidence == MappingConfidence.UNMAPPED
            )
        }
    }

    // Commercial Area Loading Calculation (Office: 45%, Shop/Showroom: 50%, Residential: 0%)
    fun calculateCommercialLoading(
        carpet: Double?,
        builtUp: Double?,
        propType: String,
        portfolio: String
    ): Triple<Double, Double, Boolean> {
        val isCommercial = portfolio.contains("Commercial", ignoreCase = true) ||
                propType.contains("Office", ignoreCase = true) ||
                propType.contains("Shop", ignoreCase = true) ||
                propType.contains("Showroom", ignoreCase = true) ||
                propType.contains("Warehouse", ignoreCase = true)

        if (!isCommercial) {
            // Commercial loading percentages must NEVER automatically apply to residential properties
            return Triple(carpet ?: 0.0, builtUp ?: 0.0, false)
        }

        val loadingRatio = when {
            propType.contains("Office", ignoreCase = true) -> 0.45 // 45% default
            propType.contains("Shop", ignoreCase = true) ||
            propType.contains("Showroom", ignoreCase = true) -> 0.50 // 50% default
            else -> 0.45
        }

        var finalCarpet = carpet ?: 0.0
        var finalBuiltUp = builtUp ?: 0.0
        var isEstimated = false

        if (finalCarpet > 0.0 && finalBuiltUp <= 0.0) {
            // Built-up = Carpet * (1 + loading)
            finalBuiltUp = kotlin.math.round(finalCarpet * (1.0 + loadingRatio))
            isEstimated = true
        } else if (finalBuiltUp > 0.0 && finalCarpet <= 0.0) {
            // Carpet = Built-up / (1 + loading)
            finalCarpet = kotlin.math.round(finalBuiltUp / (1.0 + loadingRatio))
            isEstimated = true
        }

        return Triple(finalCarpet, finalBuiltUp, isEstimated)
    }

    // Authoritative 35-Column Property Import Parser
    fun parseCsvOrTextData(
        rawContent: String,
        fileName: String = "Pasted_Spreadsheet.csv",
        customHeaderMapping: Map<String, String>? = null
    ): List<ImportPreviewRow> {
        val existingCodes = _properties.value.map { it.propertyCode.uppercase().trim() }.toSet()
        val lines = rawContent.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()

        val delimiter = if (lines.any { it.contains("\t") }) "\t" else ","
        val previewRows = mutableListOf<ImportPreviewRow>()

        // Check if first row is header
        val firstTokens = lines.first().split(delimiter).map { it.trim().removeSurrounding("\"") }
        val hasHeader = firstTokens.any { header ->
            val (target, conf) = recognizeHeader(header)
            conf != MappingConfidence.UNMAPPED
        }

        val headerColumns = if (hasHeader) firstTokens else emptyList()
        val dataLines = if (hasHeader) lines.drop(1) else lines

        // Pre-compute mapped standard column for each column index
        val columnIndexToStandard = mutableMapOf<Int, String>()
        val unmappedIndices = mutableListOf<Int>()

        if (hasHeader) {
            headerColumns.forEachIndexed { idx, h ->
                val overrideTarget = customHeaderMapping?.get(h)
                if (!overrideTarget.isNullOrBlank()) {
                    columnIndexToStandard[idx] = overrideTarget
                } else {
                    val (target, conf) = recognizeHeader(h)
                    if (conf != MappingConfidence.UNMAPPED && target.isNotBlank()) {
                        columnIndexToStandard[idx] = target
                    } else {
                        unmappedIndices.add(idx)
                    }
                }
            }
        }

        var nextAutoIndex = 1

        dataLines.forEachIndexed { index, line ->
            val cols = line.split(delimiter).map { it.trim().removeSurrounding("\"") }
            if (cols.isNotEmpty() && cols.any { it.isNotBlank() }) {
                var code = ""
                var date = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).format(Date())
                var location = ""
                var projectName = ""
                var unitNumber = ""
                var floor = "Mid Floor"
                var propType = "Office"
                var subType = "Commercial Offices (Lease)"
                var tab = InventoryTab.OFF_LEASE
                var rawCarpet: Double? = null
                var rawBuiltUp: Double? = null
                var priceSale: Double? = null
                var rent: Double? = null
                var deposit: Double? = null
                var roi: Double? = null
                var possession = "Immediate"
                var furnishing = FurnishingType.WARM_SHELL
                var status = AvailabilityStatus.AVAILABLE
                var owner = ""
                var contact = ""
                var source = fileName
                var remarks = ""
                var listingLink = ""
                var lastUpdated = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date())
                var internalRemark = ""
                var portfolio = "Commercial"
                var transType = "Lease"
                var gmapsUrl = ""
                var latitude: Double? = null
                var longitude: Double? = null
                var verifStatus = VerificationStatus.PENDING
                var lastVerifiedDateClean = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date())
                var verifiedBy = ""
                var recordId = ""
                var syncUpdatedAt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
                var archiveStatus = ArchiveStatus.ACTIVE

                val unmappedData = mutableMapOf<String, String>()

                if (hasHeader) {
                    cols.forEachIndexed { colIdx, value ->
                        val target = columnIndexToStandard[colIdx]
                        if (target != null) {
                            when (target) {
                                "Property Code" -> code = value
                                "Date" -> if (value.isNotBlank()) date = value
                                "Location" -> location = value
                                "Project / Building" -> projectName = value
                                "Unit / Shop / Office No" -> unitNumber = value
                                "Floor" -> floor = value
                                "Property Type" -> propType = value
                                "Sub Type" -> {
                                    subType = value
                                    tab = inferTab(value, code)
                                }
                                "Carpet Area" -> rawCarpet = value.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                                "Built-up Area" -> rawBuiltUp = value.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                                "Price / Sale" -> priceSale = value.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                                "Rent" -> rent = value.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                                "Deposit" -> deposit = value.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                                "ROI %" -> roi = value.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                                "Possession" -> possession = value
                                "Furnishing" -> furnishing = parseFurnishing(value)
                                "Status" -> status = parseStatus(value)
                                "Owner / Contact Person" -> owner = value
                                "Contact Number" -> contact = value
                                "Source" -> if (value.isNotBlank()) source = value
                                "Remarks" -> remarks = value
                                "Listing Link" -> listingLink = value
                                "Last Updated" -> if (value.isNotBlank()) lastUpdated = value
                                "Remark" -> internalRemark = value
                                "Portfolio" -> portfolio = StandardPortfolio.fromString(value, tab).label
                                "Transaction Type" -> transType = StandardTransactionType.fromString(value, tab).label
                                "Google Maps URL" -> gmapsUrl = value
                                "Latitude" -> latitude = value.toDoubleOrNull()
                                "Longitude" -> longitude = value.toDoubleOrNull()
                                "Verification Status" -> verifStatus = VerificationStatus.fromString(value)
                                "Last Verified Date" -> if (value.isNotBlank()) lastVerifiedDateClean = value
                                "Verified By" -> verifiedBy = value
                                "Record ID" -> recordId = value
                                "Sync Updated At" -> if (value.isNotBlank()) syncUpdatedAt = value
                                "Archive Status" -> archiveStatus = ArchiveStatus.fromString(value)
                            }
                        } else {
                            // Preserve unmapped column header and value
                            if (colIdx < headerColumns.size && value.isNotBlank()) {
                                unmappedData[headerColumns[colIdx]] = value
                            }
                        }
                    }
                } else {
                    // Positional mapping for standard 35 columns
                    code = cols.getOrElse(0) { "" }
                    date = cols.getOrElse(1) { date }
                    location = cols.getOrElse(2) { "Pune" }
                    projectName = cols.getOrElse(3) { "Project ${index + 1}" }
                    unitNumber = cols.getOrElse(4) { "Unit ${index + 1}" }
                    floor = cols.getOrElse(5) { "Mid Floor" }
                    propType = cols.getOrElse(6) { "Commercial" }
                    subType = cols.getOrElse(7) { "" }
                    tab = inferTab(subType, code)
                    rawCarpet = cols.getOrElse(8) { "" }.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                    rawBuiltUp = cols.getOrElse(9) { "" }.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                    priceSale = cols.getOrElse(10) { "" }.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                    rent = cols.getOrElse(11) { "" }.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                    deposit = cols.getOrElse(12) { "" }.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                    roi = cols.getOrElse(13) { "" }.replace("[^0-9.]".toRegex(), "").toDoubleOrNull()
                    possession = cols.getOrElse(14) { "Immediate" }
                    furnishing = parseFurnishing(cols.getOrElse(15) { "" })
                    status = parseStatus(cols.getOrElse(16) { "" })
                    owner = cols.getOrElse(17) { "" }
                    contact = cols.getOrElse(18) { "" }
                    source = cols.getOrElse(19) { fileName }
                    remarks = cols.getOrElse(20) { "" }
                    listingLink = cols.getOrElse(21) { "" }
                    lastUpdated = cols.getOrElse(22) { lastUpdated }
                    internalRemark = cols.getOrElse(23) { "" }
                    portfolio = cols.getOrElse(24) { if (tab.brand == Brand.AUREA_LIVING) "Residential" else "Commercial" }
                    transType = cols.getOrElse(25) { if (tab.isRental) "Lease" else "Sale" }
                    gmapsUrl = cols.getOrElse(26) { "" }
                    latitude = cols.getOrElse(27) { "" }.toDoubleOrNull()
                    longitude = cols.getOrElse(28) { "" }.toDoubleOrNull()
                    verifStatus = VerificationStatus.fromString(cols.getOrElse(29) { "" })
                    lastVerifiedDateClean = cols.getOrElse(30) { lastVerifiedDateClean }
                    verifiedBy = cols.getOrElse(31) { "" }
                    recordId = cols.getOrElse(32) { "" }
                    syncUpdatedAt = cols.getOrElse(33) { syncUpdatedAt }
                    archiveStatus = ArchiveStatus.fromString(cols.getOrElse(34) { "" })
                }

                // Append all unmapped columns to remarks so zero source info is discarded
                if (unmappedData.isNotEmpty()) {
                    val extraText = "[Extra: " + unmappedData.entries.joinToString("; ") { "${it.key} = ${it.value}" } + "]"
                    remarks = if (remarks.isNotBlank()) "$remarks\n$extraText" else extraText
                }

                // If tab was not inferred from type header, infer from code
                if (tab == InventoryTab.OFF_LEASE) {
                    tab = inferTab(subType, code)
                }

                // Synchronize portfolio with tab if not explicitly set
                if (portfolio.isBlank() || portfolio == "Commercial") {
                    portfolio = if (tab.brand == Brand.AUREA_LIVING) "Residential" else "Commercial"
                }

                // Commercial Area Loading Calculations
                val (carpetArea, builtUpArea, isAreaEstimated) = calculateCommercialLoading(
                    carpet = rawCarpet,
                    builtUp = rawBuiltUp,
                    propType = propType,
                    portfolio = portfolio
                )

                // Price and Rent resolution
                val finalPriceOrRent = when {
                    tab.isRental -> rent ?: (priceSale ?: 0.0)
                    else -> priceSale ?: (rent ?: 0.0)
                }

                // Code Generation if missing
                if (code.isBlank()) {
                    code = generateNextCode(tab)
                }

                // Permanent Record ID (AST-xxxxxx) if missing
                if (recordId.isBlank()) {
                    val codeNumber = code.filter { it.isDigit() }.padStart(6, '0').takeLast(6)
                    recordId = if (codeNumber.isNotBlank() && codeNumber != "000000") "AST-$codeNumber" else "AST-${String.format(Locale.ENGLISH, "%06d", nextAutoIndex++)}"
                }

                // Validate uniqueness and duplicate check
                val isDuplicate = existingCodes.contains(code.uppercase().trim())
                val isLocationValid = location.isNotBlank()
                val isPriceValid = finalPriceOrRent >= 0.0
                val isValid = isLocationValid && isPriceValid

                val valMessage = when {
                    !isLocationValid -> "Missing Location: Sent to DATA_REVIEW"
                    !isPriceValid -> "Invalid Negative Price/Rent: Sent to DATA_REVIEW"
                    isDuplicate -> "Duplicate Property Code detected ($code)"
                    isAreaEstimated -> "Commercial loading applied (${if (propType.contains("Shop", ignoreCase = true)) "50%" else "45%"} Estimated Area)"
                    else -> "Standard 35-Column Record Validated"
                }

                // If invalid or ambiguous, log to DATA_REVIEW queue
                if (!isValid) {
                    addReviewRow(
                        sourceFile = fileName,
                        rowNumber = index + (if (hasHeader) 2 else 1),
                        rawData = line,
                        issueReason = if (!isLocationValid) "MISSING_LOCATION" else "INVALID_PRICE",
                        suggestedCode = code
                    )
                }

                previewRows.add(
                    ImportPreviewRow(
                        rowNumber = index + (if (hasHeader) 2 else 1),
                        propertyCode = code.trim(),
                        projectName = projectName.ifBlank { "Project Unit ${index + 1}" }.trim(),
                        location = location.ifBlank { "Unverified Location" }.trim(),
                        unitNumber = unitNumber.ifBlank { "Unit #${index + 1}" }.trim(),
                        floor = floor.ifBlank { "Mid Floor" },
                        propertyType = StandardPropertyType.fromString(propType).label,
                        tab = tab,
                        carpetAreaSqFt = carpetArea,
                        builtUpAreaSqFt = if (builtUpArea > 0) builtUpArea else null,
                        priceOrRent = finalPriceOrRent,
                        priceSale = if (!tab.isRental) finalPriceOrRent else priceSale,
                        rent = if (tab.isRental) finalPriceOrRent else rent,
                        deposit = deposit ?: if (finalPriceOrRent > 0 && tab.isRental) finalPriceOrRent * 6 else null,
                        roiPercent = roi,
                        possession = possession.ifBlank { "Immediate" },
                        furnishing = furnishing,
                        status = status,
                        ownerName = owner.ifBlank { null },
                        ownerContact = contact.ifBlank { null },
                        sourceInfo = source.ifBlank { fileName },
                        remarks = remarks.ifBlank { null },
                        listingLink = listingLink.ifBlank { null },
                        isDuplicateCode = isDuplicate,
                        isValid = isValid,
                        validationMessage = valMessage,
                        // 11 Appended Columns
                        recordId = recordId,
                        portfolio = portfolio,
                        transactionType = transType,
                        googleMapsUrl = gmapsUrl.ifBlank { null },
                        latitude = latitude,
                        longitude = longitude,
                        verificationStatus = verifStatus,
                        lastVerifiedDateClean = lastVerifiedDateClean,
                        verifiedBy = verifiedBy.ifBlank { null },
                        isAreaEstimated = isAreaEstimated,
                        unmappedColumns = unmappedData,
                        conflictResolution = if (isDuplicate) "REVIEW" else "INSERT"
                    )
                )
            }
        }
        return previewRows
    }

    private fun parseFurnishing(value: String): FurnishingType {
        val v = value.lowercase()
        return when {
            v.contains("plug") || v.contains("full") -> FurnishingType.FULLY_FURNISHED
            v.contains("semi") -> FurnishingType.SEMI_FURNISHED
            v.contains("warm") -> FurnishingType.WARM_SHELL
            v.contains("bare") || v.contains("unfurnish") -> FurnishingType.BARE_SHELL
            else -> FurnishingType.UNFURNISHED
        }
    }

    private fun parseStatus(value: String): AvailabilityStatus {
        val v = value.lowercase()
        return when {
            v.contains("avail") -> AvailabilityStatus.AVAILABLE
            v.contains("sold") || v.contains("leased") || v.contains("not avail") || v.contains("close") -> AvailabilityStatus.NOT_AVAILABLE
            else -> AvailabilityStatus.NOT_CONFIRMED
        }
    }

    private fun inferTab(text: String, code: String): InventoryTab {
        val combined = "$text $code".uppercase()
        return when {
            combined.contains("OFF LEASE") || combined.contains("OFFICE LEASE") || combined.startsWith("OL-") || combined.contains(" OL ") -> InventoryTab.OFF_LEASE
            combined.contains("OFF OUT") || combined.contains("OFFICE SALE") || combined.startsWith("OO-") || combined.contains(" OO ") -> InventoryTab.OFF_OUT
            combined.contains("SHOP LEASE") || combined.contains("RETAIL LEASE") || combined.startsWith("SL-") || combined.contains(" SL ") -> InventoryTab.SHOP_LEASE
            combined.contains("SHOP OUT") || combined.contains("RETAIL SALE") || combined.startsWith("SO-") || combined.contains(" SO ") -> InventoryTab.SHOP_OUT
            combined.contains("PRE - LEASED") || combined.contains("PRE-LEASED") || combined.contains("PRE LEASED") || combined.startsWith("PL-") -> InventoryTab.PRE_LEASED
            combined.contains("RESI RENT") || combined.contains("RESIDENTIAL RENT") || combined.startsWith("RR-") || combined.contains(" RR ") -> InventoryTab.RESI_RENT
            combined.contains("RESI RESALE") || combined.contains("RESIDENTIAL RESALE") || combined.startsWith("RS-") || combined.contains(" RS ") -> InventoryTab.RESI_RESALE
            combined.contains("UND CONST") || combined.contains("UNDER CONST") || combined.startsWith("UC-") || combined.contains(" UC ") -> InventoryTab.UND_CONST
            else -> InventoryTab.OFF_LEASE
        }
    }

    // Comprehensive Master Demo Portfolio covering all 8 tabs
    fun loadLargeMasterDemoPortfolio(): List<ImportPreviewRow> {
        return emptyList()
    }

    // Inventory Import Engine
    fun generateImportPreview(fileName: String, rawContent: String = ""): List<ImportPreviewRow> {
        if (rawContent.isNotBlank()) {
            return parseCsvOrTextData(rawContent, fileName)
        }
        return emptyList()
    }

    data class SyncStats(
        val recordsFound: Int,
        val addedCount: Int,
        val updatedCount: Int,
        val skippedCount: Int,
        val failedCount: Int
    )

    fun importRowsDetailed(rows: List<ImportPreviewRow>, duplicateHandling: String = "OVERWRITE"): SyncStats {
        val today = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).format(Date())
        var addedCount = 0
        var updatedCount = 0
        var skippedCount = 0
        var failedCount = 0
        val currentList = _properties.value.toMutableList()

        rows.forEach { row ->
            if (!row.isValid) {
                failedCount++
                return@forEach
            }

            val idx = currentList.indexOfFirst { it.propertyCode.equals(row.propertyCode.trim(), ignoreCase = true) }
            val isDuplicate = idx >= 0

            if (isDuplicate) {
                when (duplicateHandling) {
                    "OVERWRITE" -> {
                        val existing = currentList[idx]
                        currentList[idx] = existing.copy(
                            projectName = if (row.projectName.isNotBlank()) row.projectName else existing.projectName,
                            location = if (row.location.isNotBlank()) row.location else existing.location,
                            unitNumber = if (row.unitNumber.isNotBlank()) row.unitNumber else existing.unitNumber,
                            floor = if (row.floor.isNotBlank()) row.floor else existing.floor,
                            propertyType = if (row.propertyType.isNotBlank()) row.propertyType else existing.propertyType,
                            tab = row.tab,
                            carpetAreaSqFt = if (row.carpetAreaSqFt > 0) row.carpetAreaSqFt else existing.carpetAreaSqFt,
                            builtUpAreaSqFt = row.builtUpAreaSqFt ?: existing.builtUpAreaSqFt,
                            priceOrRent = if (row.priceOrRent > 0) row.priceOrRent else existing.priceOrRent,
                            priceSale = row.priceSale ?: existing.priceSale,
                            rent = row.rent ?: existing.rent,
                            deposit = row.deposit ?: existing.deposit,
                            roiPercent = row.roiPercent ?: existing.roiPercent,
                            possession = if (row.possession.isNotBlank()) row.possession else existing.possession,
                            furnishing = row.furnishing,
                            status = row.status,
                            ownerName = row.ownerName ?: existing.ownerName,
                            ownerContact = row.ownerContact ?: existing.ownerContact,
                            sourceInfo = row.sourceInfo ?: existing.sourceInfo,
                            remarks = row.remarks ?: existing.remarks,
                            listingLink = row.listingLink ?: existing.listingLink,
                            lastVerificationDate = today,
                            isSyncedToSheet = true,
                            // 11 Appended Columns (25-35)
                            portfolio = row.portfolio,
                            transactionType = row.transactionType,
                            googleMapsUrl = row.googleMapsUrl ?: existing.googleMapsUrl,
                            latitude = row.latitude ?: existing.latitude,
                            longitude = row.longitude ?: existing.longitude,
                            verificationStatus = row.verificationStatus,
                            lastVerifiedDateClean = row.lastVerifiedDateClean,
                            verifiedBy = row.verifiedBy ?: existing.verifiedBy,
                            recordId = if (existing.recordId.isNotBlank()) existing.recordId else row.recordId,
                            syncUpdatedAt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date()),
                            archiveStatus = ArchiveStatus.ACTIVE,
                            isAreaEstimated = row.isAreaEstimated
                        )
                        updatedCount++
                    }
                    "NEW_CODE" -> {
                        val newCode = generateNextCode(row.tab)
                        val codeNumber = newCode.filter { it.isDigit() }.padStart(6, '0').takeLast(6).ifBlank { (100000..999999).random().toString() }
                        val newProp = PropertyItem(
                            id = "prop_imp_${System.currentTimeMillis()}_${row.rowNumber}_${(100..999).random()}",
                            propertyCode = newCode,
                            date = today,
                            location = row.location,
                            projectName = row.projectName,
                            unitNumber = row.unitNumber,
                            floor = row.floor,
                            propertyType = row.propertyType,
                            tab = row.tab,
                            carpetAreaSqFt = row.carpetAreaSqFt,
                            builtUpAreaSqFt = row.builtUpAreaSqFt,
                            priceOrRent = row.priceOrRent,
                            priceSale = row.priceSale,
                            rent = row.rent,
                            deposit = row.deposit,
                            roiPercent = row.roiPercent,
                            possession = row.possession,
                            furnishing = row.furnishing,
                            status = row.status,
                            ownerName = row.ownerName,
                            ownerContact = row.ownerContact,
                            sourceInfo = row.sourceInfo ?: "Master Spreadsheet Import",
                            remarks = row.remarks,
                            listingLink = row.listingLink,
                            isSyncedToSheet = true,
                            lastVerificationDate = today,
                            portfolio = row.portfolio,
                            transactionType = row.transactionType,
                            googleMapsUrl = row.googleMapsUrl,
                            latitude = row.latitude,
                            longitude = row.longitude,
                            verificationStatus = row.verificationStatus,
                            lastVerifiedDateClean = row.lastVerifiedDateClean,
                            verifiedBy = row.verifiedBy,
                            recordId = "AST-$codeNumber",
                            syncUpdatedAt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date()),
                            archiveStatus = ArchiveStatus.ACTIVE,
                            isAreaEstimated = row.isAreaEstimated,
                            images = listOf(
                                if (row.tab.brand == Brand.ASCEND_COMMERCIAL)
                                    "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80"
                                else
                                    "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80"
                            )
                        )
                        currentList.add(0, newProp)
                        addedCount++
                    }
                    else -> {
                        // SKIP duplicate
                        skippedCount++
                    }
                }
            } else {
                val codeNumber = row.propertyCode.filter { it.isDigit() }.padStart(6, '0').takeLast(6).ifBlank { (100000..999999).random().toString() }
                val newProp = PropertyItem(
                    id = "prop_imp_${System.currentTimeMillis()}_${row.rowNumber}_${(100..999).random()}",
                    propertyCode = row.propertyCode,
                    date = today,
                    location = row.location,
                    projectName = row.projectName,
                    unitNumber = row.unitNumber,
                    floor = row.floor,
                    propertyType = row.propertyType,
                    tab = row.tab,
                    carpetAreaSqFt = row.carpetAreaSqFt,
                    builtUpAreaSqFt = row.builtUpAreaSqFt,
                    priceOrRent = row.priceOrRent,
                    priceSale = row.priceSale,
                    rent = row.rent,
                    deposit = row.deposit,
                    roiPercent = row.roiPercent,
                    possession = row.possession,
                    furnishing = row.furnishing,
                    status = row.status,
                    ownerName = row.ownerName,
                    ownerContact = row.ownerContact,
                    sourceInfo = row.sourceInfo ?: "Master Spreadsheet Import",
                    remarks = row.remarks,
                    listingLink = row.listingLink,
                    isSyncedToSheet = true,
                    lastVerificationDate = today,
                    portfolio = row.portfolio,
                    transactionType = row.transactionType,
                    googleMapsUrl = row.googleMapsUrl,
                    latitude = row.latitude,
                    longitude = row.longitude,
                    verificationStatus = row.verificationStatus,
                    lastVerifiedDateClean = row.lastVerifiedDateClean,
                    verifiedBy = row.verifiedBy,
                    recordId = row.recordId.ifBlank { "AST-$codeNumber" },
                    syncUpdatedAt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date()),
                    archiveStatus = ArchiveStatus.ACTIVE,
                    isAreaEstimated = row.isAreaEstimated,
                    images = listOf(
                        if (row.tab.brand == Brand.ASCEND_COMMERCIAL)
                            "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80"
                        else
                            "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80"
                    )
                )
                currentList.add(0, newProp)
                addedCount++
            }
        }
        _properties.value = currentList
        persistChanges()

        logSyncEvent(
            direction = "FILE_IMPORT",
            status = if (failedCount == 0) "SUCCESS" else "WARNING",
            recordCount = addedCount + updatedCount,
            details = "Import completed: $addedCount added, $updatedCount updated, $skippedCount skipped, $failedCount failed",
            triggeredBy = "File Import Engine"
        )

        return SyncStats(
            recordsFound = rows.size,
            addedCount = addedCount,
            updatedCount = updatedCount,
            skippedCount = skippedCount,
            failedCount = failedCount
        )
    }

    data class SafeImportPreview(
        val total: Int,
        val readyToAdd: Int,
        val duplicates: Int,
        val invalid: Int
    )

    /** Read-only preview. Never overwrites existing property codes. */
    fun previewSafeImport(rows: List<ImportPreviewRow>): SafeImportPreview {
        val existing = _properties.value.map { it.propertyCode.trim().uppercase(Locale.ROOT) }.toSet()
        val seen = mutableSetOf<String>()
        var ready = 0
        var duplicates = 0
        var invalid = 0
        rows.forEach { row ->
            val code = row.propertyCode.trim().uppercase(Locale.ROOT)
            when {
                !row.isValid || code.isBlank() -> invalid++
                code in existing || !seen.add(code) -> duplicates++
                else -> ready++
            }
        }
        return SafeImportPreview(rows.size, ready, duplicates, invalid)
    }

    /** Explicit, non-destructive import. Duplicates and blank codes are skipped. */
    fun importSafelySkippingExisting(rows: List<ImportPreviewRow>): SyncStats {
        val existing = _properties.value.map { it.propertyCode.trim().uppercase(Locale.ROOT) }.toSet()
        val seen = mutableSetOf<String>()
        val safeRows = rows.filter { row ->
            val code = row.propertyCode.trim().uppercase(Locale.ROOT)
            row.isValid && code.isNotBlank() && code !in existing && seen.add(code)
        }
        val result = importRowsDetailed(safeRows, duplicateHandling = "SKIP")
        return result.copy(
            recordsFound = rows.size,
            skippedCount = result.skippedCount + (rows.size - safeRows.size)
        )
    }

    fun importRows(rows: List<ImportPreviewRow>, duplicateHandling: String = "SKIP"): Int {
        val stats = importRowsDetailed(rows, duplicateHandling)
        return stats.addedCount + stats.updatedCount
    }

    fun parseWorksheets(
        worksheets: List<ParsedWorksheet>,
        customHeaderMapping: Map<String, String>? = null
    ): List<ImportPreviewRow> {
        val allPreview = mutableListOf<ImportPreviewRow>()
        worksheets.forEach { sheet ->
            val textLines = sheet.rows.map { it.joinToString("\t") }
            val raw = textLines.joinToString("\n")
            val parsed = parseCsvOrTextData(raw, sheet.sheetName, customHeaderMapping)
            allPreview.addAll(parsed)
        }
        return allPreview
    }



    // Duplicate detection
    fun findPotentialDuplicates(propertyCode: String, projectName: String, unitNumber: String, excludeId: String? = null): List<PropertyItem> {
        return _properties.value.filter { item ->
            if (excludeId != null && item.id == excludeId) return@filter false
            val codeMatch = propertyCode.isNotBlank() && item.propertyCode.equals(propertyCode.trim(), ignoreCase = true)
            val unitMatch = projectName.isNotBlank() && unitNumber.isNotBlank() &&
                    item.projectName.equals(projectName.trim(), ignoreCase = true) &&
                    item.unitNumber.equals(unitNumber.trim(), ignoreCase = true)
            codeMatch || unitMatch
        }
    }

    fun generateNextCode(tab: InventoryTab): String {
        val prefix = when (tab) {
            InventoryTab.OFF_LEASE -> "OL"
            InventoryTab.OFF_OUT -> "OO"
            InventoryTab.SHOP_LEASE -> "SL"
            InventoryTab.SHOP_OUT -> "SO"
            InventoryTab.PRE_LEASED -> "PL"
            InventoryTab.RESI_RENT -> "RR"
            InventoryTab.RESI_RESALE -> "RS"
            InventoryTab.UND_CONST -> "UC"
        }
        val num = (100..999).random()
        return "$prefix-PUN-$num"
    }

    // =========================================================================
    // STEP 12: MASTER SHEET SCHEMA VALIDATION, EXPORT, TEMPLATE & BACKUP/RESTORE
    // =========================================================================

    /**
     * Master Google Sheet Schema Validation against 35 Standard Columns
     */
    fun validateMasterSheetSchema(actualHeaders: List<String>): SchemaValidationResult {
        val expected = MASTER_PROPERTY_35_COLUMNS
        val cleanActual = actualHeaders.map { it.trim() }

        val missing = expected.filter { exp -> cleanActual.none { act -> act.equals(exp, ignoreCase = true) } }
        val extra = cleanActual.filter { act -> act.isNotBlank() && expected.none { exp -> exp.equals(act, ignoreCase = true) } }

        val isValid = missing.isEmpty()
        val detailedMsg = if (isValid) {
            "✅ Sheet headers match the approved 35-column Master Inventory schema in correct sequence."
        } else {
            "⚠️ Mismatch detected: Found ${cleanActual.size} columns. Missing ${missing.size} required Master Inventory columns."
        }

        val correctionGuidance = if (missing.isNotEmpty()) {
            "Action Required: Missing headers: ${missing.joinToString(", ")}. Please add these exact headers or download the Standard Template."
        } else {
            "All 35 standard columns are properly present."
        }

        return SchemaValidationResult(
            isValid = isValid,
            totalColumnsFound = cleanActual.size,
            missingColumns = missing,
            extraColumns = extra,
            detailedMessage = detailedMsg,
            correctionGuidance = correctionGuidance
        )
    }

    /**
     * Export Master Inventory CSV with Client vs Internal Distinction & Filters
     */
    fun exportStandardCsv(
        isClientExport: Boolean = false,
        filterType: String = "ALL", // "ALL", "COMMERCIAL", "RESIDENTIAL", "AVAILABLE", "ARCHIVED"
        customList: List<PropertyItem>? = null
    ): String {
        val targetProps = customList ?: when (filterType.uppercase()) {
            "COMMERCIAL" -> _properties.value.filter { it.tab.isCommercial && it.archiveStatus != ArchiveStatus.ARCHIVED }
            "RESIDENTIAL" -> _properties.value.filter { !it.tab.isCommercial && it.archiveStatus != ArchiveStatus.ARCHIVED }
            "AVAILABLE" -> _properties.value.filter { it.status == AvailabilityStatus.AVAILABLE && it.archiveStatus != ArchiveStatus.ARCHIVED }
            "ARCHIVED" -> _properties.value.filter { it.archiveStatus == ArchiveStatus.ARCHIVED }
            else -> _properties.value.filter { it.archiveStatus != ArchiveStatus.ARCHIVED }
        }

        val headers = if (isClientExport) {
            // Client-safe 24 public columns (excludes owner contacts, confidential details, internal remarks)
            listOf(
                "Property Code", "Date", "Location", "Project / Building", "Unit / Shop / Office No",
                "Floor", "Property Type", "Sub Type", "Carpet Area", "Built-up Area",
                "Price / Sale", "Rent", "Deposit", "ROI %", "Possession",
                "Furnishing", "Status", "Source", "Remarks", "Listing Link",
                "Portfolio", "Transaction Type", "Google Maps URL", "Last Verified Date"
            )
        } else {
            MASTER_PROPERTY_35_COLUMNS
        }

        val sb = StringBuilder()
        sb.append(headers.joinToString(",")).append("\n")

        targetProps.forEach { p ->
            val row = if (isClientExport) {
                listOf(
                    p.propertyCode,
                    p.date,
                    "\"${p.location.replace("\"", "\"\"")}\"",
                    "\"${p.projectName.replace("\"", "\"\"")}\"",
                    "\"${p.unitNumber.replace("\"", "\"\"")}\"",
                    p.floor,
                    p.propertyType,
                    p.tab.code,
                    p.carpetAreaSqFt.toInt().toString(),
                    (p.builtUpAreaSqFt?.toInt() ?: "").toString(),
                    (p.priceSale?.toLong() ?: if (!p.tab.isRental) p.priceOrRent.toLong() else "").toString(),
                    (p.rent?.toLong() ?: if (p.tab.isRental) p.priceOrRent.toLong() else "").toString(),
                    (p.deposit?.toLong() ?: "").toString(),
                    (p.roiPercent ?: "").toString(),
                    p.possession,
                    p.furnishing.label,
                    p.status.label,
                    "Real Estate Exclusive",
                    "\"${(p.remarks ?: "").replace("\"", "\"\"")}\"",
                    p.listingLink ?: "",
                    p.portfolio,
                    p.transactionType,
                    p.googleMapsUrl ?: "",
                    p.lastVerifiedDateClean
                )
            } else {
                listOf(
                    p.propertyCode,
                    p.date,
                    "\"${p.location.replace("\"", "\"\"")}\"",
                    "\"${p.projectName.replace("\"", "\"\"")}\"",
                    "\"${p.unitNumber.replace("\"", "\"\"")}\"",
                    p.floor,
                    p.propertyType,
                    p.tab.code,
                    p.carpetAreaSqFt.toInt().toString(),
                    (p.builtUpAreaSqFt?.toInt() ?: "").toString(),
                    (p.priceSale?.toLong() ?: if (!p.tab.isRental) p.priceOrRent.toLong() else "").toString(),
                    (p.rent?.toLong() ?: if (p.tab.isRental) p.priceOrRent.toLong() else "").toString(),
                    (p.deposit?.toLong() ?: "").toString(),
                    (p.roiPercent ?: "").toString(),
                    p.possession,
                    p.furnishing.label,
                    p.status.label,
                    "\"${(p.ownerName ?: "").replace("\"", "\"\"")}\"",
                    p.ownerContact ?: "",
                    p.sourceInfo ?: "",
                    "\"${(p.remarks ?: "").replace("\"", "\"\"")}\"",
                    p.listingLink ?: "",
                    p.lastVerificationDate,
                    "\"${(p.internalRemarks ?: "").replace("\"", "\"\"")}\"",
                    p.portfolio,
                    p.transactionType,
                    p.googleMapsUrl ?: "",
                    (p.latitude ?: "").toString(),
                    (p.longitude ?: "").toString(),
                    p.verificationStatus.label,
                    p.lastVerifiedDateClean,
                    p.verifiedBy ?: "",
                    p.recordId,
                    p.syncUpdatedAt,
                    p.archiveStatus.label
                )
            }
            sb.append(row.joinToString(",")).append("\n")
        }
        return sb.toString()
    }

    /**
     * Download Standard Inventory Template CSV with Instructions
     */
    fun generateStandardTemplateCsv(): String {
        val sb = StringBuilder()
        sb.append("# REAL ESTATE INVENTORY — STANDARD INVENTORY IMPORT TEMPLATE\n")
        sb.append("# INSTRUCTIONS: Fill your property details under the headers below. Mandatory fields: Property Code, Project / Building, Location, Carpet Area, Price/Rent.\n")
        sb.append("# VALID PORTFOLIOS: Commercial | Residential\n")
        sb.append("# VALID TRANSACTION TYPES: Lease | Sale | Pre-Leased Sale\n")
        sb.append("# VALID STATUSES: Available | Not Available | Not Confirmed\n")
        sb.append("# VALID VERIFICATION STATUSES: Verified | Pending | Overdue\n\n")
        sb.append(MASTER_PROPERTY_35_COLUMNS.joinToString(",")).append("\n")
        sb.append("OFF-PUN-101,14/10/2026,Kharadi Pune,EON Free Zone Phase 1,Unit 402,4th Floor,Commercial Office,Off Lease,1850,2200,,165000,990000,,Immediate,Fully Furnished,Available,Mr. Rajesh Sharma,9822000000,Direct Listing,Fully furnished office with 32 workstations and 3 cabins,https://realestateinventory.in,14 Oct 2026,Key with security desk,Commercial,Lease,https://maps.google.com/?q=18.55,18.55,73.95,Verified,14 Oct 2026,Pavan Patil,AST-000101,14 Oct 2026 09:00 AM,Active\n")
        return sb.toString()
    }

    /**
     * Create Backup JSON Snapshot
     */
    fun createBackupNow(
        notes: String = "Manual Inventory Backup",
        userSettingsManager: UserSettingsManager? = null
    ): BackupSnapshot {
        val today = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val count = _properties.value.size

        val json = JSONObject().apply {
            put("appVersion", "12.0.0")
            put("timestamp", today)
            put("totalProperties", count)
            put("notes", notes)

            val propsArr = org.json.JSONArray()
            _properties.value.forEach { p ->
                val pObj = JSONObject().apply {
                    put("id", p.id)
                    put("propertyCode", p.propertyCode)
                    put("projectName", p.projectName)
                    put("location", p.location)
                    put("unitNumber", p.unitNumber)
                    put("carpetAreaSqFt", p.carpetAreaSqFt)
                    put("priceOrRent", p.priceOrRent)
                    put("portfolio", p.portfolio)
                    put("transactionType", p.transactionType)
                    put("status", p.status.name)
                    put("recordId", p.recordId)
                    put("ownerName", p.ownerName ?: "")
                    put("ownerContact", p.ownerContact ?: "")
                    put("internalRemarks", p.internalRemarks ?: "")
                    val imgs = org.json.JSONArray()
                    p.images.forEach { imgs.put(it) }
                    put("images", imgs)
                    put("videoUrl", p.videoUrl ?: "")
                }
                propsArr.put(pObj)
            }
            put("properties", propsArr)

            if (userSettingsManager != null) {
                val ascendP = userSettingsManager.ascendCompanyProfile.value
                val aureaP = userSettingsManager.aureaCompanyProfile.value
                val userP = userSettingsManager.userProfile.value

                put("ascendProfile", JSONObject().apply {
                    put("name", ascendP.companyName)
                    put("contact1", ascendP.contact1)
                    put("contact2", ascendP.contact2)
                    put("email", ascendP.email)
                    put("address", ascendP.officeAddress)
                    put("footer", ascendP.whatsappFooter)
                })

                put("aureaProfile", JSONObject().apply {
                    put("name", aureaP.companyName)
                    put("contact1", aureaP.contact1)
                    put("contact2", aureaP.contact2)
                    put("email", aureaP.email)
                    put("address", aureaP.officeAddress)
                    put("footer", aureaP.whatsappFooter)
                })

                put("userProfile", JSONObject().apply {
                    put("username", userP.username)
                    put("mobile", userP.mobileNumber)
                    put("email", userP.email)
                    put("role", userP.role.label)
                })

                put("verificationValidityDays", userSettingsManager.verificationValidityDays.value)
            }
        }

        val jsonStr = json.toString(2)
        val snap = BackupSnapshot(
            backupId = "bak_${System.currentTimeMillis()}",
            createdAt = today,
            propertyCount = count,
            notes = notes,
            dataJson = jsonStr
        )
        _backups.value = listOf(snap) + _backups.value
        return snap
    }

    /**
     * Restore Backup JSON
     */
    fun restoreFromBackupJson(
        jsonString: String,
        userSettingsManager: UserSettingsManager? = null
    ): Pair<Boolean, String> {
        return try {
            val root = JSONObject(jsonString)
            if (!root.has("properties")) {
                return Pair(false, "Invalid Backup Format: Missing 'properties' array in JSON backup file.")
            }

            // Create automatic safety backup before restoring
            createBackupNow(notes = "Automatic Pre-Restore Safety Backup", userSettingsManager = userSettingsManager)

            val propsArr = root.getJSONArray("properties")
            var restoredCount = 0

            val restoredProps = mutableListOf<PropertyItem>()
            val existingCodes = _properties.value.map { it.propertyCode }.toSet()

            for (i in 0 until propsArr.length()) {
                val pObj = propsArr.getJSONObject(i)
                val code = pObj.optString("propertyCode", "PUN-${100 + i}")
                val name = pObj.optString("projectName", "Commercial Project")
                val loc = pObj.optString("location", "Kharadi, Pune")

                val existing = _properties.value.find { it.propertyCode == code }
                if (existing != null) {
                    restoredProps.add(existing)
                } else {
                    val newP = PropertyItem(
                        id = pObj.optString("id", "prop_bak_${System.currentTimeMillis()}_$i"),
                        propertyCode = code,
                        projectName = name,
                        location = loc,
                        unitNumber = pObj.optString("unitNumber", "Unit 101"),
                        carpetAreaSqFt = pObj.optDouble("carpetAreaSqFt", 1000.0),
                        priceOrRent = pObj.optDouble("priceOrRent", 100000.0),
                        portfolio = pObj.optString("portfolio", "Ascend Commercial"),
                        transactionType = pObj.optString("transactionType", "Lease"),
                        recordId = pObj.optString("recordId", "AST-000${100 + i}"),
                        ownerName = if (pObj.has("ownerName")) pObj.optString("ownerName") else null,
                        ownerContact = if (pObj.has("ownerContact")) pObj.optString("ownerContact") else null,
                        internalRemarks = if (pObj.has("internalRemarks")) pObj.optString("internalRemarks") else null
                    )
                    restoredProps.add(newP)
                    restoredCount++
                }
            }

            if (userSettingsManager != null) {
                if (root.has("ascendProfile")) {
                    val asc = root.getJSONObject("ascendProfile")
                    userSettingsManager.updateAscendCompanyProfile(
                        asc.optString("name", "ASCEND COMMERCIAL SOLUTIONS"),
                        asc.optString("contact1", "9766880099"),
                        asc.optString("contact2", "9766668099"),
                        asc.optString("email", "contact@ascendcommercial.in"),
                        asc.optString("address", "Kharadi, Pune, Maharashtra"),
                        asc.optString("footer", "For private viewing and detailed brochure:\n📞 Call/WhatsApp: 9766880099 | 9766668099")
                    )
                }

                if (root.has("aureaProfile")) {
                    val aur = root.getJSONObject("aureaProfile")
                    userSettingsManager.updateAureaCompanyProfile(
                        aur.optString("name", "AUREA LIVING"),
                        aur.optString("contact1", "9766880099"),
                        aur.optString("contact2", "9766668099"),
                        aur.optString("email", "contact@aurealiving.in"),
                        aur.optString("address", "Kharadi, Pune, Maharashtra"),
                        aur.optString("footer", "For floor plans and builder inventory:\n📞 Call/WhatsApp: 9766880099 | 9766668099")
                    )
                }

                if (root.has("userProfile")) {
                    val usr = root.getJSONObject("userProfile")
                    userSettingsManager.updateProfile(
                        usr.optString("username", "Pavan Patil"),
                        usr.optString("mobile", "9766880099"),
                        usr.optString("email", "Pavanpatil93@gmail.com"),
                        UserRole.fromString(usr.optString("role", "Admin"))
                    )
                }

                if (root.has("verificationValidityDays")) {
                    userSettingsManager.updateVerificationValidityDays(root.optInt("verificationValidityDays", 30))
                }
            }

            _properties.value = restoredProps
            persistChanges()
            logSyncEvent("BACKUP_RESTORE", "SUCCESS", restoredProps.size, "Successfully restored backup. Preserved ${restoredProps.size} records.")

            Pair(true, "Backup restored successfully! Total ${restoredProps.size} properties active in system.")
        } catch (e: Exception) {
            Pair(false, "Failed to restore backup: ${e.localizedMessage}")
        }
    }

    fun restoreBackup(backupId: String): Boolean {
        val snap = _backups.value.find { it.backupId == backupId }
        return if (snap != null) {
            restoreFromBackupJson(snap.dataJson).first
        } else false
    }

    fun getGoogleAppsScriptTemplate(): String {
        return """
/**
 * ASCEND COMMERCIAL SOLUTIONS & AUREA LIVING LLP
 * MASTER REAL ESTATE INVENTORY DATABASE: ASCEND_AUREA_MASTER_INVENTORY
 * 4 REQUIRED WORKSHEETS:
 * 1. MASTER_PROPERTIES (35 Standard Columns)
 * 2. SETTINGS
 * 3. SYNC_LOG
 * 4. DATA_REVIEW
 * 
 * SETUP INSTRUCTIONS:
 * 1. In your Google Spreadsheet (named ASCEND_AUREA_MASTER_INVENTORY), click:
 *    Extensions > Apps Script.
 * 2. Delete existing code and paste this script into Code.gs.
 * 3. Click Run > setupMasterDatabase() ONCE to automatically create the 4 worksheets and format headers.
 * 4. Click Deploy > New Deployment.
 * 5. Select type: 'Web App'.
 *    - Execute as: 'Me' (your account)
 *    - Who has access: 'Anyone' (Allows your mobile app to 2-way sync)
 * 6. Copy the resulting Web App URL and paste it into the Android App.
 */

function setupMasterDatabase() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  // 1. MASTER_PROPERTIES: Exact 35 Standard Columns
  var masterCols = [
    'Property Code', 'Date', 'Location', 'Project / Building', 'Unit / Shop / Office No',
    'Floor', 'Property Type', 'Sub Type', 'Carpet Area', 'Built-up Area',
    'Price / Sale', 'Rent', 'Deposit', 'ROI %', 'Possession',
    'Furnishing', 'Status', 'Owner / Contact Person', 'Contact Number', 'Source',
    'Remarks', 'Listing Link', 'Last Updated', 'Remark',
    'Portfolio', 'Transaction Type', 'Google Maps URL', 'Latitude', 'Longitude',
    'Verification Status', 'Last Verified Date', 'Verified By', 'Record ID', 'Sync Updated At', 'Archive Status'
  ];

  // 2. SETTINGS
  var settingsCols = ['Setting Key', 'Configured Value', 'Description', 'Category'];

  // 3. SYNC_LOG
  var syncLogCols = ['Log ID', 'Timestamp', 'Direction', 'Status', 'Record Count', 'Details', 'Triggered By'];

  // 4. DATA_REVIEW
  var dataReviewCols = ['Review ID', 'Source File', 'Row Number', 'Raw Data Snapshot', 'Issue Reason', 'Suggested Code', 'Created Date'];

  var worksheets = {
    'MASTER_PROPERTIES': masterCols,
    'SETTINGS': settingsCols,
    'SYNC_LOG': syncLogCols,
    'DATA_REVIEW': dataReviewCols
  };

  Object.keys(worksheets).forEach(function(name) {
    var sheet = ss.getSheetByName(name);
    if (!sheet) {
      sheet = ss.insertSheet(name);
    }
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(worksheets[name]);
      sheet.getRange(1, 1, 1, worksheets[name].length)
        .setFontWeight('bold')
        .setBackground('#0F172A')
        .setFontColor('#D4AF37');
      sheet.setFrozenRows(1);
    }
  });

  // Seed default settings if empty
  var setSheet = ss.getSheetByName('SETTINGS');
  if (setSheet && setSheet.getLastRow() === 1) {
    setSheet.appendRow(['WORKBOOK_NAME', 'ASCEND_AUREA_MASTER_INVENTORY', 'Authoritative Master Database', 'Core']);
    setSheet.appendRow(['OFFICE_DEFAULT_LOADING', '45%', 'Standard office built-up loading factor', 'Area Math']);
    setSheet.appendRow(['SHOP_DEFAULT_LOADING', '50%', 'Retail shop/showroom loading factor', 'Area Math']);
    setSheet.appendRow(['RESIDENTIAL_LOADING', '0%', 'Commercial loading never applies to residential', 'Area Math']);
    setSheet.appendRow(['PORTFOLIO_COMMERCIAL', 'Ascend Commercial', 'Commercial real estate portfolio', 'Classification']);
    setSheet.appendRow(['PORTFOLIO_RESIDENTIAL', 'Aurea Residential', 'Residential real estate portfolio', 'Classification']);
  }
}

function doGet(e) {
  if (e && e.parameter && (e.parameter.action || e.parameter.payload || e.parameter.data)) {
    return handleWriteRequest(e);
  }
  return handleReadRequest(e);
}

function doPost(e) {
  return handleWriteRequest(e);
}

function handleReadRequest(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var masterSheet = ss.getSheetByName('MASTER_PROPERTIES') || ss.getSheetByName('Master Inventory') || ss.getSheets()[0];
  var settingsSheet = ss.getSheetByName('SETTINGS');
  var logSheet = ss.getSheetByName('SYNC_LOG');
  var reviewSheet = ss.getSheetByName('DATA_REVIEW');

  var data = {
    'MASTER_PROPERTIES': masterSheet ? masterSheet.getDataRange().getValues() : [],
    'SETTINGS': settingsSheet ? settingsSheet.getDataRange().getValues() : [],
    'SYNC_LOG': logSheet ? logSheet.getDataRange().getValues() : [],
    'DATA_REVIEW': reviewSheet ? reviewSheet.getDataRange().getValues() : []
  };

  return ContentService.createTextOutput(JSON.stringify({
    status: 'success',
    workbook: 'ASCEND_AUREA_MASTER_INVENTORY',
    timestamp: new Date().toISOString(),
    data: data
  })).setMimeType(ContentService.MimeType.JSON);
}

function handleWriteRequest(e) {
  try {
    var postData = {};
    if (e && e.postData && e.postData.contents) {
      postData = JSON.parse(e.postData.contents);
    } else if (e && e.parameter && e.parameter.payload) {
      postData = JSON.parse(e.parameter.payload);
    } else if (e && e.parameter && e.parameter.data) {
      postData = JSON.parse(e.parameter.data);
    } else if (e && e.parameter) {
      postData = e.parameter;
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var masterSheet = ss.getSheetByName('MASTER_PROPERTIES') || ss.getSheetByName('Master Inventory') || ss.getSheets()[0];
    var logSheet = ss.getSheetByName('SYNC_LOG');
    var reviewSheet = ss.getSheetByName('DATA_REVIEW');

    var action = postData.action || 'UPSERT';

    if (action === 'DIAGNOSTIC_PING') {
      return ContentService.createTextOutput(JSON.stringify({ status: 'success', message: 'Apps Script 2-way write connection verified!' }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // 1. Audit Logging
    if (action === 'LOG_SYNC') {
      if (logSheet) {
        logSheet.appendRow([
          postData.logId || ('LOG-' + new Date().getTime()),
          postData.timestamp || new Date().toLocaleString(),
          postData.direction || 'APP_TO_SHEET',
          postData.status || 'SUCCESS',
          postData.recordCount || 1,
          postData.details || '',
          postData.triggeredBy || 'Android App'
        ]);
      }
      return ContentService.createTextOutput(JSON.stringify({ status: 'success', action: 'LOG_SYNC' }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // 2. Quarantine Ambiguous/Invalid Records
    if (action === 'QUARANTINE_REVIEW_ROW') {
      if (reviewSheet) {
        reviewSheet.appendRow([
          postData.reviewId || ('REV-' + new Date().getTime()),
          postData.sourceFile || 'Import File',
          postData.rowNumber || 1,
          postData.rawData || '',
          postData.issueReason || 'INVALID_ROW',
          postData.suggestedCode || '',
          postData.createdAt || new Date().toLocaleDateString()
        ]);
      }
      return ContentService.createTextOutput(JSON.stringify({ status: 'success', action: 'QUARANTINE_REVIEW_ROW' }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // 3. Property Upsert (Matching by Property Code or Record ID)
    var values = masterSheet.getDataRange().getValues();
    var rowIndex = -1;
    var targetCode = String(postData.propertyCode || '').trim();
    var targetRecordId = String(postData.recordId || '').trim();

    for (var i = 1; i < values.length; i++) {
      var rowCode = String(values[i][0] || '').trim();
      var rowRecId = String(values[i][32] || '').trim();
      if ((targetCode && rowCode.toLowerCase() === targetCode.toLowerCase()) ||
          (targetRecordId && rowRecId.toLowerCase() === targetRecordId.toLowerCase())) {
        rowIndex = i + 1;
        break;
      }
    }

    var row35 = [
      postData.propertyCode || '',
      postData.date || new Date().toLocaleDateString(),
      postData.location || '',
      postData.projectName || '',
      postData.unitNumber || '',
      postData.floor || 'Mid Floor',
      postData.propertyType || 'Office',
      postData.subType || 'Commercial Offices (Lease)',
      postData.carpetAreaSqFt || 0,
      postData.builtUpAreaSqFt || '',
      postData.priceSale || '',
      postData.rent || '',
      postData.deposit || '',
      postData.roiPercent || '',
      postData.possession || 'Immediate',
      postData.furnishing || 'Not Mentioned',
      postData.status || 'Available',
      postData.ownerName || '',
      postData.ownerContact || '',
      postData.source || 'Android App Live Sync',
      postData.remarks || '',
      postData.listingLink || '',
      postData.lastUpdated || new Date().toLocaleDateString(),
      postData.remark || '',
      postData.portfolio || 'Ascend Commercial',
      postData.transactionType || 'Lease',
      postData.googleMapsUrl || '',
      postData.latitude || '',
      postData.longitude || '',
      postData.verificationStatus || 'Pending',
      postData.lastVerifiedDate || new Date().toLocaleDateString(),
      postData.verifiedBy || '',
      postData.recordId || ('AST-' + (targetCode.replace(/\D/g, '').padStart(6, '0') || '000101')),
      postData.syncUpdatedAt || new Date().toLocaleString(),
      postData.archiveStatus || 'Active'
    ];

    if (rowIndex > 0) {
      masterSheet.getRange(rowIndex, 1, 1, row35.length).setValues([row35]);
    } else {
      masterSheet.appendRow(row35);
    }

    if (logSheet) {
      logSheet.appendRow([
        'LOG-' + new Date().getTime(),
        new Date().toLocaleString(),
        'APP_TO_SHEET',
        'SUCCESS',
        1,
        (rowIndex > 0 ? 'Updated ' : 'Added ') + targetCode + ' (' + (postData.portfolio || 'Ascend') + ')',
        'Android Device'
      ]);
    }

    return ContentService.createTextOutput(JSON.stringify({
      status: 'success',
      action: rowIndex > 0 ? 'UPDATED' : 'ADDED',
      propertyCode: targetCode,
      recordId: row35[32]
    })).setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
""".trimIndent()
    }

    private suspend fun sendAppsScriptPost(targetUrl: String, jsonPayload: JSONObject): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        var url = targetUrl.trim()
        var conn: java.net.HttpURLConnection? = null
        try {
            val payloadBytes = jsonPayload.toString().toByteArray(Charsets.UTF_8)
            var redirectCount = 0
            var lastMsg = ""

            while (redirectCount < 5) {
                val u = java.net.URL(url)
                conn = u.openConnection() as java.net.HttpURLConnection
                conn.instanceFollowRedirects = true
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                conn.doOutput = true

                conn.outputStream.use { os ->
                    os.write(payloadBytes)
                    os.flush()
                }

                val status = conn.responseCode
                if (status in 200..299) {
                    val respText = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    return@withContext Pair(true, respText)
                } else if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
                    val loc = conn.getHeaderField("Location")
                    conn.disconnect()
                    if (!loc.isNullOrBlank()) {
                        url = loc
                        redirectCount++
                        continue
                    } else {
                        lastMsg = "HTTP $status Redirect without Location header"
                        break
                    }
                } else {
                    val errText = try { conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "" } catch (e: Exception) { "" }
                    conn.disconnect()
                    lastMsg = "HTTP $status: $errText"
                    break
                }
            }

            // Fallback: If POST with redirect returned issue, try GET with payload query parameter
            val encodedPayload = java.net.URLEncoder.encode(jsonPayload.toString(), "UTF-8")
            val getUrl = if (targetUrl.contains("?")) "$targetUrl&payload=$encodedPayload" else "$targetUrl?payload=$encodedPayload"
            val getResp = fetchUrlText(getUrl)
            if (getResp.isNotBlank()) {
                return@withContext Pair(true, getResp)
            }

            return@withContext Pair(false, lastMsg.ifBlank { "HTTP POST redirect failed" })
        } catch (e: Exception) {
            // Fallback: Try GET with payload query parameter
            try {
                val encodedPayload = java.net.URLEncoder.encode(jsonPayload.toString(), "UTF-8")
                val getUrl = if (targetUrl.contains("?")) "$targetUrl&payload=$encodedPayload" else "$targetUrl?payload=$encodedPayload"
                val getResp = fetchUrlText(getUrl)
                if (getResp.isNotBlank()) {
                    return@withContext Pair(true, getResp)
                }
            } catch (_: Exception) {}

            return@withContext Pair(false, e.localizedMessage ?: "Network Error")
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }

    private suspend fun reverseSyncToSheet(property: PropertyItem, action: String) {
        val scriptUrl = _sheetsScriptUrl.value.trim()
        if (scriptUrl.isBlank()) {
            logSyncEvent(
                direction = "APP_TO_SHEET",
                status = "WARNING",
                recordCount = 0,
                details = "Cannot reverse sync: No Google Sheet / Apps Script URL configured.",
                triggeredBy = "Live 2-Way Sync"
            )
            return
        }

        if (!scriptUrl.contains("script.google.com")) {
            logSyncEvent(
                direction = "APP_TO_SHEET",
                status = "WARNING",
                recordCount = 0,
                details = "Direct Google Sheet link configured (Read-Only). Deploy Google Apps Script Web App for automatic 2-way write sync.",
                triggeredBy = "Live 2-Way Sync"
            )
            return
        }

        try {
            val json = JSONObject().apply {
                put("action", action)
                put("propertyId", property.id)
                put("propertyCode", property.propertyCode)
                put("date", property.date)
                put("location", property.location)
                put("projectName", property.projectName)
                put("unitNumber", property.unitNumber)
                put("floor", property.floor)
                put("propertyType", property.propertyType)
                put("subType", property.tab.title)
                put("carpetAreaSqFt", property.carpetAreaSqFt)
                put("builtUpAreaSqFt", property.builtUpAreaSqFt ?: "")
                put("priceSale", property.priceSale ?: if (!property.tab.isRental) property.priceOrRent else "")
                put("rent", property.rent ?: if (property.tab.isRental) property.priceOrRent else "")
                put("deposit", property.deposit ?: "")
                put("roiPercent", property.roiPercent ?: "")
                put("possession", property.possession)
                put("furnishing", property.furnishing.label)
                put("status", property.status.label)
                put("ownerName", property.ownerName ?: "")
                put("ownerContact", property.ownerContact ?: "")
                put("source", property.sourceInfo ?: "Real Estate Inventory App")
                put("remarks", property.remarks ?: "")
                put("listingLink", property.listingLink ?: "")
                put("lastUpdated", property.lastVerificationDate)
                put("remark", property.internalRemarks ?: "")
                put("portfolio", property.portfolio)
                put("transactionType", property.transactionType)
                put("googleMapsUrl", property.googleMapsUrl ?: "")
                put("latitude", property.latitude ?: "")
                put("longitude", property.longitude ?: "")
                put("verificationStatus", property.verificationStatus.label)
                put("lastVerifiedDate", property.lastVerifiedDateClean)
                put("verifiedBy", property.verifiedBy ?: "")
                put("recordId", property.recordId)
                put("syncUpdatedAt", SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date()))
                put("archiveStatus", property.archiveStatus.label)
            }

            val (success, responseText) = sendAppsScriptPost(scriptUrl, json)
            if (success) {
                _properties.value = _properties.value.map { prop ->
                    if (prop.id == property.id) prop.copy(isSyncedToSheet = true) else prop
                }
                persistChanges()
                logSyncEvent(
                    direction = "APP_TO_SHEET",
                    status = "SUCCESS",
                    recordCount = 1,
                    details = "Synced ${property.propertyCode} ($action) to Google Sheet",
                    triggeredBy = "Live 2-Way Sync"
                )
            } else {
                logSyncEvent(
                    direction = "APP_TO_SHEET",
                    status = "FAILED",
                    recordCount = 0,
                    details = "Failed to sync ${property.propertyCode}: $responseText",
                    triggeredBy = "Live 2-Way Sync"
                )
            }
        } catch (e: Exception) {
            android.util.Log.e("SheetsRepository", "Reverse Sync Failed: ${e.message}")
            logSyncEvent(
                direction = "APP_TO_SHEET",
                status = "FAILED",
                recordCount = 0,
                details = "Error syncing ${property.propertyCode}: ${e.message}",
                triggeredBy = "Live 2-Way Sync"
            )
        }
    }
}
