package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Locale

enum class KpiFilterType(val title: String, val subtitle: String) {
    TOTAL_PROPERTIES("Total Active Properties", "Unique active property records in inventory"),
    AVAILABLE_NOW("Available Now Properties", "Properties vacant/ready for immediate deal"),
    VERIFICATION_PENDING("Verification Overdue / Pending", "Pending verification or last verified > 90 days ago"),
    DATA_QUALITY("Data Quality Action Required", "Listings missing carpet area, price, location, or contact")
}

@Composable
private fun CompactInventoryMetric(
    label: String,
    value: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(66.dp),
        color = BrandCharcoalSurface,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(0.8.dp, BrandCharcoalBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(label, color = TextSecondaryDark, fontSize = 11.sp)
                Text(value.toString(), color = TextPrimaryDark, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = AscendGold, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
fun DashboardScreen(
    properties: List<PropertyItem>,
    underConstProjects: List<UnderConstProject>,
    initialBrand: Brand? = null,
    userProfile: UserProfile = UserProfile(),
    onPropertyClick: (PropertyItem) -> Unit,
    onEditProperty: (PropertyItem) -> Unit,
    onVerifyProperty: (String) -> Unit,
    onOpenMasterSync: () -> Unit
) {
    val context = LocalContext.current
    var selectedBrandFilter by remember { mutableStateOf<Brand?>(initialBrand) }
    var activeKpiModalFilter by remember { mutableStateOf<KpiFilterType?>(null) }
    var modalSearchQuery by remember { mutableStateOf("") }

    // Filter properties by selected portfolio (Active records only for KPI)
    val portfolioProperties = remember(properties, selectedBrandFilter) {
        properties.filter { p ->
            p.archiveStatus == ArchiveStatus.ACTIVE && when (selectedBrandFilter) {
                Brand.ASCEND_COMMERCIAL -> p.isCommercial()
                Brand.AUREA_LIVING -> p.isResidential()
                null -> true
            }
        }
    }

    // Filter under construction projects by portfolio
    val portfolioUnderConst = remember(underConstProjects, selectedBrandFilter) {
        if (selectedBrandFilter == Brand.ASCEND_COMMERCIAL) emptyList()
        else underConstProjects
    }

    // 1. TOTAL PROPERTIES (Count unique property codes / records)
    val totalUniqueProperties = remember(portfolioProperties, portfolioUnderConst) {
        val uniqueCodes = portfolioProperties.distinctBy { it.propertyCode.ifBlank { it.id } }
        uniqueCodes.size + portfolioUnderConst.size
    }

    // 2. AVAILABLE NOW
    val availableProperties = remember(portfolioProperties, portfolioUnderConst) {
        val availProps = portfolioProperties.filter {
            it.status == AvailabilityStatus.AVAILABLE ||
            it.status.label.contains("Available", ignoreCase = true) ||
            it.possession.contains("Immediate", ignoreCase = true)
        }
        val availConst = portfolioUnderConst.filter { it.status == AvailabilityStatus.AVAILABLE }
        availProps to availConst
    }
    val availableCount = availableProperties.first.size + availableProperties.second.size

    // 3. VERIFICATION OVERDUE / PENDING
    val pendingOrOverdueProperties = remember(portfolioProperties) {
        portfolioProperties.filter { p ->
            p.verificationStatus == VerificationStatus.PENDING ||
            p.lastVerifiedDateClean.isBlank() ||
            isOlderThan90Days(p.lastVerifiedDateClean.ifBlank { p.lastVerificationDate })
        }
    }
    val pendingOrOverdueCount = pendingOrOverdueProperties.size

    // 4. DATA QUALITY / ACTION REQUIRED
    val incompleteDataProperties = remember(portfolioProperties) {
        portfolioProperties.filter { p ->
            isMissingArea(p) || isMissingPrice(p) || isMissingLocation(p) || isMissingContact(p)
        }
    }
    val incompleteDataCount = incompleteDataProperties.size

    // Overall Data Health Score calculation
    val dataHealthScore = remember(portfolioProperties) {
        if (portfolioProperties.isEmpty()) 100
        else {
            val validAreaCount = portfolioProperties.count { !isMissingArea(it) }
            val validPriceCount = portfolioProperties.count { !isMissingPrice(it) }
            val validLocCount = portfolioProperties.count { !isMissingLocation(it) }
            val validContactCount = portfolioProperties.count { !isMissingContact(it) }
            val verifiedCount = portfolioProperties.count { it.verificationStatus == VerificationStatus.VERIFIED }

            val totalChecks = portfolioProperties.size * 5
            val passedChecks = validAreaCount + validPriceCount + validLocCount + validContactCount + verifiedCount
            if (totalChecks == 0) 100 else ((passedChecks.toDouble() / totalChecks) * 100).toInt()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandCharcoalDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .padding(bottom = 80.dp)
            .testTag("inventory_dashboard_screen")
    ) {
        // =====================================================================
        // HEADER & PORTFOLIO SWITCHER
        // =====================================================================
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Inventory Health Dashboard",
                    color = TextPrimaryDark,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "EXECUTIVE KPI & MASTER DATA QUALITY ANALYTICS",
                    color = AscendGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
            }

            // Sync Status Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(BrandCharcoalSurface)
                    .border(0.8.dp, BrandCharcoalBorder, RoundedCornerShape(8.dp))
                    .clickable { onOpenMasterSync() }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.CloudSync, contentDescription = null, tint = AscendGold, modifier = Modifier.size(14.dp))
                    Text("Master Sync", color = AscendGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // PORTFOLIO FILTER TABS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(BrandCharcoalSurface)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val portfolios = listOf(
                null to "All Businesses",
                Brand.ASCEND_COMMERCIAL to "Ascend Commercial",
                Brand.AUREA_LIVING to "Aurea Residential"
            )

            portfolios.forEach { (brand, label) ->
                val isSelected = selectedBrandFilter == brand
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) AscendGold else Color.Transparent)
                        .clickable { selectedBrandFilter = brand }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) BrandCharcoalDark else TextSecondaryDark,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // =====================================================================
        // SECTION 2: FOUR MAIN KPI CARDS
        // =====================================================================
        Text(
            text = "EXECUTIVE KPI SUMMARY",
            color = AscendGold,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp
        )
        Text(
            text = "Tap any KPI card below to inspect filtered property listings",
            color = TextMutedDark,
            fontSize = 10.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Compact KPI summary: keep the existing drill-down dialogs without oversized cards.
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CompactInventoryMetric("Total", totalUniqueProperties, Modifier.weight(1f)) {
                    activeKpiModalFilter = KpiFilterType.TOTAL_PROPERTIES
                }
                CompactInventoryMetric("Available", availableCount, Modifier.weight(1f)) {
                    activeKpiModalFilter = KpiFilterType.AVAILABLE_NOW
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CompactInventoryMetric("Verify", pendingOrOverdueCount, Modifier.weight(1f)) {
                    activeKpiModalFilter = KpiFilterType.VERIFICATION_PENDING
                }
                CompactInventoryMetric("Fix data", incompleteDataCount, Modifier.weight(1f)) {
                    activeKpiModalFilter = KpiFilterType.DATA_QUALITY
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // =====================================================================
        // MASTER DATA HEALTH SCORE CARD
        // =====================================================================
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Overall Master Data Quality Index",
                            color = TextPrimaryDark,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Aggregated check across price, area, location, contact & verification",
                            color = TextSecondaryDark,
                            fontSize = 10.sp
                        )
                    }
                    Text(
                        text = "$dataHealthScore%",
                        color = if (dataHealthScore >= 80) StatusAvailable else if (dataHealthScore >= 60) StatusUnconfirmed else Color(0xFFF43F5E),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { dataHealthScore / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (dataHealthScore >= 80) StatusAvailable else if (dataHealthScore >= 60) StatusUnconfirmed else Color(0xFFF43F5E),
                    trackColor = BrandCharcoalCard
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // =====================================================================
        // SECTION 4: IMMEDIATE DATA QUALITY ACTIONS
        // =====================================================================
        Text(
            text = "IMMEDIATE DATA QUALITY ACTIONS",
            color = AscendGold,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Button 1: Verify Pending
            Button(
                onClick = { activeKpiModalFilter = KpiFilterType.VERIFICATION_PENDING },
                modifier = Modifier.weight(1f).height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706), contentColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Verify Pending ($pendingOrOverdueCount)", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }

            // Button 2: Fix Incomplete Data
            Button(
                onClick = { activeKpiModalFilter = KpiFilterType.DATA_QUALITY },
                modifier = Modifier.weight(1f).height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48), contentColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Icon(Icons.Default.BuildCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Fix Incomplete ($incompleteDataCount)", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }

            // Button 3: Export Inventory Summary
            OutlinedButton(
                onClick = {
                    val summary = generateInventorySummaryText(
                        brand = selectedBrandFilter,
                        totalCount = totalUniqueProperties,
                        availableCount = availableCount,
                        pendingVerifCount = pendingOrOverdueCount,
                        incompleteCount = incompleteDataCount,
                        properties = portfolioProperties
                    )
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Executive Inventory Summary", summary))
                    Toast.makeText(context, "Executive Summary copied to Clipboard!", Toast.LENGTH_LONG).show()
                },
                modifier = Modifier.weight(1f).height(44.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = AscendGold),
                border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Export Summary", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // =====================================================================
        // SECTION 3: INVENTORY DISTRIBUTION BREAKDOWN
        // =====================================================================
        Text(
            text = "INVENTORY DISTRIBUTION ANALYTICS",
            color = AscendGold,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        // 3.1 BY CATEGORY / TAB
        BreakdownCard(
            title = "Distribution by Property Category",
            icon = Icons.Default.Category
        ) {
            InventoryTab.values()
                .filter { tab ->
                    when (selectedBrandFilter) {
                        Brand.ASCEND_COMMERCIAL -> tab.brand == Brand.ASCEND_COMMERCIAL
                        Brand.AUREA_LIVING -> tab.brand == Brand.AUREA_LIVING
                        null -> true
                    }
                }
                .forEach { tab ->
                    val count = if (tab == InventoryTab.UND_CONST) portfolioUnderConst.size else portfolioProperties.count { it.tab == tab }
                    val totalForTabPct = if (totalUniqueProperties > 0) (count.toFloat() / totalUniqueProperties) else 0f
                    
                    ProgressStatRow(
                        label = tab.title,
                        count = count,
                        percentage = totalForTabPct,
                        barColor = if (tab.isCommercial) CommercialBlue else ResidentialRose
                    )
                }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3.2 BY MICRO-MARKET / LOCATION
        val locationGroups = remember(portfolioProperties) {
            portfolioProperties
                .groupBy { it.location.ifBlank { "Unmapped Micro-Market" } }
                .mapValues { it.value.size }
                .entries.sortedByDescending { it.value }
                .take(6)
        }

        BreakdownCard(
            title = "Top Micro-Markets / Locations",
            icon = Icons.Default.Place
        ) {
            if (locationGroups.isEmpty()) {
                Text("No location data available", color = TextMutedDark, fontSize = 11.sp)
            } else {
                locationGroups.forEach { (locName, count) ->
                    val pct = if (totalUniqueProperties > 0) (count.toFloat() / totalUniqueProperties) else 0f
                    ProgressStatRow(
                        label = locName,
                        count = count,
                        percentage = pct,
                        barColor = AscendGold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3.3 BY AVAILABILITY STATUS
        BreakdownCard(
            title = "Distribution by Availability Status",
            icon = Icons.Default.Rule
        ) {
            val availCount = portfolioProperties.count { it.status == AvailabilityStatus.AVAILABLE } + portfolioUnderConst.count { it.status == AvailabilityStatus.AVAILABLE }
            val unconfirmedCount = portfolioProperties.count { it.status == AvailabilityStatus.NOT_CONFIRMED }
            val closedCount = portfolioProperties.count { it.status == AvailabilityStatus.NOT_AVAILABLE }

            ProgressStatRow(
                label = "Available Now (Ready / Vacant)",
                count = availCount,
                percentage = if (totalUniqueProperties > 0) availCount.toFloat() / totalUniqueProperties else 0f,
                barColor = StatusAvailable
            )
            Spacer(modifier = Modifier.height(6.dp))
            ProgressStatRow(
                label = "Not Confirmed / Verification Pending",
                count = unconfirmedCount,
                percentage = if (totalUniqueProperties > 0) unconfirmedCount.toFloat() / totalUniqueProperties else 0f,
                barColor = StatusUnconfirmed
            )
            Spacer(modifier = Modifier.height(6.dp))
            ProgressStatRow(
                label = "Closed / Leased / Sold / Out",
                count = closedCount,
                percentage = if (totalUniqueProperties > 0) closedCount.toFloat() / totalUniqueProperties else 0f,
                barColor = StatusNotAvailable
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3.4 BY VERIFICATION STATUS
        BreakdownCard(
            title = "Distribution by Verification Status",
            icon = Icons.Default.Verified
        ) {
            val verifiedCount = portfolioProperties.count { it.verificationStatus == VerificationStatus.VERIFIED }
            val pendingCount = portfolioProperties.count { it.verificationStatus == VerificationStatus.PENDING }

            ProgressStatRow(
                label = "Verified Properties",
                count = verifiedCount,
                percentage = if (portfolioProperties.isNotEmpty()) verifiedCount.toFloat() / portfolioProperties.size else 0f,
                barColor = StatusAvailable
            )
            Spacer(modifier = Modifier.height(6.dp))
            ProgressStatRow(
                label = "Pending or Overdue Verification",
                count = pendingCount,
                percentage = if (portfolioProperties.isNotEmpty()) pendingCount.toFloat() / portfolioProperties.size else 0f,
                barColor = StatusUnconfirmed
            )
        }
    }

    // =========================================================================
    // MODAL DIALOG FOR FILTERED KPI PROPERTIES LIST
    // =========================================================================
    if (activeKpiModalFilter != null) {
        val filter = activeKpiModalFilter!!

        val filteredModalList = remember(portfolioProperties, filter, modalSearchQuery) {
            val baseList = when (filter) {
                KpiFilterType.TOTAL_PROPERTIES -> portfolioProperties
                KpiFilterType.AVAILABLE_NOW -> portfolioProperties.filter {
                    it.status == AvailabilityStatus.AVAILABLE ||
                    it.status.label.contains("Available", ignoreCase = true) ||
                    it.possession.contains("Immediate", ignoreCase = true)
                }
                KpiFilterType.VERIFICATION_PENDING -> pendingOrOverdueProperties
                KpiFilterType.DATA_QUALITY -> incompleteDataProperties
            }

            if (modalSearchQuery.isBlank()) baseList
            else baseList.filter {
                it.propertyCode.contains(modalSearchQuery, ignoreCase = true) ||
                it.projectName.contains(modalSearchQuery, ignoreCase = true) ||
                it.location.contains(modalSearchQuery, ignoreCase = true)
            }
        }

        AlertDialog(
            onDismissRequest = {
                activeKpiModalFilter = null
                modalSearchQuery = ""
            },
            title = {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = filter.title,
                            color = TextPrimaryDark,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            activeKpiModalFilter = null
                            modalSearchQuery = ""
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryDark)
                        }
                    }
                    Text(
                        text = "${filteredModalList.size} matching properties • ${filter.subtitle}",
                        color = AscendGold,
                        fontSize = 11.sp
                    )
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    // Search box inside modal
                    OutlinedTextField(
                        value = modalSearchQuery,
                        onValueChange = { modalSearchQuery = it },
                        placeholder = { Text("Search by code, project or location...", fontSize = 11.sp, color = TextMutedDark) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMutedDark, modifier = Modifier.size(16.dp)) },
                        trailingIcon = {
                            if (modalSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { modalSearchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = null, tint = TextMutedDark, modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = BrandCharcoalDark,
                            unfocusedContainerColor = BrandCharcoalDark,
                            focusedBorderColor = AscendGold,
                            unfocusedBorderColor = BrandCharcoalBorder,
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark
                        )
                    )

                    if (filteredModalList.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No properties found for this KPI filter", color = TextMutedDark, fontSize = 12.sp)
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(filteredModalList, key = { it.id }) { item ->
                                KpiPropertyListItemCard(
                                    property = item,
                                    filterType = filter,
                                    onPropertyClick = {
                                        activeKpiModalFilter = null
                                        onPropertyClick(item)
                                    },
                                    onEditProperty = {
                                        activeKpiModalFilter = null
                                        onEditProperty(item)
                                    },
                                    onVerifyProperty = {
                                        onVerifyProperty(item.id)
                                        Toast.makeText(context, "${item.propertyCode} marked as Verified!", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    activeKpiModalFilter = null
                    modalSearchQuery = ""
                }) {
                    Text("Close", color = AscendGold, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = BrandCharcoalSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

// =============================================================================
// HELPER COMPOSABLES & FUNCTIONS
// =============================================================================

@Composable
fun ExecutiveKpiCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    containerColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = accentColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, color = TextPrimaryDark, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, color = TextSecondaryDark, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun BreakdownCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = AscendGold, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, color = TextPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun ProgressStatRow(
    label: String,
    count: Int,
    percentage: Float,
    barColor: Color
) {
    val pctText = (percentage * 100).toInt()
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = TextPrimaryDark, fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("$count records ($pctText%)", color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(3.dp))
        LinearProgressIndicator(
            progress = { percentage.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
            color = barColor,
            trackColor = BrandCharcoalCard
        )
    }
}

@Composable
fun KpiPropertyListItemCard(
    property: PropertyItem,
    filterType: KpiFilterType,
    onPropertyClick: () -> Unit,
    onEditProperty: () -> Unit,
    onVerifyProperty: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onPropertyClick() },
        colors = CardDefaults.cardColors(containerColor = BrandCharcoalDark),
        border = androidx.compose.foundation.BorderStroke(0.8.dp, BrandCharcoalBorder),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(AscendGold)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(property.propertyCode, color = BrandCharcoalDark, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                    Text(property.projectName.ifBlank { "Unassigned Building" }, color = TextPrimaryDark, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }

                Text(
                    text = "₹${CalculationUtils.formatIndianCurrency(property.priceOrRent)}",
                    color = AscendGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${property.location} • ${property.tab.title} • ${property.carpetAreaSqFt.toInt()} sq.ft",
                color = TextSecondaryDark,
                fontSize = 10.sp
            )

            // Special indicators based on filter
            if (filterType == KpiFilterType.DATA_QUALITY) {
                val missing = getMissingFieldsList(property)
                if (missing.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Missing: ${missing.joinToString(", ")}",
                            color = Color(0xFFF43F5E),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = onEditProperty,
                            modifier = Modifier.height(28.dp),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("Edit", fontSize = 9.sp, color = AscendGold)
                        }
                    }
                }
            } else if (filterType == KpiFilterType.VERIFICATION_PENDING) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Status: ${property.verificationStatus.label} • Last: ${property.lastVerifiedDateClean.ifBlank { "Never" }}",
                        color = StatusUnconfirmed,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Button(
                        onClick = onVerifyProperty,
                        modifier = Modifier.height(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable, contentColor = BrandCharcoalDark),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Verify Now", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

fun getMissingFieldsList(p: PropertyItem): List<String> {
    val list = mutableListOf<String>()
    if (isMissingArea(p)) list.add("Area")
    if (isMissingPrice(p)) list.add("Price/Rent")
    if (isMissingLocation(p)) list.add("Location")
    if (isMissingContact(p)) list.add("Contact")
    return list
}

fun isMissingArea(p: PropertyItem): Boolean {
    return p.carpetAreaSqFt <= 0 && (p.builtUpAreaSqFt == null || p.builtUpAreaSqFt <= 0)
}

fun isMissingPrice(p: PropertyItem): Boolean {
    return p.priceOrRent <= 0 && (p.priceSale == null || p.priceSale <= 0) && (p.rent == null || p.rent <= 0)
}

fun isMissingLocation(p: PropertyItem): Boolean {
    return p.location.isBlank()
}

fun isMissingContact(p: PropertyItem): Boolean {
    return p.ownerContact.isNullOrBlank() && p.ownerName.isNullOrBlank() && p.brokerContact.isNullOrBlank()
}

fun isOlderThan90Days(dateStr: String): Boolean {
    if (dateStr.isBlank()) return true
    val formatter = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
    val parsedDate = try {
        formatter.parse(dateStr)
    } catch (e: Exception) {
        try {
            SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).parse(dateStr)
        } catch (e2: Exception) {
            try {
                SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).parse(dateStr)
            } catch (e3: Exception) {
                null
            }
        }
    } ?: return true

    val diffMillis = System.currentTimeMillis() - parsedDate.time
    val diffDays = diffMillis / (1000 * 60 * 60 * 24)
    return diffDays > 90
}

fun generateInventorySummaryText(
    brand: Brand?,
    totalCount: Int,
    availableCount: Int,
    pendingVerifCount: Int,
    incompleteCount: Int,
    properties: List<PropertyItem>
): String {
    val brandName = brand?.displayName ?: "ASCEND COMMERCIAL SOLUTIONS & AUREA LIVING"
    val dateToday = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(java.util.Date())
    val topLocations = properties.groupBy { it.location.ifBlank { "Other" } }
        .mapValues { it.value.size }
        .entries.sortedByDescending { it.value }
        .take(5)
        .joinToString("\n") { "  • ${it.key}: ${it.value} listings" }

    val availPct = if (totalCount > 0) (availableCount * 100 / totalCount) else 0

    return """
        📊 EXECUTIVE INVENTORY HEALTH REPORT
        Business: $brandName
        Date: $dateToday
        
        📈 KEY KPI METRICS:
        • Total Unique Properties: $totalCount
        • Available Now: $availableCount ($availPct%)
        • Verification Overdue/Pending: $pendingVerifCount
        • Data Quality Action Required: $incompleteCount
        
        📍 TOP MICRO-MARKETS:
        $topLocations
        
        Source: Master Google Sheet Database (ASCEND_AUREA_MASTER_INVENTORY)
    """.trimIndent()
}
