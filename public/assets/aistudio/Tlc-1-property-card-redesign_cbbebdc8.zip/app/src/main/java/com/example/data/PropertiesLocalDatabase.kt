package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object PropertiesLocalDatabase {

    private const val TAG = "PropertiesLocalDatabase"
    private const val DB_FILE_NAME = "ascend_aurea_inventory_db.json"

    fun loadProperties(context: Context): List<PropertyItem> {
        val file = File(context.filesDir, DB_FILE_NAME)
        if (!file.exists()) {
            return emptyList()
        }

        return try {
            val jsonString = file.readText()
            val jsonArray = JSONArray(jsonString)
            val list = mutableListOf<PropertyItem>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(deserializeProperty(obj))
            }
            list
        } catch (e: Exception) {
            Log.e(TAG, "Error loading saved properties: ${e.message}", e)
            emptyList()
        }
    }

    fun clearAll(context: Context) {
        try {
            val file = File(context.filesDir, DB_FILE_NAME)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting local DB file: ${e.message}", e)
        }
    }

    fun saveProperties(context: Context, properties: List<PropertyItem>): Boolean {
        return try {
            val file = File(context.filesDir, DB_FILE_NAME)
            val jsonArray = JSONArray()
            properties.forEach { item ->
                jsonArray.put(serializeProperty(item))
            }
            file.writeText(jsonArray.toString(2))
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error saving properties to disk: ${e.message}", e)
            false
        }
    }

    private fun serializeProperty(item: PropertyItem): JSONObject {
        val obj = JSONObject()
        obj.put("id", item.id)
        obj.put("propertyCode", item.propertyCode)
        obj.put("date", item.date)
        obj.put("location", item.location)
        obj.put("projectName", item.projectName)
        obj.put("unitNumber", item.unitNumber)
        obj.put("floor", item.floor)
        obj.put("propertyType", item.propertyType)
        obj.put("tab", item.tab.name)
        obj.put("carpetAreaSqFt", item.carpetAreaSqFt)
        item.builtUpAreaSqFt?.let { obj.put("builtUpAreaSqFt", it) }
        obj.put("priceOrRent", item.priceOrRent)
        item.priceSale?.let { obj.put("priceSale", it) }
        item.rent?.let { obj.put("rent", it) }
        item.deposit?.let { obj.put("deposit", it) }
        item.roiPercent?.let { obj.put("roiPercent", it) }
        obj.put("possession", item.possession)
        obj.put("furnishing", item.furnishing.name)
        obj.put("status", item.status.name)
        item.ownerName?.let { obj.put("ownerName", it) }
        item.ownerContact?.let { obj.put("ownerContact", it) }
        item.sourceInfo?.let { obj.put("sourceInfo", it) }
        item.remarks?.let { obj.put("remarks", it) }
        item.listingLink?.let { obj.put("listingLink", it) }
        obj.put("lastVerificationDate", item.lastVerificationDate)
        item.internalRemarks?.let { obj.put("internalRemarks", it) }

        // Images array
        val imagesArray = JSONArray()
        item.images.forEach { imagesArray.put(it) }
        obj.put("images", imagesArray)

        item.floorPlanUrl?.let { obj.put("floorPlanUrl", it) }
        item.videoUrl?.let { obj.put("videoUrl", it) }
        item.brochureUrl?.let { obj.put("brochureUrl", it) }

        // Attachments array
        val attachArray = JSONArray()
        item.attachments.forEach { att ->
            val attObj = JSONObject()
            attObj.put("id", att.id)
            attObj.put("name", att.name)
            attObj.put("type", att.type.name)
            attObj.put("localUriOrPath", att.localUriOrPath)
            attObj.put("fileSizeBytes", att.fileSizeBytes)
            attObj.put("uploadDate", att.uploadDate)
            attObj.put("mimeType", att.mimeType)
            attachArray.put(attObj)
        }
        obj.put("attachments", attachArray)

        item.workstations?.let { obj.put("workstations", it) }
        item.cabins?.let { obj.put("cabins", it) }
        item.conferenceRooms?.let { obj.put("conferenceRooms", it) }
        item.frontageFeet?.let { obj.put("frontageFeet", it) }
        item.floorLevel?.let { obj.put("floorLevel", it) }
        item.ceilingHeightFeet?.let { obj.put("ceilingHeightFeet", it) }
        obj.put("isMainRoadFacing", item.isMainRoadFacing)
        item.bhk?.let { obj.put("bhk", it) }
        item.balconies?.let { obj.put("balconies", it) }
        item.builderName?.let { obj.put("builderName", it) }
        item.brokerName?.let { obj.put("brokerName", it) }
        item.brokerContact?.let { obj.put("brokerContact", it) }
        obj.put("rowNumber", item.rowNumber)

        // 11 Standard Master Management Columns
        obj.put("portfolio", item.portfolio)
        obj.put("transactionType", item.transactionType)
        item.googleMapsUrl?.let { obj.put("googleMapsUrl", it) }
        item.latitude?.let { obj.put("latitude", it) }
        item.longitude?.let { obj.put("longitude", it) }
        obj.put("verificationStatus", item.verificationStatus.name)
        obj.put("lastVerifiedDateClean", item.lastVerifiedDateClean)
        item.verifiedBy?.let { obj.put("verifiedBy", it) }
        obj.put("recordId", item.recordId)
        obj.put("syncUpdatedAt", item.syncUpdatedAt)
        obj.put("archiveStatus", item.archiveStatus.name)
        obj.put("isAreaEstimated", item.isAreaEstimated)

        return obj
    }

    private fun deserializeProperty(obj: JSONObject): PropertyItem {
        val tabName = obj.optString("tab", InventoryTab.OFF_LEASE.name)
        val tab = try { InventoryTab.valueOf(tabName) } catch (_: Exception) { InventoryTab.OFF_LEASE }

        val furnishingName = obj.optString("furnishing", FurnishingType.UNFURNISHED.name)
        val furnishing = try { FurnishingType.valueOf(furnishingName) } catch (_: Exception) { FurnishingType.UNFURNISHED }

        val statusName = obj.optString("status", AvailabilityStatus.AVAILABLE.name)
        val status = try { AvailabilityStatus.valueOf(statusName) } catch (_: Exception) { AvailabilityStatus.AVAILABLE }

        val images = mutableListOf<String>()
        val imgArray = obj.optJSONArray("images")
        if (imgArray != null) {
            for (i in 0 until imgArray.length()) {
                images.add(imgArray.getString(i))
            }
        }

        val attachments = mutableListOf<PropertyAttachment>()
        val attArray = obj.optJSONArray("attachments")
        if (attArray != null) {
            for (i in 0 until attArray.length()) {
                val attObj = attArray.getJSONObject(i)
                val typeName = attObj.optString("type", AttachmentType.DOCUMENT.name)
                val type = try { AttachmentType.valueOf(typeName) } catch (_: Exception) { AttachmentType.DOCUMENT }
                attachments.add(
                    PropertyAttachment(
                        id = attObj.optString("id"),
                        name = attObj.optString("name", "Document"),
                        type = type,
                        localUriOrPath = attObj.optString("localUriOrPath"),
                        fileSizeBytes = attObj.optLong("fileSizeBytes", 0L),
                        uploadDate = attObj.optString("uploadDate", "13 Oct 2026"),
                        mimeType = attObj.optString("mimeType", "application/pdf")
                    )
                )
            }
        }

        val propCode = obj.getString("propertyCode")
        val fallbackRecordId = "AST-${propCode.filter { it.isDigit() }.padStart(6, '0').takeLast(6).ifBlank { "000001" }}"

        val verifStatus = try {
            VerificationStatus.valueOf(obj.optString("verificationStatus", VerificationStatus.PENDING.name))
        } catch (_: Exception) {
            VerificationStatus.PENDING
        }

        val archiveSt = try {
            ArchiveStatus.valueOf(obj.optString("archiveStatus", ArchiveStatus.ACTIVE.name))
        } catch (_: Exception) {
            ArchiveStatus.ACTIVE
        }

        return PropertyItem(
            id = obj.getString("id"),
            propertyCode = propCode,
            date = obj.optString("date", "13/10/2026"),
            location = obj.optString("location", "Kharadi, Pune"),
            projectName = obj.optString("projectName", "Commercial Project"),
            unitNumber = obj.optString("unitNumber", "Unit 101"),
            floor = obj.optString("floor", "Mid Floor"),
            propertyType = obj.optString("propertyType", "Commercial"),
            tab = tab,
            carpetAreaSqFt = obj.optDouble("carpetAreaSqFt", 1000.0),
            builtUpAreaSqFt = if (obj.has("builtUpAreaSqFt")) obj.optDouble("builtUpAreaSqFt") else null,
            priceOrRent = obj.optDouble("priceOrRent", 90000.0),
            priceSale = if (obj.has("priceSale")) obj.optDouble("priceSale") else null,
            rent = if (obj.has("rent")) obj.optDouble("rent") else null,
            deposit = if (obj.has("deposit")) obj.optDouble("deposit") else null,
            roiPercent = if (obj.has("roiPercent")) obj.optDouble("roiPercent") else null,
            possession = obj.optString("possession", "Immediate"),
            furnishing = furnishing,
            status = status,
            ownerName = if (obj.has("ownerName")) obj.optString("ownerName") else null,
            ownerContact = if (obj.has("ownerContact")) obj.optString("ownerContact") else null,
            sourceInfo = if (obj.has("sourceInfo")) obj.optString("sourceInfo") else null,
            remarks = if (obj.has("remarks")) obj.optString("remarks") else null,
            listingLink = if (obj.has("listingLink")) obj.optString("listingLink") else null,
            lastVerificationDate = obj.optString("lastVerificationDate", "13 Oct 2026"),
            internalRemarks = if (obj.has("internalRemarks")) obj.optString("internalRemarks") else null,
            images = images,
            floorPlanUrl = if (obj.has("floorPlanUrl")) obj.optString("floorPlanUrl") else null,
            videoUrl = if (obj.has("videoUrl")) obj.optString("videoUrl") else null,
            brochureUrl = if (obj.has("brochureUrl")) obj.optString("brochureUrl") else null,
            attachments = attachments,
            workstations = if (obj.has("workstations")) obj.optInt("workstations") else null,
            cabins = if (obj.has("cabins")) obj.optInt("cabins") else null,
            conferenceRooms = if (obj.has("conferenceRooms")) obj.optInt("conferenceRooms") else null,
            frontageFeet = if (obj.has("frontageFeet")) obj.optDouble("frontageFeet") else null,
            floorLevel = if (obj.has("floorLevel")) obj.optString("floorLevel") else null,
            ceilingHeightFeet = if (obj.has("ceilingHeightFeet")) obj.optDouble("ceilingHeightFeet") else null,
            isMainRoadFacing = obj.optBoolean("isMainRoadFacing", false),
            bhk = if (obj.has("bhk")) obj.optString("bhk") else null,
            balconies = if (obj.has("balconies")) obj.optInt("balconies") else null,
            builderName = if (obj.has("builderName")) obj.optString("builderName") else null,
            brokerName = if (obj.has("brokerName")) obj.optString("brokerName") else null,
            brokerContact = if (obj.has("brokerContact")) obj.optString("brokerContact") else null,
            rowNumber = obj.optInt("rowNumber", 0),
            // 11 Standard Master Management Columns
            portfolio = obj.optString("portfolio", if (tab.brand == Brand.AUREA_LIVING) "Aurea Residential" else "Ascend Commercial"),
            transactionType = obj.optString("transactionType", if (tab.isRental) "Lease" else "Sale"),
            googleMapsUrl = if (obj.has("googleMapsUrl")) obj.optString("googleMapsUrl") else null,
            latitude = if (obj.has("latitude")) obj.optDouble("latitude") else if (obj.has("lat")) obj.optDouble("lat") else null,
            longitude = if (obj.has("longitude")) obj.optDouble("longitude") else if (obj.has("lng")) obj.optDouble("lng") else null,
            verificationStatus = verifStatus,
            lastVerifiedDateClean = obj.optString("lastVerifiedDateClean", "14 Oct 2026"),
            verifiedBy = if (obj.has("verifiedBy")) obj.optString("verifiedBy") else null,
            recordId = obj.optString("recordId", fallbackRecordId),
            syncUpdatedAt = obj.optString("syncUpdatedAt", "14 Oct 2026, 09:00 AM"),
            archiveStatus = archiveSt,
            isAreaEstimated = obj.optBoolean("isAreaEstimated", false)
        )
    }

    fun getDefaultSampleProperties(): List<PropertyItem> {
        return listOf(
            PropertyItem(
                id = "sample_prop_1",
                propertyCode = "OL-KHD-101",
                date = "13/10/2026",
                location = "Kharadi, Pune",
                projectName = "World Trade Center (WTC)",
                unitNumber = "Tower 4, 8th Floor",
                floor = "High Floor",
                propertyType = "Office",
                tab = InventoryTab.OFF_LEASE,
                carpetAreaSqFt = 2400.0,
                priceOrRent = 168000.0,
                deposit = 1008000.0,
                possession = "Immediate",
                furnishing = FurnishingType.FULLY_FURNISHED,
                status = AvailabilityStatus.AVAILABLE,
                ownerName = "Rajesh Singhania",
                ownerContact = "9822011223",
                remarks = "Fully furnished plug & play corporate office with 24 workstations, 3 cabins, and conference room.",
                verificationStatus = VerificationStatus.VERIFIED,
                archiveStatus = ArchiveStatus.ACTIVE,
                portfolio = "Commercial",
                transactionType = "Lease"
            ),
            PropertyItem(
                id = "sample_prop_2",
                propertyCode = "SL-VMN-202",
                date = "13/10/2026",
                location = "Viman Nagar, Pune",
                projectName = "Phoenix Marketcity Retail",
                unitNumber = "Ground Floor, Shop 14",
                floor = "Ground Floor",
                propertyType = "Shop",
                tab = InventoryTab.SHOP_LEASE,
                carpetAreaSqFt = 950.0,
                priceOrRent = 190000.0,
                deposit = 1140000.0,
                possession = "Immediate",
                furnishing = FurnishingType.BARE_SHELL,
                status = AvailabilityStatus.AVAILABLE,
                ownerName = "Suresh Mehta",
                ownerContact = "9822188220",
                remarks = "Prime high-street frontage retail shop with excellent footfall.",
                verificationStatus = VerificationStatus.VERIFIED,
                archiveStatus = ArchiveStatus.ACTIVE,
                portfolio = "Commercial",
                transactionType = "Lease"
            ),
            PropertyItem(
                id = "sample_prop_3",
                propertyCode = "PL-KHD-303",
                date = "13/10/2026",
                location = "Kharadi, Pune",
                projectName = "Gera Imperium Alpha",
                unitNumber = "Office 305",
                floor = "Mid Floor",
                propertyType = "Office",
                tab = InventoryTab.PRE_LEASED,
                carpetAreaSqFt = 1450.0,
                priceOrRent = 22500000.0,
                roiPercent = 7.8,
                possession = "Immediate",
                furnishing = FurnishingType.SEMI_FURNISHED,
                status = AvailabilityStatus.AVAILABLE,
                ownerName = "Anil Deshmukh",
                ownerContact = "9850123456",
                remarks = "Pre-leased to multinational tech tenant with 3-year lock-in. 7.8% net ROI.",
                verificationStatus = VerificationStatus.VERIFIED,
                archiveStatus = ArchiveStatus.ACTIVE,
                portfolio = "Commercial",
                transactionType = "Pre-Leased Sale"
            ),
            PropertyItem(
                id = "sample_prop_4",
                propertyCode = "RR-WKD-404",
                date = "13/10/2026",
                location = "Wakad, Pune",
                projectName = "Kasturi Apostrophe",
                unitNumber = "Building B, 1202",
                floor = "High Floor",
                propertyType = "Apartment",
                tab = InventoryTab.RESI_RENT,
                carpetAreaSqFt = 1320.0,
                priceOrRent = 45000.0,
                deposit = 200000.0,
                bhk = "3 BHK",
                possession = "Immediate",
                furnishing = FurnishingType.SEMI_FURNISHED,
                status = AvailabilityStatus.AVAILABLE,
                ownerName = "Dr. Prakash Kulkarni",
                ownerContact = "9860012345",
                remarks = "Sprawling 3 BHK luxury apartment with club view and 2 covered parking spaces.",
                verificationStatus = VerificationStatus.VERIFIED,
                archiveStatus = ArchiveStatus.ACTIVE,
                portfolio = "Residential",
                transactionType = "Lease"
            ),
            PropertyItem(
                id = "sample_prop_5",
                propertyCode = "RS-Kalyani-505",
                date = "13/10/2026",
                location = "Kalyani Nagar, Pune",
                projectName = "Kumar Primavera",
                unitNumber = "A Wing, 401",
                floor = "Mid Floor",
                propertyType = "Apartment",
                tab = InventoryTab.RESI_RESALE,
                carpetAreaSqFt = 1650.0,
                priceOrRent = 18500000.0,
                bhk = "3 BHK",
                possession = "Immediate",
                furnishing = FurnishingType.FULLY_FURNISHED,
                status = AvailabilityStatus.AVAILABLE,
                ownerName = "Vikramaditya Rao",
                ownerContact = "9881122334",
                remarks = "Exquisitely renovated 3 BHK resale in prime Kalyani Nagar residential enclave.",
                verificationStatus = VerificationStatus.VERIFIED,
                archiveStatus = ArchiveStatus.ACTIVE,
                portfolio = "Residential",
                transactionType = "Sale"
            )
        )
    }
}
