package com.example.data

import android.content.Context
import android.net.Uri
import com.example.model.BrandLogos
import com.example.model.CompanyProfile
import com.example.model.UserProfile
import com.example.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream

class UserSettingsManager(private val context: Context?) {

    private val prefs = context?.getSharedPreferences("ascend_aurea_user_settings", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(loadProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _brandLogos = MutableStateFlow(loadLogos())
    val brandLogos: StateFlow<BrandLogos> = _brandLogos.asStateFlow()

    private val _ascendCompanyProfile = MutableStateFlow(loadAscendProfile())
    val ascendCompanyProfile: StateFlow<CompanyProfile> = _ascendCompanyProfile.asStateFlow()

    private val _aureaCompanyProfile = MutableStateFlow(loadAureaProfile())
    val aureaCompanyProfile: StateFlow<CompanyProfile> = _aureaCompanyProfile.asStateFlow()

    private val _verificationValidityDays = MutableStateFlow(prefs?.getInt("verification_validity_days", 30) ?: 30)
    val verificationValidityDays: StateFlow<Int> = _verificationValidityDays.asStateFlow()

    fun updateVerificationValidityDays(days: Int) {
        _verificationValidityDays.value = days
        prefs?.edit()?.putInt("verification_validity_days", days)?.apply()
    }

    private fun loadProfile(): UserProfile {
        if (prefs == null) return UserProfile()
        val username = prefs.getString("user_username", "Pavan Patil") ?: "Pavan Patil"
        val mobile = prefs.getString("user_mobile", "9766880099") ?: "9766880099"
        val email = prefs.getString("user_email", "Pavanpatil93@gmail.com") ?: "Pavanpatil93@gmail.com"
        val roleStr = prefs.getString("user_role", "Admin") ?: "Admin"
        val photoUri = prefs.getString("user_photo_uri", null)
        return UserProfile(
            username = username,
            mobileNumber = mobile,
            email = email,
            role = UserRole.fromString(roleStr),
            profilePhotoUri = photoUri
        )
    }

    private fun loadLogos(): BrandLogos {
        if (prefs == null) return BrandLogos()
        val ascendUri = prefs.getString("brand_ascend_logo", null)
        val aureaUri = prefs.getString("brand_aurea_logo", null)
        return BrandLogos(
            ascendLogoUri = ascendUri,
            aureaLogoUri = aureaUri
        )
    }

    private fun loadAscendProfile(): CompanyProfile {
        if (prefs == null) {
            return CompanyProfile(
                companyName = "COMMERCIAL PORTFOLIO",
                contact1 = "9766880099",
                contact2 = "9766668099",
                portfolio = "Commercial",
                email = "commercial@realestateinventory.in",
                officeAddress = "Kharadi, Pune, Maharashtra",
                whatsappFooter = "For private viewing and detailed brochure:\n📞 Call/WhatsApp: 9766880099 | 9766668099"
            )
        }
        return CompanyProfile(
            companyName = prefs.getString("ascend_name", "COMMERCIAL PORTFOLIO") ?: "COMMERCIAL PORTFOLIO",
            contact1 = prefs.getString("ascend_contact1", "9766880099") ?: "9766880099",
            contact2 = prefs.getString("ascend_contact2", "9766668099") ?: "9766668099",
            portfolio = "Commercial",
            email = prefs.getString("ascend_email", "commercial@realestateinventory.in") ?: "commercial@realestateinventory.in",
            officeAddress = prefs.getString("ascend_address", "Kharadi, Pune, Maharashtra") ?: "Kharadi, Pune, Maharashtra",
            whatsappFooter = prefs.getString("ascend_footer", "For private viewing and detailed brochure:\n📞 Call/WhatsApp: 9766880099 | 9766668099") ?: "For private viewing and detailed brochure:\n📞 Call/WhatsApp: 9766880099 | 9766668099",
            logoUri = prefs.getString("brand_ascend_logo", null)
        )
    }

    private fun loadAureaProfile(): CompanyProfile {
        if (prefs == null) {
            return CompanyProfile(
                companyName = "RESIDENTIAL PORTFOLIO",
                contact1 = "9766880099",
                contact2 = "9766668099",
                portfolio = "Residential",
                email = "residential@realestateinventory.in",
                officeAddress = "Kharadi, Pune, Maharashtra",
                whatsappFooter = "For floor plans and builder inventory:\n📞 Call/WhatsApp: 9766880099 | 9766668099"
            )
        }
        return CompanyProfile(
            companyName = prefs.getString("aurea_name", "RESIDENTIAL PORTFOLIO") ?: "RESIDENTIAL PORTFOLIO",
            contact1 = prefs.getString("aurea_contact1", "9766880099") ?: "9766880099",
            contact2 = prefs.getString("aurea_contact2", "9766668099") ?: "9766668099",
            portfolio = "Residential",
            email = prefs.getString("aurea_email", "residential@realestateinventory.in") ?: "residential@realestateinventory.in",
            officeAddress = prefs.getString("aurea_address", "Kharadi, Pune, Maharashtra") ?: "Kharadi, Pune, Maharashtra",
            whatsappFooter = prefs.getString("aurea_footer", "For floor plans and builder inventory:\n📞 Call/WhatsApp: 9766880099 | 9766668099") ?: "For floor plans and builder inventory:\n📞 Call/WhatsApp: 9766880099 | 9766668099",
            logoUri = prefs.getString("brand_aurea_logo", null)
        )
    }

    fun updateProfile(
        username: String,
        mobileNumber: String,
        email: String,
        role: UserRole,
        photoUri: String? = _userProfile.value.profilePhotoUri
    ) {
        val updated = UserProfile(
            username = username.ifBlank { "Pavan Patil" },
            mobileNumber = mobileNumber.ifBlank { "9766880099" },
            email = email.ifBlank { "Pavanpatil93@gmail.com" },
            role = role,
            profilePhotoUri = photoUri
        )
        _userProfile.value = updated
        prefs?.edit()?.apply {
            putString("user_username", updated.username)
            putString("user_mobile", updated.mobileNumber)
            putString("user_email", updated.email)
            putString("user_role", updated.role.label)
            if (photoUri != null) putString("user_photo_uri", photoUri) else remove("user_photo_uri")
            apply()
        }
    }

    fun saveProfilePhoto(uri: Uri) {
        val localPath = copyUriToInternalStorage(uri, "user_photo")
        updateProfile(
            username = _userProfile.value.username,
            mobileNumber = _userProfile.value.mobileNumber,
            email = _userProfile.value.email,
            role = _userProfile.value.role,
            photoUri = localPath ?: uri.toString()
        )
    }

    fun updateAscendCompanyProfile(
        name: String,
        contact1: String,
        contact2: String,
        email: String,
        address: String,
        footer: String
    ) {
        val updated = CompanyProfile(
            companyName = name.ifBlank { "ASCEND COMMERCIAL SOLUTIONS" },
            contact1 = contact1.ifBlank { "9766880099" },
            contact2 = contact2.ifBlank { "9766668099" },
            portfolio = "Commercial",
            email = email,
            officeAddress = address,
            whatsappFooter = footer,
            logoUri = _brandLogos.value.ascendLogoUri
        )
        _ascendCompanyProfile.value = updated
        prefs?.edit()?.apply {
            putString("ascend_name", updated.companyName)
            putString("ascend_contact1", updated.contact1)
            putString("ascend_contact2", updated.contact2)
            putString("ascend_email", updated.email)
            putString("ascend_address", updated.officeAddress)
            putString("ascend_footer", updated.whatsappFooter)
            apply()
        }
    }

    fun updateAureaCompanyProfile(
        name: String,
        contact1: String,
        contact2: String,
        email: String,
        address: String,
        footer: String
    ) {
        val updated = CompanyProfile(
            companyName = name.ifBlank { "AUREA LIVING" },
            contact1 = contact1.ifBlank { "9766880099" },
            contact2 = contact2.ifBlank { "9766668099" },
            portfolio = "Residential",
            email = email,
            officeAddress = address,
            whatsappFooter = footer,
            logoUri = _brandLogos.value.aureaLogoUri
        )
        _aureaCompanyProfile.value = updated
        prefs?.edit()?.apply {
            putString("aurea_name", updated.companyName)
            putString("aurea_contact1", updated.contact1)
            putString("aurea_contact2", updated.contact2)
            putString("aurea_email", updated.email)
            putString("aurea_address", updated.officeAddress)
            putString("aurea_footer", updated.whatsappFooter)
            apply()
        }
    }

    fun saveAscendLogo(uri: Uri) {
        val localPath = copyUriToInternalStorage(uri, "ascend_logo")
        val logoPath = localPath ?: uri.toString()
        val updated = _brandLogos.value.copy(ascendLogoUri = logoPath)
        _brandLogos.value = updated
        _ascendCompanyProfile.value = _ascendCompanyProfile.value.copy(logoUri = logoPath)
        prefs?.edit()?.putString("brand_ascend_logo", logoPath)?.apply()
    }

    fun saveAureaLogo(uri: Uri) {
        val localPath = copyUriToInternalStorage(uri, "aurea_logo")
        val logoPath = localPath ?: uri.toString()
        val updated = _brandLogos.value.copy(aureaLogoUri = logoPath)
        _brandLogos.value = updated
        _aureaCompanyProfile.value = _aureaCompanyProfile.value.copy(logoUri = logoPath)
        prefs?.edit()?.putString("brand_aurea_logo", logoPath)?.apply()
    }

    fun resetAscendLogo() {
        val updated = _brandLogos.value.copy(ascendLogoUri = null)
        _brandLogos.value = updated
        _ascendCompanyProfile.value = _ascendCompanyProfile.value.copy(logoUri = null)
        prefs?.edit()?.remove("brand_ascend_logo")?.apply()
    }

    fun resetAureaLogo() {
        val updated = _brandLogos.value.copy(aureaLogoUri = null)
        _brandLogos.value = updated
        _aureaCompanyProfile.value = _aureaCompanyProfile.value.copy(logoUri = null)
        prefs?.edit()?.remove("brand_aurea_logo")?.apply()
    }

    private fun copyUriToInternalStorage(uri: Uri, prefix: String): String? {
        if (context == null) return uri.toString()
        return try {
            val extension = context.contentResolver.getType(uri)?.substringAfterLast("/") ?: "png"
            val destFile = File(context.filesDir, "${prefix}_${System.currentTimeMillis()}.$extension")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            destFile.absolutePath
        } catch (e: Exception) {
            uri.toString()
        }
    }
}
