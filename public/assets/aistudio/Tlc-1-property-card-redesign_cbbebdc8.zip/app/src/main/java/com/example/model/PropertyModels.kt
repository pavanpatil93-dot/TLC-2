package com.example.model

enum class Brand(val displayName: String, val tagline: String) {
    ASCEND_COMMERCIAL(
        "COMMERCIAL (ASCEND)",
        "Commercial Real Estate & Institutional Inventory"
    ),
    AUREA_LIVING(
        "RESIDENTIAL (AUREA)",
        "Residential Living & Luxury Inventory"
    )
}

enum class InventoryTab(
    val code: String,
    val title: String,
    val brand: Brand,
    val isCommercial: Boolean,
    val isRental: Boolean
) {
    OFF_LEASE("Off Lease", "Commercial Offices (Lease)", Brand.ASCEND_COMMERCIAL, true, true),
    OFF_OUT("Off Out", "Offices (Outright Sale)", Brand.ASCEND_COMMERCIAL, true, false),
    SHOP_LEASE("Shop Lease", "Retail Shops & Showrooms (Lease)", Brand.ASCEND_COMMERCIAL, true, true),
    SHOP_OUT("Shop Out", "Retail Shops (Outright Sale)", Brand.ASCEND_COMMERCIAL, true, false),
    PRE_LEASED("Pre - Leased", "Pre-Leased Investment", Brand.ASCEND_COMMERCIAL, true, false),
    RESI_RENT("Resi Rent", "Residential Rentals", Brand.AUREA_LIVING, false, true),
    RESI_RESALE("Resi Resale", "Residential Resale", Brand.AUREA_LIVING, false, false),
    UND_CONST("Und Const", "Under Construction Projects", Brand.AUREA_LIVING, false, false)
}

enum class AvailabilityStatus(val label: String) {
    AVAILABLE("Available"),
    NOT_AVAILABLE("Not Available"),
    NOT_CONFIRMED("Not Confirmed")
}

enum class StandardPortfolio(val label: String) {
    ASCEND_COMMERCIAL("Commercial"),
    AUREA_RESIDENTIAL("Residential");

    companion object {
        fun fromString(value: String?, tab: InventoryTab? = null): StandardPortfolio {
            if (!value.isNullOrBlank()) {
                val v = value.lowercase()
                if (v.contains("commercial") || v.contains("ascend")) return ASCEND_COMMERCIAL
                if (v.contains("residential") || v.contains("aurea")) return AUREA_RESIDENTIAL
            }
            return if (tab?.brand == Brand.AUREA_LIVING) AUREA_RESIDENTIAL else ASCEND_COMMERCIAL
        }
    }
}

enum class StandardTransactionType(val label: String) {
    LEASE("Lease"),
    SALE("Sale"),
    PRE_LEASED_SALE("Pre-Leased Sale");

    companion object {
        fun fromString(value: String?, tab: InventoryTab? = null): StandardTransactionType {
            if (!value.isNullOrBlank()) {
                val v = value.lowercase()
                if (v.contains("pre-lease") || v.contains("pre leased")) return PRE_LEASED_SALE
                if (v.contains("lease") || v.contains("rent")) return LEASE
                if (v.contains("sale") || v.contains("outright") || v.contains("resale")) return SALE
            }
            return when {
                tab == InventoryTab.PRE_LEASED -> PRE_LEASED_SALE
                tab?.isRental == true -> LEASE
                else -> SALE
            }
        }
    }
}

enum class StandardPropertyType(val label: String) {
    OFFICE("Office"),
    SHOP("Shop"),
    SHOWROOM("Showroom"),
    WAREHOUSE("Warehouse"),
    COMMERCIAL_LAND("Commercial Land"),
    APARTMENT("Apartment"),
    VILLA("Villa"),
    BUNGALOW("Bungalow"),
    RESIDENTIAL_PLOT("Residential Plot");

    companion object {
        fun fromString(value: String?): StandardPropertyType {
            val v = value?.lowercase()?.trim() ?: ""
            return when {
                v.contains("showroom") -> SHOWROOM
                v.contains("office") -> OFFICE
                v.contains("shop") || v.contains("retail") -> SHOP
                v.contains("warehouse") || v.contains("godown") -> WAREHOUSE
                v.contains("commercial land") -> COMMERCIAL_LAND
                v.contains("villa") -> VILLA
                v.contains("bungalow") -> BUNGALOW
                v.contains("plot") || v.contains("land") -> RESIDENTIAL_PLOT
                v.contains("apartment") || v.contains("flat") || v.contains("condo") || v.contains("resi") -> APARTMENT
                else -> OFFICE
            }
        }
    }
}

enum class StandardFurnishing(val label: String) {
    BARE("Bare"),
    WARM_SHELL("Warm Shell"),
    SEMI_FURNISHED("Semi-Furnished"),
    FULLY_FURNISHED("Fully Furnished"),
    PLUG_AND_PLAY("Plug-and-Play"),
    NOT_MENTIONED("Not Mentioned");

    companion object {
        fun fromString(value: String?): StandardFurnishing {
            val v = value?.lowercase()?.trim() ?: ""
            return when {
                v.contains("plug") -> PLUG_AND_PLAY
                v.contains("full") -> FULLY_FURNISHED
                v.contains("semi") -> SEMI_FURNISHED
                v.contains("warm") -> WARM_SHELL
                v.contains("bare") || v.contains("unfurnish") -> BARE
                v.isBlank() || v.contains("not") -> NOT_MENTIONED
                else -> NOT_MENTIONED
            }
        }
    }
}

enum class VerificationStatus(val label: String) {
    VERIFIED("Verified"),
    PENDING("Pending");

    companion object {
        fun fromString(value: String?): VerificationStatus {
            val v = value?.lowercase()?.trim() ?: ""
            return if (v.contains("veri")) VERIFIED else PENDING
        }
    }
}

enum class ArchiveStatus(val label: String) {
    ACTIVE("Active"),
    ARCHIVED("Archived");

    companion object {
        fun fromString(value: String?): ArchiveStatus {
            val v = value?.lowercase()?.trim() ?: ""
            return if (v.contains("archive")) ARCHIVED else ACTIVE
        }
    }
}

enum class FurnishingType(val label: String) {
    BARE_SHELL("Bare Shell"),
    WARM_SHELL("Warm Shell"),
    SEMI_FURNISHED("Semi-Furnished"),
    FULLY_FURNISHED("Fully Furnished"),
    UNFURNISHED("Unfurnished")
}

data class PropertyEditHistory(
    val historyId: String,
    val timestamp: String,
    val summary: String,
    val snapshot: PropertyItemSnapshot
)

data class PropertyItemSnapshot(
    val carpetAreaSqFt: Double,
    val builtUpAreaSqFt: Double?,
    val priceOrRent: Double,
    val priceSale: Double?,
    val rent: Double?,
    val deposit: Double?,
    val roiPercent: Double?,
    val furnishing: FurnishingType,
    val possession: String,
    val status: AvailabilityStatus,
    val ownerName: String?,
    val ownerContact: String?,
    val remarks: String?
)

data class PropertyItem(
    val id: String = "",
    // Standard Master Inventory 24 Columns
    val propertyCode: String = "",
    val date: String = "13/10/2026",
    val location: String = "",
    val projectName: String = "", // Project / Building
    val unitNumber: String = "", // Unit / Shop / Office No
    val floor: String = "Mid Floor",
    val propertyType: String = "Commercial", // Property Type
    val tab: InventoryTab = InventoryTab.OFF_LEASE, // Sub Type
    val carpetAreaSqFt: Double = 0.0,
    val builtUpAreaSqFt: Double? = null,
    val priceOrRent: Double = 0.0, // Price / Sale or Rent
    val priceSale: Double? = null, // Price / Sale
    val rent: Double? = null, // Rent
    val deposit: Double? = null,
    val roiPercent: Double? = null, // ROI %
    val possession: String = "Immediate",
    val furnishing: FurnishingType = FurnishingType.UNFURNISHED,
    val status: AvailabilityStatus = AvailabilityStatus.NOT_CONFIRMED,
    val ownerName: String? = null, // Owner / Contact Person
    val ownerContact: String? = null, // Contact Number
    val sourceInfo: String? = null, // Source
    val remarks: String? = null, // Remarks
    val listingLink: String? = null, // Listing Link
    val lastVerificationDate: String = "13 Oct 2026", // Last Updated
    val internalRemarks: String? = null, // Remark

    // Photos & Media
    val images: List<String> = emptyList(),
    val floorPlanUrl: String? = null,
    val videoUrl: String? = null,
    val brochureUrl: String? = null,
    val amenities: List<String> = emptyList(),
    val parking: String = "1 Reserved",
    val maintenance: Double? = null,
    val lat: Double? = null,
    val lng: Double? = null,

    // Specific specs
    val workstations: Int? = null,
    val cabins: Int? = null,
    val conferenceRooms: Int? = null,
    val frontageFeet: Double? = null,
    val floorLevel: String? = null,
    val ceilingHeightFeet: Double? = null,
    val isMainRoadFacing: Boolean = false,
    val bhk: String? = null,
    val balconies: Int? = null,
    val builderName: String? = null,
    val monthlyRentalIncome: Double? = null,
    val tenantName: String? = null,
    val leaseDurationYears: Int? = null,
    val lockInPeriodYears: Int? = null,
    val escalationPercent: Double? = null,
    val escalationIntervalYears: Int? = null,
    val brokerName: String? = null,
    val brokerContact: String? = null,
    val rowNumber: Int = 0,
    val editHistory: List<PropertyEditHistory> = emptyList(),
    val attachments: List<PropertyAttachment> = emptyList(),
    val isSyncedToSheet: Boolean = true, // True for imported items, false for locally created/edited

    // Appended Standard 11 Master Management Columns (25 to 35)
    val portfolio: String = "Commercial", // 25. Portfolio
    val transactionType: String = "Lease", // 26. Transaction Type
    val googleMapsUrl: String? = null, // 27. Google Maps URL
    val latitude: Double? = null, // 28. Latitude
    val longitude: Double? = null, // 29. Longitude
    val verificationStatus: VerificationStatus = VerificationStatus.PENDING, // 30. Verification Status
    val lastVerifiedDateClean: String = "14 Oct 2026", // 31. Last Verified Date
    val verifiedBy: String? = null, // 32. Verified By
    val recordId: String = "", // 33. Record ID (AST-xxxxxx unique permanent identifier)
    val syncUpdatedAt: String = "14 Oct 2026, 09:00 AM", // 34. Sync Updated At
    val archiveStatus: ArchiveStatus = ArchiveStatus.ACTIVE, // 35. Archive Status
    val isAreaEstimated: Boolean = false // Commercial loading area estimated indicator
)

enum class AttachmentType(val displayName: String, val badgeColor: Long) {
    PDF_BROCHURE("PDF Brochure", 0xFFEF4444),
    FLOOR_PLAN("Floor Plan", 0xFF3B82F6),
    DOCUMENT("Document", 0xFFD4AF37),
    VIDEO("Video", 0xFF8B5CF6)
}

data class PropertyAttachment(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val type: AttachmentType,
    val localUriOrPath: String,
    val fileSizeBytes: Long = 0,
    val uploadDate: String = "13 Oct 2026",
    val mimeType: String = "application/pdf"
)


data class UnderConstConfig(
    val id: String,
    val configName: String,
    val carpetAreaSqFt: Double,
    val price: Double,
    val possessionDate: String,
    val floorPlanUrl: String? = null,
    val unitsAvailable: Int = 1
)

data class UnderConstProject(
    val id: String,
    val projectCode: String,
    val projectName: String,
    val location: String,
    val builderName: String,
    val possessionYear: String,
    val mahaReraNumber: String,
    val startingPrice: Double,
    val configurations: List<UnderConstConfig>,
    val photoGallery: List<String> = emptyList(),
    val videoUrl: String? = null,
    val brochureUrl: String? = null,
    val amenities: List<String> = emptyList(),
    val lat: Double? = null,
    val lng: Double? = null,
    val status: AvailabilityStatus = AvailabilityStatus.AVAILABLE,
    val lastVerificationDate: String = "10 Oct 2026",
    val builderContactPerson: String? = null,
    val builderPhone: String? = null,
    val internalRemarks: String? = null
)

data class BackupSnapshot(
    val backupId: String,
    val createdAt: String,
    val propertyCount: Int,
    val notes: String,
    val dataJson: String
)

data class ImportPreviewRow(
    val rowNumber: Int,
    val propertyCode: String,
    val projectName: String,
    val location: String,
    val unitNumber: String,
    val floor: String = "Mid Floor",
    val propertyType: String = "Commercial",
    val tab: InventoryTab,
    val carpetAreaSqFt: Double,
    val builtUpAreaSqFt: Double? = null,
    val priceOrRent: Double,
    val priceSale: Double? = null,
    val rent: Double? = null,
    val deposit: Double? = null,
    val roiPercent: Double? = null,
    val possession: String = "Immediate",
    val furnishing: FurnishingType = FurnishingType.UNFURNISHED,
    val status: AvailabilityStatus = AvailabilityStatus.AVAILABLE,
    val ownerName: String? = null,
    val ownerContact: String? = null,
    val sourceInfo: String? = null,
    val remarks: String? = null,
    val listingLink: String? = null,
    val isDuplicateCode: Boolean,
    val isValid: Boolean,
    val validationMessage: String = "Valid Record",
    // Standard 35-column additions
    val recordId: String = "",
    val portfolio: String = "Ascend Commercial",
    val transactionType: String = "Lease",
    val googleMapsUrl: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val verificationStatus: VerificationStatus = VerificationStatus.PENDING,
    val lastVerifiedDateClean: String = "14 Oct 2026",
    val verifiedBy: String? = null,
    val isAreaEstimated: Boolean = false,
    val unmappedColumns: Map<String, String> = emptyMap(),
    val conflictResolution: String = "REVIEW" // "SKIP", "UPDATE", "CANCEL", "NEW_CODE"
)

// 35 Standard Columns for ASCEND_AUREA_MASTER_INVENTORY
val MASTER_PROPERTY_35_COLUMNS = listOf(
    "Property Code", "Date", "Location", "Project / Building", "Unit / Shop / Office No",
    "Floor", "Property Type", "Sub Type", "Carpet Area", "Built-up Area",
    "Price / Sale", "Rent", "Deposit", "ROI %", "Possession",
    "Furnishing", "Status", "Owner / Contact Person", "Contact Number", "Source",
    "Remarks", "Listing Link", "Last Updated", "Remark",
    "Portfolio", "Transaction Type", "Google Maps URL", "Latitude", "Longitude",
    "Verification Status", "Last Verified Date", "Verified By", "Record ID", "Sync Updated At", "Archive Status"
)

data class SyncLogEntry(
    val logId: String = "LOG-${System.currentTimeMillis()}",
    val timestamp: String,
    val direction: String, // "APP_TO_SHEET", "SHEET_TO_APP", "VERIFICATION_TEST"
    val status: String, // "SUCCESS", "FAILED", "WARNING"
    val recordCount: Int,
    val details: String,
    val triggeredBy: String = "User"
)

data class DataReviewRow(
    val reviewId: String = "REV-${System.currentTimeMillis()}",
    val sourceFile: String,
    val rowNumber: Int,
    val rawData: String,
    val issueReason: String, // "DUPLICATE_CODE", "MISSING_MANDATORY", "INVALID_NUMBER", "UNRECOGNIZED_FORMAT"
    val suggestedCode: String? = null,
    val createdAt: String = "14 Oct 2026"
)

data class ColumnMappingItem(
    val sourceHeader: String,
    val targetStandardHeader: String,
    val sampleValue: String,
    val confidence: MappingConfidence,
    val isUnmapped: Boolean = false
)

enum class MappingConfidence(val label: String, val badgeColor: Long) {
    EXACT("Exact Match (100%)", 0xFF10B981),
    HIGH("High Confidence (>80%)", 0xFF059669),
    MEDIUM("Medium Confidence (>60%)", 0xFFD97706),
    MANUAL("Manual Selection", 0xFF3B82F6),
    UNMAPPED("Unmapped (Preserved in Remarks)", 0xFFEF4444)
}

enum class UserRole(val label: String) {
    OWNER("Owner"),
    BROKER("Broker"),
    ADMIN("Admin");

    companion object {
        fun fromString(value: String?): UserRole {
            return values().find { it.label.equals(value?.trim(), ignoreCase = true) } ?: ADMIN
        }
    }
}

data class UserProfile(
    val username: String = "Pavan Patil",
    val mobileNumber: String = "9766880099",
    val email: String = "Pavanpatil93@gmail.com",
    val role: UserRole = UserRole.ADMIN,
    val profilePhotoUri: String? = null
) {
    val contactInfo: String
        get() = if (email.isNotBlank()) email else mobileNumber
}

data class CompanyProfile(
    val companyName: String,
    val contact1: String = "9766880099",
    val contact2: String = "9766668099",
    val portfolio: String = "Commercial",
    val email: String = "contact@realestateinventory.in",
    val officeAddress: String = "Kharadi, Pune, Maharashtra",
    val whatsappFooter: String = "For private viewing and detailed brochure:\n📞 Call/WhatsApp: 9766880099 | 9766668099",
    val logoUri: String? = null
)

data class BrandLogos(
    val ascendLogoUri: String? = null,
    val aureaLogoUri: String? = null
) {
    val commercialLogoUri: String? get() = ascendLogoUri
    val residentialLogoUri: String? get() = aureaLogoUri
}

data class SchemaValidationResult(
    val isValid: Boolean,
    val totalColumnsFound: Int,
    val missingColumns: List<String>,
    val extraColumns: List<String>,
    val detailedMessage: String,
    val correctionGuidance: String
)

/**
 * Non-destructive Portfolio Classification
 * Reads the Portfolio field first; for legacy records with missing/blank portfolio,
 * derives the portfolio from existing property classification without altering source records.
 * Returns null if the property cannot be classified reliably.
 */
fun PropertyItem.effectivePortfolio(): StandardPortfolio? {
    if (portfolio.isNotBlank()) {
        val p = portfolio.lowercase().trim()
        if (p.contains("ascend") || p.contains("commercial")) return StandardPortfolio.ASCEND_COMMERCIAL
        if (p.contains("aurea") || p.contains("residential")) return StandardPortfolio.AUREA_RESIDENTIAL
    }

    // Legacy Category Mapping
    return when (tab) {
        InventoryTab.OFF_LEASE, InventoryTab.OFF_OUT,
        InventoryTab.SHOP_LEASE, InventoryTab.SHOP_OUT,
        InventoryTab.PRE_LEASED -> StandardPortfolio.ASCEND_COMMERCIAL

        InventoryTab.RESI_RENT, InventoryTab.RESI_RESALE,
        InventoryTab.UND_CONST -> StandardPortfolio.AUREA_RESIDENTIAL

        else -> {
            val pt = propertyType.lowercase().trim()
            val st = tab.code.lowercase().trim()
            when {
                pt.contains("office") || pt.contains("shop") || pt.contains("showroom") ||
                pt.contains("warehouse") || pt.contains("commercial") ||
                st.contains("off") || st.contains("shop") -> StandardPortfolio.ASCEND_COMMERCIAL

                pt.contains("apartment") || pt.contains("flat") || pt.contains("villa") ||
                pt.contains("bungalow") || pt.contains("residential") || pt.contains("plot") ||
                st.contains("resi") -> StandardPortfolio.AUREA_RESIDENTIAL

                else -> null // Ambiguous / Unclassified
            }
        }
    }
}

fun PropertyItem.isCommercial(): Boolean = effectivePortfolio() == StandardPortfolio.ASCEND_COMMERCIAL
fun PropertyItem.isResidential(): Boolean = effectivePortfolio() == StandardPortfolio.AUREA_RESIDENTIAL
fun PropertyItem.isUnclassified(): Boolean = effectivePortfolio() == null

enum class VerificationAgeState(val label: String, val badgeColor: Long) {
    CURRENT("Verified", 0xFF10B981),        // Green
    DUE("Verification Due", 0xFFF59E0B),    // Amber / Warning
    PENDING("Pending", 0xFFEF4444)          // Red / Orange
}

fun getVerificationAgeState(property: PropertyItem, validityDays: Int = 30): VerificationAgeState {
    if (property.verificationStatus != VerificationStatus.VERIFIED) {
        return VerificationAgeState.PENDING
    }
    val dateStr = property.lastVerifiedDateClean.ifBlank { property.lastVerificationDate }
    if (dateStr.isBlank()) return VerificationAgeState.PENDING
    
    val formatter = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.ENGLISH)
    val parsedDate = try {
        formatter.parse(dateStr)
    } catch (e: Exception) {
        try {
            java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ENGLISH).parse(dateStr)
        } catch (e2: Exception) {
            null
        }
    }
    
    if (parsedDate == null) return VerificationAgeState.PENDING
    
    val diffMillis = System.currentTimeMillis() - parsedDate.time
    val diffDays = diffMillis / (1000 * 60 * 60 * 24)
    
    return if (diffDays <= validityDays) {
        VerificationAgeState.CURRENT
    } else {
        VerificationAgeState.DUE
    }
}



