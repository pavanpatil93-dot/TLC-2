package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Brand
import com.example.model.PropertyItem
import com.example.model.UnderConstProject
import com.example.ui.theme.*

@Composable
fun WhatsAppShareDialog(
    property: PropertyItem? = null,
    project: UnderConstProject? = null,
    customMessage: String? = null,
    userSettingsManager: com.example.data.UserSettingsManager? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    val ascendProfile = userSettingsManager?.ascendCompanyProfile?.collectAsState()?.value
    val aureaProfile = userSettingsManager?.aureaCompanyProfile?.collectAsState()?.value

    val initialText = remember(property, project, customMessage, ascendProfile, aureaProfile) {
        if (!customMessage.isNullOrBlank()) {
            customMessage
        } else if (property != null) {
            val isCommercial = property.tab.brand == Brand.ASCEND_COMMERCIAL
            val brandProfile = if (isCommercial) ascendProfile else aureaProfile

            val brandName = brandProfile?.companyName ?: if (isCommercial) "ASCEND COMMERCIAL SOLUTIONS" else "AUREA LIVING"
            val contact1 = brandProfile?.contact1 ?: "9766880099"
            val contact2 = brandProfile?.contact2 ?: "9766668099"
            val footer = brandProfile?.whatsappFooter ?: "For private viewing and detailed brochure:\n📞 Call/WhatsApp: $contact1 | $contact2"

            val mediaText = if (property.images.isNotEmpty()) {
                "\n\n📸 *Property Media & Photo Gallery:* ${property.images.first()}"
            } else if (!property.videoUrl.isNullOrBlank()) {
                "\n\n🎬 *Video Walkthrough:* ${property.videoUrl}"
            } else if (!property.listingLink.isNullOrBlank()) {
                "\n\n🔗 *Property Listing Link:* ${property.listingLink}"
            } else ""

            """
*EXCLUSIVE LISTING | $brandName*

🏢 *${property.projectName.uppercase()}*
📍 *Location:* ${property.location}
📐 *Carpet Area:* ${property.carpetAreaSqFt.toInt()} sq.ft
🛋 *Furnishing:* ${property.furnishing.label}
💰 *Commercials:* ${com.example.model.CalculationUtils.formatIndianCurrency(property.priceOrRent, property.tab.isRental)}
🚗 *Parking:* ${property.parking}
🔑 *Possession:* ${property.possession}

🌟 *Key Features:*
${property.amenities.take(4).joinToString("\n") { "• $it" }}$mediaText

$footer
            """.trimIndent()
        } else if (project != null) {
            """
*PROJECT SHOWCASE | AUREA LIVING LLP*

🏢 *${project.projectName.uppercase()}*
📍 *Location:* ${project.location}
🏗 *Developer:* ${project.builderName}
📜 *MahaRERA:* ${project.mahaReraNumber}
🔑 *Possession:* ${project.possessionYear}
💰 *Starting From:* ${com.example.model.CalculationUtils.formatIndianCurrency(project.startingPrice)}

📐 *Available Configurations:*
${project.configurations.joinToString("\n") { "• ${it.configName} (${it.carpetAreaSqFt.toInt()} sq.ft) — ${com.example.model.CalculationUtils.formatIndianCurrency(it.price)}" }}

🌟 *Highlights:*
${project.amenities.take(4).joinToString("\n") { "• $it" }}

For floor plans and builder inventory:
📞 *Call/WhatsApp:* 9766880099 | 9766668099
            """.trimIndent()
        } else {
            "Contact Ascend & Aurea at 9766880099 | 9766668099"
        }
    }

    var shareText by remember { mutableStateOf(initialText) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .clip(RoundedCornerShape(20.dp))
                .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(20.dp))
                .testTag("whatsapp_share_dialog"),
            colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "WhatsApp Share Preview",
                            color = TextPrimaryDark,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Branded & Client-Safe Format",
                            color = AscendGold,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryDark)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandCharcoalDark)
                        .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = shareText,
                        color = Color(0xFFE2E8F0),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.SansSerif,
                        lineHeight = 18.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Property Share", shareText)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Copied to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AscendGold)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy")
                    }

                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, shareText)
                            }
                            context.startActivity(Intent.createChooser(intent, "Share Property via"))
                            onDismiss()
                        },
                        modifier = Modifier.weight(1.5f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AscendGold,
                            contentColor = BrandCharcoalDark
                        )
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Send via WhatsApp", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
