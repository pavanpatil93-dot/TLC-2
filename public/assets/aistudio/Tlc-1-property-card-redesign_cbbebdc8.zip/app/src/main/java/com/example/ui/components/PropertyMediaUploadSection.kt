package com.example.ui.components

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.FileStorageManager
import com.example.data.PropertyMediaManager
import com.example.model.AttachmentType
import com.example.model.PropertyAttachment
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

private const val MAX_PHOTOS_PER_PROPERTY = 20

@Composable
fun PropertyMediaUploadSection(
    photosList: List<String>,
    onPhotosChange: (List<String>) -> Unit,
    attachments: List<PropertyAttachment>,
    onAttachmentsChange: (List<PropertyAttachment>) -> Unit,
    videoUrl: String? = null,
    onVideoUrlChange: (String?) -> Unit = {},
    floorPlanUrl: String? = null,
    onFloorPlanUrlChange: (String?) -> Unit = {},
    propertyRecordId: String = ""
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isUploading by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableStateOf(0f) }
    var uploadStatusText by remember { mutableStateOf("") }
    var uploadError by remember { mutableStateOf<String?>(null) }

    var showVideoDialog by remember { mutableStateOf(false) }
    var videoInput by remember { mutableStateOf(videoUrl ?: "") }

    var photoIndexToReplace by remember { mutableStateOf<Int?>(null) }
    var tempCameraFileUri by remember { mutableStateOf<Uri?>(null) }
    var tempCameraFilePath by remember { mutableStateOf<String?>(null) }

    var lastFailedOperation by remember { mutableStateOf<(() -> Unit)?>(null) }
    var pendingAttachmentType by remember { mutableStateOf(AttachmentType.DOCUMENT) }

    fun syncMediaMetadata(updatedPhotos: List<String>, updatedVideo: String? = videoUrl) {
        if (propertyRecordId.isNotBlank()) {
            PropertyMediaManager.addOrUpdateMediaForProperty(
                context = context,
                propertyRecordId = propertyRecordId,
                photoPaths = updatedPhotos,
                videoUrl = updatedVideo
            )
        }
    }

    // Multi-photo Gallery Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = MAX_PHOTOS_PER_PROPERTY)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            if (photosList.size + uris.size > MAX_PHOTOS_PER_PROPERTY) {
                Toast.makeText(context, "Maximum $MAX_PHOTOS_PER_PROPERTY photos allowed per property. Some images were trimmed.", Toast.LENGTH_LONG).show()
            }
            val allowedUris = uris.take(MAX_PHOTOS_PER_PROPERTY - photosList.size)
            if (allowedUris.isEmpty()) return@rememberLauncherForActivityResult

            coroutineScope.launch {
                isUploading = true
                uploadError = null
                uploadProgress = 0.1f
                uploadStatusText = "Optimizing and saving ${allowedUris.size} photos..."

                try {
                    val savedPaths = mutableListOf<String>()
                    allowedUris.forEachIndexed { index, uri ->
                        uploadProgress = 0.1f + (0.8f * (index + 1) / allowedUris.size)
                        uploadStatusText = "Processing photo ${index + 1} of ${allowedUris.size} (Auto-compressed JPG/WEBP)..."
                        val localPath = FileStorageManager.savePhotoFromUri(context, uri)
                        savedPaths.add(localPath)
                        delay(40)
                    }
                    uploadProgress = 1f
                    uploadStatusText = "Saved ${savedPaths.size} photos permanently to storage!"
                    delay(200)
                    val newPhotoList = photosList + savedPaths
                    onPhotosChange(newPhotoList)
                    syncMediaMetadata(newPhotoList)
                    Toast.makeText(context, "Added ${savedPaths.size} photos permanently!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    uploadError = "Upload failed: ${e.localizedMessage}"
                    lastFailedOperation = {
                        Toast.makeText(context, "Retrying upload...", Toast.LENGTH_SHORT).show()
                    }
                    Toast.makeText(context, "Error saving photos: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    isUploading = false
                }
            }
        }
    }

    // Replace Specific Photo Launcher
    val replacePhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        val idx = photoIndexToReplace
        if (uri != null && idx != null) {
            coroutineScope.launch {
                isUploading = true
                uploadStatusText = "Optimizing and replacing photo #${idx + 1}..."
                uploadProgress = 0.5f
                try {
                    val localPath = FileStorageManager.savePhotoFromUri(context, uri)
                    uploadProgress = 1f
                    uploadStatusText = "Photo replaced successfully!"
                    delay(150)
                    val mutable = photosList.toMutableList()
                    if (idx in mutable.indices) {
                        mutable[idx] = localPath
                        onPhotosChange(mutable)
                        syncMediaMetadata(mutable)
                    }
                    Toast.makeText(context, "Photo #${idx + 1} replaced permanently!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    uploadError = "Failed to replace photo: ${e.localizedMessage}"
                } finally {
                    isUploading = false
                    photoIndexToReplace = null
                }
            }
        } else {
            photoIndexToReplace = null
        }
    }

    // Camera High-Res Photo Launcher
    val fullCameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        val rawPath = tempCameraFilePath
        if (success && rawPath != null) {
            coroutineScope.launch {
                if (photosList.size >= MAX_PHOTOS_PER_PROPERTY) {
                    Toast.makeText(context, "Maximum limit of $MAX_PHOTOS_PER_PROPERTY photos reached.", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                isUploading = true
                uploadStatusText = "Optimizing and saving high-res camera photo..."
                uploadProgress = 0.7f
                try {
                    delay(150)
                    uploadProgress = 1f
                    uploadStatusText = "Camera photo saved permanently!"
                    delay(150)
                    val newList = photosList + rawPath
                    onPhotosChange(newList)
                    syncMediaMetadata(newList)
                    Toast.makeText(context, "Camera photo saved permanently!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    uploadError = "Error saving camera photo: ${e.localizedMessage}"
                } finally {
                    isUploading = false
                }
            }
        }
    }

    // Video File Picker Launcher
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isUploading = true
                uploadStatusText = "Saving video file to permanent storage..."
                uploadProgress = 0.3f
                try {
                    val (fileName, fileSize) = FileStorageManager.getFileNameAndSize(context, uri)
                    val (savedPath, savedSize) = FileStorageManager.saveDocumentFromUri(context, uri, fileName)
                    uploadProgress = 1f
                    uploadStatusText = "Video file saved permanently!"
                    delay(200)

                    val videoAtt = PropertyAttachment(
                        id = UUID.randomUUID().toString(),
                        name = fileName,
                        type = AttachmentType.VIDEO,
                        localUriOrPath = savedPath,
                        fileSizeBytes = savedSize,
                        mimeType = "video/*"
                    )
                    onAttachmentsChange(attachments + videoAtt)
                    onVideoUrlChange(savedPath)
                    syncMediaMetadata(photosList, updatedVideo = savedPath)
                    Toast.makeText(context, "Video walkthrough saved permanently!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    uploadError = "Failed to save video: ${e.localizedMessage}"
                } finally {
                    isUploading = false
                }
            }
        }
    }

    // Document / PDF Picker Launcher
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isUploading = true
                uploadStatusText = "Saving document permanently..."
                uploadProgress = 0.4f
                try {
                    val (fileName, fileSize) = FileStorageManager.getFileNameAndSize(context, uri)
                    val (savedPath, savedSize) = FileStorageManager.saveDocumentFromUri(context, uri, fileName)
                    uploadProgress = 1f
                    uploadStatusText = "Document saved!"
                    delay(200)

                    val newAtt = PropertyAttachment(
                        id = UUID.randomUUID().toString(),
                        name = fileName,
                        type = pendingAttachmentType,
                        localUriOrPath = savedPath,
                        fileSizeBytes = savedSize,
                        mimeType = context.contentResolver.getType(uri) ?: "*/*"
                    )
                    onAttachmentsChange(attachments + newAtt)
                    if (pendingAttachmentType == AttachmentType.FLOOR_PLAN) {
                        onFloorPlanUrlChange(savedPath)
                    }
                    Toast.makeText(context, "${pendingAttachmentType.displayName} saved permanently!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    uploadError = "Failed to save document: ${e.localizedMessage}"
                } finally {
                    isUploading = false
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(BrandCharcoalCard)
            .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(14.dp))
            .padding(16.dp)
            .testTag("property_media_upload_section")
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PROPERTY MEDIA & GALLERY",
                    color = AscendGold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.8.sp
                )
                Text(
                    text = "Upload HD photos, cover image & video links (${photosList.size}/$MAX_PHOTOS_PER_PROPERTY)",
                    color = TextSecondaryDark,
                    fontSize = 11.sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(BrandCharcoalSurface)
                    .border(0.8.dp, AscendGold.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${photosList.size} Photos",
                    color = AscendGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Action Buttons: Select Photos & Take Camera Photo
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    if (photosList.size >= MAX_PHOTOS_PER_PROPERTY) {
                        Toast.makeText(context, "Maximum limit of $MAX_PHOTOS_PER_PROPERTY photos reached.", Toast.LENGTH_SHORT).show()
                    } else {
                        galleryLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("choose_photos_btn")
            ) {
                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Photos", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            }

            OutlinedButton(
                onClick = {
                    if (photosList.size >= MAX_PHOTOS_PER_PROPERTY) {
                        Toast.makeText(context, "Maximum limit of $MAX_PHOTOS_PER_PROPERTY photos reached.", Toast.LENGTH_SHORT).show()
                    } else {
                        try {
                            val (file, uri) = FileStorageManager.createCameraTempFileUri(context)
                            tempCameraFilePath = file.absolutePath
                            tempCameraFileUri = uri
                            fullCameraLauncher.launch(uri)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Unable to launch camera: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, BrandCharcoalBorder),
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("take_photo_camera_btn")
            ) {
                Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = AscendGold, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Take Photo", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            }
        }

        // Upload Status & Progress Indicator
        if (isUploading) {
            Spacer(modifier = Modifier.height(12.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(BrandCharcoalSurface)
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(uploadStatusText, color = TextPrimaryDark, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    Text("${(uploadProgress * 100).toInt()}%", color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { uploadProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = AscendGold,
                    trackColor = BrandCharcoalBorder
                )
            }
        }

        // Error banner with retry option
        if (uploadError != null && !isUploading) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFFEF2F2))
                    .border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(8.dp))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(uploadError ?: "", color = Color(0xFFDC2626), fontSize = 11.sp, modifier = Modifier.weight(1f))
                if (lastFailedOperation != null) {
                    TextButton(onClick = { lastFailedOperation?.invoke() }) {
                        Text("Retry", color = AscendGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Photos Horizontal Gallery with Cover Photo Badges & Actions
        if (photosList.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "SAVED PHOTOS (${photosList.size}) • TAP PHOTO TO SET AS COVER",
                color = TextMutedDark,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                itemsIndexed(photosList) { index, photoUrl ->
                    val isCover = index == 0
                    Box(
                        modifier = Modifier
                            .size(116.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(
                                width = if (isCover) 2.dp else 1.dp,
                                color = if (isCover) AscendGold else BrandCharcoalBorder,
                                shape = RoundedCornerShape(10.dp)
                            )
                            .background(BrandCharcoalSurface)
                    ) {
                        AsyncImage(
                            model = photoUrl,
                            contentDescription = "Photo ${index + 1}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable {
                                    if (!isCover) {
                                        val mutable = photosList.toMutableList()
                                        val item = mutable.removeAt(index)
                                        mutable.add(0, item)
                                        onPhotosChange(mutable)
                                        syncMediaMetadata(mutable)
                                        Toast.makeText(context, "Set as main cover photo!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        )

                        // Main Cover Badge
                        if (isCover) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(4.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(AscendGold)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("COVER", color = BrandCharcoalDark, fontSize = 8.sp, fontWeight = FontWeight.Black)
                            }
                        } else {
                            // Quick Set Cover Chip
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(4.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.Black.copy(alpha = 0.75f))
                                    .clickable {
                                        val mutable = photosList.toMutableList()
                                        val item = mutable.removeAt(index)
                                        mutable.add(0, item)
                                        onPhotosChange(mutable)
                                        syncMediaMetadata(mutable)
                                        Toast.makeText(context, "Set as main cover photo!", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            ) {
                                Text("SET COVER", color = AscendGold, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Top End: Delete Photo Button
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(4.dp)
                                .size(24.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black.copy(alpha = 0.75f))
                                .clickable {
                                    val mutable = photosList.toMutableList()
                                    mutable.removeAt(index)
                                    onPhotosChange(mutable)
                                    syncMediaMetadata(mutable)
                                    Toast.makeText(context, "Photo removed", Toast.LENGTH_SHORT).show()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Delete", tint = Color.White, modifier = Modifier.size(14.dp))
                        }

                        // Bottom End: Move Left/Right / Replace Button
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            if (index > 0) {
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color.Black.copy(alpha = 0.75f))
                                        .clickable {
                                            val mutable = photosList.toMutableList()
                                            val item = mutable.removeAt(index)
                                            mutable.add(index - 1, item)
                                            onPhotosChange(mutable)
                                            syncMediaMetadata(mutable)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.ChevronLeft, contentDescription = "Move Left", tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            }
                            if (index < photosList.size - 1) {
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color.Black.copy(alpha = 0.75f))
                                        .clickable {
                                            val mutable = photosList.toMutableList()
                                            val item = mutable.removeAt(index)
                                            mutable.add(index + 1, item)
                                            onPhotosChange(mutable)
                                            syncMediaMetadata(mutable)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.ChevronRight, contentDescription = "Move Right", tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))
        HorizontalDivider(color = BrandCharcoalBorder, thickness = 0.5.dp)
        Spacer(modifier = Modifier.height(14.dp))

        // SECTION 2: DOCUMENTS & ATTACHMENTS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PROPERTY DOCUMENTS & BROCHURES",
                    color = AscendGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
                Text(
                    text = "Upload PDF brochures, floor plans, legal mandates",
                    color = TextSecondaryDark,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Document Action Buttons
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        pendingAttachmentType = AttachmentType.PDF_BROCHURE
                        documentPickerLauncher.launch("application/pdf")
                    },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("upload_pdf_brochure_btn")
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("PDF Brochure", fontSize = 11.sp, color = TextPrimaryDark, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        pendingAttachmentType = AttachmentType.FLOOR_PLAN
                        documentPickerLauncher.launch("*/*")
                    },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("upload_floor_plan_btn")
                ) {
                    Icon(Icons.Default.Architecture, contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Floor Plan", fontSize = 11.sp, color = TextPrimaryDark, fontWeight = FontWeight.Bold)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        pendingAttachmentType = AttachmentType.DOCUMENT
                        documentPickerLauncher.launch("*/*")
                    },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("upload_document_btn")
                ) {
                    Icon(Icons.Default.Description, contentDescription = null, tint = AscendGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Property Doc", fontSize = 11.sp, color = TextPrimaryDark, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { showVideoDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("attach_video_btn")
                ) {
                    Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Video / Tour", fontSize = 11.sp, color = TextPrimaryDark, fontWeight = FontWeight.Bold)
                }
            }
        }

        // List of Uploaded Documents
        if (attachments.isNotEmpty() || !videoUrl.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "ATTACHED DOCUMENTS & MEDIA (${attachments.size + if (!videoUrl.isNullOrBlank()) 1 else 0})",
                color = TextMutedDark,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (!videoUrl.isNullOrBlank()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.SmartDisplay, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Property Walkthrough Video", color = TextPrimaryDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text(videoUrl, color = TextMutedDark, fontSize = 10.sp, maxLines = 1)
                                }
                            }
                            IconButton(onClick = {
                                onVideoUrlChange(null)
                                syncMediaMetadata(photosList, updatedVideo = null)
                            }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove", tint = TextSecondaryDark, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                attachments.forEach { att ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BrandCharcoalCard),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    imageVector = when (att.type) {
                                        AttachmentType.PDF_BROCHURE -> Icons.Default.PictureAsPdf
                                        AttachmentType.FLOOR_PLAN -> Icons.Default.Architecture
                                        AttachmentType.DOCUMENT -> Icons.Default.Description
                                        AttachmentType.VIDEO -> Icons.Default.Videocam
                                    },
                                    contentDescription = null,
                                    tint = Color(att.type.badgeColor),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(att.name, color = TextPrimaryDark, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color(att.type.badgeColor).copy(alpha = 0.2f))
                                                .padding(horizontal = 5.dp, vertical = 1.dp)
                                        ) {
                                            Text(att.type.displayName, color = Color(att.type.badgeColor), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Text(
                                        text = "${FileStorageManager.formatFileSize(att.fileSizeBytes)} • Saved permanently",
                                        color = TextSecondaryDark,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            IconButton(
                                onClick = {
                                    onAttachmentsChange(attachments.filter { it.id != att.id })
                                    Toast.makeText(context, "Attachment removed", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Video Dialog
    if (showVideoDialog) {
        AlertDialog(
            onDismissRequest = { showVideoDialog = false },
            title = { Text("Attach Video Walkthrough", color = AscendGold, fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Upload a video file from device storage or paste a walkthrough link:", color = TextSecondaryDark, fontSize = 11.sp)

                    Button(
                        onClick = {
                            showVideoDialog = false
                            videoPickerLauncher.launch("video/*")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandCharcoalCard, contentColor = AscendGold),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AscendGold.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(44.dp)
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pick Video File from Mobile Storage", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Text("OR PASTE VIDEO LINK (YouTube / Vimeo / Google Drive):", color = TextMutedDark, fontSize = 9.sp, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = videoInput,
                        onValueChange = { videoInput = it },
                        placeholder = { Text("https://youtu.be/... or https://drive.google.com/...", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val savedVideo = videoInput.trim().ifBlank { null }
                        onVideoUrlChange(savedVideo)
                        syncMediaMetadata(photosList, updatedVideo = savedVideo)
                        showVideoDialog = false
                        Toast.makeText(context, "Video link saved!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark)
                ) {
                    Text("Save Video Link", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showVideoDialog = false }) {
                    Text("Cancel", color = TextSecondaryDark)
                }
            },
            containerColor = BrandCharcoalSurface
        )
    }
}
