package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

enum class PortalNavTab(
    val label: String,
    val icon: ImageVector,
    val testTag: String
) {
    INVENTORY("Inventory", Icons.Default.HomeWork, "nav_tab_inventory"),
    SEARCH("Search", Icons.Default.Search, "nav_tab_search"),
    ADD("Add", Icons.Default.Add, "nav_tab_add"),
    AI_MATCH("AI Match", Icons.Default.AutoAwesome, "nav_tab_ai_match"),
    SAVED("Saved", Icons.Default.Bookmark, "nav_tab_saved")
}

@Composable
fun PortalBottomNavBar(
    selectedTab: PortalNavTab,
    onTabSelected: (PortalNavTab) -> Unit,
    savedCount: Int = 0,
    modifier: Modifier = Modifier
) {
    Surface(
        color = BrandCharcoalSurface,
        tonalElevation = 10.dp,
        modifier = modifier
            .fillMaxWidth()
            .border(0.8.dp, BrandCharcoalBorder)
            .testTag("portal_bottom_nav_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PortalNavTab.values().forEach { tab ->
                val isSelected = tab == selectedTab

                if (tab == PortalNavTab.ADD) {
                    // Central Prominent Gold Action Button for Add
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onTabSelected(tab) }
                            .testTag(tab.testTag)
                    ) {
                        Box(
                            modifier = Modifier
                                .offset(y = (-4).dp)
                                .size(44.dp)
                                .shadow(8.dp, CircleShape, spotColor = AscendGold)
                                .clip(CircleShape)
                                .background(AscendGold)
                                .border(1.5.dp, Color.White.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Property",
                                tint = BrandCharcoalDark,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Text(
                            text = tab.label,
                            color = AscendGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    // Standard Nav Items
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onTabSelected(tab) }
                            .padding(vertical = 4.dp)
                            .testTag(tab.testTag)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    if (isSelected) AscendGold.copy(alpha = 0.18f) else Color.Transparent
                                )
                                .padding(horizontal = 12.dp, vertical = 3.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                tint = if (isSelected) AscendGold else TextMutedDark,
                                modifier = Modifier.size(22.dp)
                            )

                            if (tab == PortalNavTab.SAVED && savedCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .offset(x = 6.dp, y = (-2).dp)
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(AscendGold)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = tab.label,
                            color = if (isSelected) AscendGold else TextMutedDark,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

