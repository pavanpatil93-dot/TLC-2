package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.model.*

@Composable
fun CrmInventoryMatchesDialog(
    segment: String, requirement: String, locations: String,
    inventory: List<PropertyItem>, onClose: () -> Unit
) {
    val locationTerms = locations.split(",", "/", ";", "|").map { it.trim().lowercase() }.filter { it.length >= 3 }
    val type = when {
        requirement.contains("showroom", true) -> "showroom"
        requirement.contains("office", true) -> "office"
        requirement.contains("shop", true) || requirement.contains("retail", true) -> "shop"
        requirement.contains("warehouse", true) -> "warehouse"
        else -> ""
    }
    val wantsLease = listOf("lease", "rent").any { requirement.contains(it, true) }
    val wantsSale = listOf("buy", "purchase", "sale").any { requirement.contains(it, true) }
    val bhk = Regex("""(\d+)\s*BHK""", RegexOption.IGNORE_CASE)
        .find(requirement)?.groupValues?.getOrNull(1)
    val matches = if (locationTerms.isEmpty()) emptyList() else inventory.filter { property ->
        (property.tab.isCommercial == (segment == "Commercial")) &&
            property.archiveStatus == ArchiveStatus.ACTIVE &&
            property.status == AvailabilityStatus.AVAILABLE &&
            (!wantsLease || wantsSale || property.tab.isRental) &&
            (!wantsSale || wantsLease || !property.tab.isRental) &&
            (bhk == null || property.bhk?.contains(bhk) == true) &&
            locationTerms.any { term ->
                property.location.lowercase().contains(term) ||
                    property.projectName.lowercase().contains(term)
            } &&
            (type.isEmpty() || property.propertyType.contains(type, true) ||
                (type == "shop" && property.tab.name.startsWith("SHOP")) ||
                (type == "office" && property.tab.name.startsWith("OFF_")))
    }.sortedWith(compareBy<PropertyItem> { it.verificationStatus != VerificationStatus.VERIFIED }
        .thenBy { it.location.lowercase() }).take(30)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Matching inventory: ${matches.size}") },
        text = {
            Column {
                Text("Rule-based suggestions: active and available listings only, matching location/building, portfolio, transaction, type and BHK when provided. Verified records appear first. Budget, area and current availability still require confirmation.",
                    style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(matches) { property ->
                        Card {
                            Column(Modifier.padding(10.dp)) {
                                Text(property.projectName.ifBlank { "Unnamed property" })
                                Text("${property.location} • ${property.propertyType}")
                                Text("Code: ${property.propertyCode}")
                                Text("Location match • ${if (property.verificationStatus == VerificationStatus.VERIFIED) "Verified record" else "Verification pending"}",
                                    style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    if (matches.isEmpty()) item { Text("No matching available inventory found. Check location and inventory status.") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}
