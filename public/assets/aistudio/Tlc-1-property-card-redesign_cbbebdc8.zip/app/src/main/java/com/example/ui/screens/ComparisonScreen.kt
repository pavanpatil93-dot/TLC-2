package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CalculationUtils
import com.example.model.PropertyItem
import com.example.ui.theme.*

@Composable
fun ComparisonScreen(
    comparisonProperties: List<PropertyItem>,
    onRemoveProperty: (String) -> Unit,
    onClearAll: () -> Unit,
    onShareComparisonWhatsApp: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandCharcoalDark)
            .testTag("comparison_screen")
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Property Comparison",
                        color = TextPrimaryDark,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "SIDE-BY-SIDE INVENTORY MATRIX (${comparisonProperties.size}/4)",
                        color = AscendGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.8.sp
                    )
                }

                if (comparisonProperties.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = onClearAll) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear", tint = TextMutedDark)
                        }
                        Button(
                            onClick = onShareComparisonWhatsApp,
                            colors = ButtonDefaults.buttonColors(containerColor = AscendGold, contentColor = BrandCharcoalDark),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (comparisonProperties.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No Properties Selected for Comparison",
                        color = TextPrimaryDark,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Tap the compare icon on any property card to compare up to 4 listings side-by-side.",
                        color = TextSecondaryDark,
                        fontSize = 12.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            // Scrollable Comparison Matrix
            val horizontalScrollState = rememberScrollState()
            val verticalScrollState = rememberScrollState()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(verticalScrollState)
                    .padding(bottom = 80.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(horizontalScrollState)
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    comparisonProperties.forEach { prop ->
                        ComparisonColumn(
                            property = prop,
                            onRemove = { onRemoveProperty(prop.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ComparisonColumn(
    property: PropertyItem,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(220.dp)
            .border(1.dp, BrandCharcoalBorder, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = BrandCharcoalSurface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header with delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(AscendGold.copy(alpha = 0.2f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(property.propertyCode, color = AscendGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }

                IconButton(onClick = onRemove, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = TextMutedDark, modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = property.projectName,
                color = TextPrimaryDark,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = property.location,
                color = TextSecondaryDark,
                fontSize = 11.sp,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = BrandCharcoalBorder)
            Spacer(modifier = Modifier.height(10.dp))

            // Spec Comparisons
            ComparisonCell(label = "Category", value = property.tab.code)
            ComparisonCell(label = "Commercials", value = CalculationUtils.formatIndianCurrency(property.priceOrRent, property.tab.isRental))

            val rate = if (property.tab.isRental) {
                CalculationUtils.calculateRentPerCarpet(property.priceOrRent, property.carpetAreaSqFt)
            } else {
                CalculationUtils.calculateRatePerCarpet(property.priceOrRent, property.carpetAreaSqFt)
            }
            ComparisonCell(label = "Rate / Carpet", value = if (rate != null) "₹${rate.toInt()}/sqft" else "N/A")
            ComparisonCell(label = "Carpet Area", value = "${property.carpetAreaSqFt.toInt()} sq.ft")
            ComparisonCell(label = "Furnishing", value = property.furnishing.label)
            ComparisonCell(label = "Possession", value = property.possession)
            ComparisonCell(label = "Parking", value = property.parking)
            ComparisonCell(label = "Status", value = property.status.label)
        }
    }
}

@Composable
fun ComparisonCell(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(text = label, color = TextMutedDark, fontSize = 9.sp, fontWeight = FontWeight.Medium)
        Text(text = value, color = TextPrimaryDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
