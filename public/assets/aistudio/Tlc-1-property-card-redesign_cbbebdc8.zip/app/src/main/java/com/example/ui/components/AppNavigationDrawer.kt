package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Brand
import com.example.model.BrandLogos
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.ui.theme.*

enum class DrawerDestination(
    val title: String,
    val icon: ImageVector,
    val isComingSoon: Boolean = false
) {
    INVENTORY_DASHBOARD("Inventory Dashboard", Icons.Default.Dashboard),
    CRM_WORKSPACE("CRM Workspace", Icons.Default.Groups),
    CRM_CALLS("Call Intelligence", Icons.Default.Call),
    SEARCH_PROPERTIES("Search & Filter Properties", Icons.Default.Search),
    ASCEND_COMMERCIAL("Commercial (Ascend)", Icons.Default.Business),
    AUREA_RESIDENTIAL("Residential (Aurea)", Icons.Default.Apartment),
    ADD_PROPERTY("Add Property", Icons.Default.AddCircleOutline),
    CLIENT_MATCHER("Client Requirement Matcher", Icons.Default.PersonSearch),
    AI_SEARCH("AI Inventory Search", Icons.Default.AutoAwesome),
    FIND_ON_MAP("Find Properties on Map", Icons.Default.Map),
    SAVED_PROPERTIES("Saved Properties", Icons.Default.Bookmark),
    COMPARE_PROPERTIES("Compare Properties", Icons.Default.CompareArrows),
    MASTER_SYNC("Master Sheet Sync", Icons.Default.CloudSync),
    SETTINGS("Settings", Icons.Default.Settings)
}

@Composable
fun AppDrawerContent(
    currentDestination: DrawerDestination,
    selectedBrand: Brand?,
    brandLogos: BrandLogos,
    userProfile: UserProfile,
    commercialCount: Int,
    residentialCount: Int,
    comparisonCount: Int,
    savedCount: Int,
    unclassifiedCount: Int,
    onNavigate: (DrawerDestination) -> Unit,
    onCloseDrawer: () -> Unit,
    crmMode: Boolean = false,
    isDesktopCompact: Boolean = false,
    onToggleDesktopCompact: (() -> Unit)? = null
) {
    Surface(
        color = BrandCharcoalDark,
        modifier = Modifier
            .fillMaxHeight()
            .width(if (isDesktopCompact) 72.dp else 290.dp)
            .testTag("app_navigation_drawer")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // =================================================================
            // DRAWER HEADER
            // =================================================================
            if (!isDesktopCompact) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        BrandLogoView(
                            brand = selectedBrand,
                            customLogoUri = when (selectedBrand) {
                                Brand.ASCEND_COMMERCIAL -> brandLogos.ascendLogoUri
                                Brand.AUREA_LIVING -> brandLogos.aureaLogoUri
                                null -> null
                            },
                            size = 36.dp
                        )
                        Column {
                            Text(
                                text = if (crmMode) "CLIENT RELATIONSHIP MANAGER" else "PROPERTY INVENTORY",
                                color = TextPrimaryDark,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = if (crmMode) "LEADS • FOLLOW-UPS • MATCHING" else "SEARCH • FILTER • MANAGE",
                                color = AscendGold,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    // Explicit Close Button for Mobile Drawer
                    IconButton(
                        onClick = onCloseDrawer,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(BrandCharcoalSurface)
                            .testTag("drawer_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Sidebar",
                            tint = TextSecondaryDark,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                HorizontalDivider(color = BrandCharcoalBorder, thickness = 0.8.dp)
            } else {
                // Compact icon mode header
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    BrandLogoView(
                        brand = selectedBrand,
                        customLogoUri = when (selectedBrand) {
                            Brand.ASCEND_COMMERCIAL -> brandLogos.ascendLogoUri
                            Brand.AUREA_LIVING -> brandLogos.aureaLogoUri
                            null -> null
                        },
                        size = 32.dp
                    )
                    if (onToggleDesktopCompact != null) {
                        IconButton(onClick = onToggleDesktopCompact, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.MenuOpen, contentDescription = "Expand", tint = AscendGold)
                        }
                    }
                }
                HorizontalDivider(color = BrandCharcoalBorder, thickness = 0.8.dp)
            }

            // =================================================================
            // SCROLLABLE NAVIGATION ITEMS
            // =================================================================
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 8.dp, horizontal = if (isDesktopCompact) 6.dp else 10.dp)
            ) {
                if (!isDesktopCompact) {
                    Text(
                        text = if (crmMode) "CRM WORKSPACE" else "INVENTORY WORKSPACE",
                        color = AscendGold,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                    OutlinedButton(
                        onClick = {
                            onNavigate(if (crmMode) DrawerDestination.SEARCH_PROPERTIES else DrawerDestination.CRM_WORKSPACE)
                            onCloseDrawer()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.SwapHoriz, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (crmMode) "Switch to Inventory" else "Switch to CRM")
                    }
                }
                // Keep the drawer for navigation, not duplicate on-screen filters/actions.
                // Existing screens remain accessible through their in-screen controls.
                val workspaceDestinations = if (crmMode) listOf(
                    DrawerDestination.CRM_WORKSPACE,
                    DrawerDestination.CRM_CALLS,
                    DrawerDestination.CLIENT_MATCHER,
                    DrawerDestination.SETTINGS
                ) else listOf(
                    DrawerDestination.SEARCH_PROPERTIES,
                    DrawerDestination.SAVED_PROPERTIES,
                    DrawerDestination.COMPARE_PROPERTIES,
                    DrawerDestination.FIND_ON_MAP,
                    DrawerDestination.MASTER_SYNC,
                    DrawerDestination.SETTINGS
                )
                workspaceDestinations.forEach { destination ->
                    if (!isDesktopCompact && destination == DrawerDestination.SETTINGS) {
                        Spacer(Modifier.height(12.dp))
                        HorizontalDivider(color = BrandCharcoalBorder)
                        Text(
                            text = "COMMON SETTINGS & TECHNICAL",
                            color = TextSecondaryDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp)
                        )
                    }
                    if (!isDesktopCompact && destination == DrawerDestination.CLIENT_MATCHER) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "CLIENT & PROPERTY MATCHING",
                            color = TextSecondaryDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                    val isSelected = currentDestination == destination

                    val badgeText = when (destination) {
                        DrawerDestination.ASCEND_COMMERCIAL -> "$commercialCount"
                        DrawerDestination.AUREA_RESIDENTIAL -> "$residentialCount"
                        DrawerDestination.COMPARE_PROPERTIES -> if (comparisonCount > 0) "$comparisonCount" else null
                        DrawerDestination.SAVED_PROPERTIES -> if (savedCount > 0) "$savedCount" else null
                        DrawerDestination.FIND_ON_MAP -> null
                        else -> null
                    }

                    val badgeColor = when (destination) {
                        DrawerDestination.ASCEND_COMMERCIAL -> AscendGold
                        DrawerDestination.AUREA_RESIDENTIAL -> Color(0xFF10B981)
                        DrawerDestination.FIND_ON_MAP -> Color(0xFF8B5CF6)
                        DrawerDestination.COMPARE_PROPERTIES -> AscendGold
                        else -> TextSecondaryDark
                    }

                    if (isDesktopCompact) {
                        // Compact Icon Mode
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) AscendGold.copy(alpha = 0.2f) else Color.Transparent)
                                .clickable {
                                    onNavigate(destination)
                                    onCloseDrawer()
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = destination.icon,
                                contentDescription = destination.title,
                                tint = if (isSelected) AscendGold else TextSecondaryDark,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    } else {
                        // Full Drawer Item
                        Surface(
                            onClick = {
                                onNavigate(destination)
                                onCloseDrawer()
                            },
                            color = if (isSelected) AscendGold.copy(alpha = 0.15f) else Color.Transparent,
                            shape = RoundedCornerShape(10.dp),
                            border = if (isSelected) {
                                androidx.compose.foundation.BorderStroke(1.dp, AscendGold.copy(alpha = 0.6f))
                            } else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .testTag("drawer_item_${destination.name.lowercase()}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = destination.icon,
                                        contentDescription = null,
                                        tint = if (isSelected) AscendGold else TextSecondaryDark,
                                        modifier = Modifier.size(19.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = destination.title,
                                        color = if (isSelected) AscendGold else TextPrimaryDark,
                                        fontSize = 12.5.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                if (badgeText != null) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(badgeColor.copy(alpha = 0.2f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = badgeText,
                                            color = badgeColor,
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = BrandCharcoalBorder, thickness = 0.8.dp)

            // =================================================================
            // BOTTOM USER PROFILE SECTION (Owner / Broker / Admin)
            // =================================================================
            if (!isDesktopCompact) {
                Surface(
                    onClick = {
                        onNavigate(DrawerDestination.SETTINGS)
                        onCloseDrawer()
                    },
                    color = BrandCharcoalSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("drawer_user_profile_section")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            // User Initial Avatar
                            val roleRingColor = when (userProfile.role) {
                                UserRole.ADMIN -> AscendGold
                                UserRole.BROKER -> Color(0xFF3B82F6)
                                UserRole.OWNER -> Color(0xFF10B981)
                            }

                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(BrandCharcoalCard)
                                    .border(1.5.dp, roleRingColor, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                val initials = userProfile.username
                                    .split(" ")
                                    .filter { it.isNotBlank() }
                                    .map { it.first() }
                                    .take(2)
                                    .joinToString("")
                                    .uppercase()
                                    .ifBlank { "U" }
                                Text(
                                    text = initials,
                                    color = roleRingColor,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = userProfile.username,
                                    color = TextPrimaryDark,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = userProfile.contactInfo,
                                    color = TextSecondaryDark,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Role Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    when (userProfile.role) {
                                        UserRole.ADMIN -> AscendGold.copy(alpha = 0.2f)
                                        UserRole.BROKER -> Color(0xFF3B82F6).copy(alpha = 0.2f)
                                        UserRole.OWNER -> Color(0xFF10B981).copy(alpha = 0.2f)
                                    }
                                )
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = userProfile.role.label.uppercase(),
                                color = when (userProfile.role) {
                                    UserRole.ADMIN -> AscendGold
                                    UserRole.BROKER -> Color(0xFF93C5FD)
                                    UserRole.OWNER -> Color(0xFF6EE7B7)
                                },
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            } else {
                // Compact profile icon
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .clickable {
                            onNavigate(DrawerDestination.SETTINGS)
                            onCloseDrawer()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(AscendGold.copy(alpha = 0.2f))
                            .border(1.dp, AscendGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Person, contentDescription = "Profile", tint = AscendGold, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
