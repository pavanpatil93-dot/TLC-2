package com.example.ai

import android.util.Log
import com.example.BuildConfig
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ExtractedPropertyDraft(
    val tab: InventoryTab = InventoryTab.OFF_LEASE,
    val propertyType: String = "Commercial Office",
    val projectName: String = "",
    val location: String = "",
    val unitNumber: String = "",
    val floor: String = "Mid Floor",
    val carpetAreaSqFt: Double = 0.0,
    val builtUpAreaSqFt: Double? = null,
    val priceOrRent: Double = 0.0,
    val priceSale: Double? = null,
    val rent: Double? = null,
    val deposit: Double? = null,
    val furnishing: FurnishingType = FurnishingType.SEMI_FURNISHED,
    val possession: String = "Immediate",
    val contactName: String = "",
    val contactPhone: String = "",
    val remarks: String = "",
    val confidenceNotes: String = ""
)

data class ClientMatchCategory(
    val categoryName: String,
    val results: List<ClientMatchResult>
)

data class ClientMatchResult(
    val property: PropertyItem,
    val matchScorePercent: Int,
    val matchingReasons: List<String>,
    val matchType: String // "Exact Match", "Close Match", "Alternative"
)

data class ExtractedClientRequirement(
    val rawPrompt: String = "",
    val portfolio: Brand? = null, // ASCEND_COMMERCIAL or AUREA_LIVING or null
    val propertyType: String = "",
    val transactionType: String = "", // "Lease" or "Sale"
    val minPriceOrRent: Double? = null,
    val maxPriceOrRent: Double? = null,
    val minCarpetSqFt: Double? = null,
    val maxCarpetSqFt: Double? = null,
    val locations: List<String> = emptyList(),
    val furnishing: FurnishingType? = null,
    val bhkConfig: String? = null,
    val possession: String? = null,
    val isVague: Boolean = false,
    val extractionSource: String = "Gemini 3.5 Flash Model"
) {
    fun toCriteriaSummary(): String {
        val parts = mutableListOf<String>()
        val portfolioText = when (portfolio) {
            Brand.ASCEND_COMMERCIAL -> "Commercial Portfolio"
            Brand.AUREA_LIVING -> "Residential Portfolio"
            null -> "All Portfolios"
        }
        parts.add(portfolioText)
        if (propertyType.isNotBlank()) parts.add(propertyType)
        if (transactionType.isNotBlank()) parts.add(transactionType)
        if (locations.isNotEmpty()) parts.add(locations.joinToString(", "))
        if (minCarpetSqFt != null || maxCarpetSqFt != null) {
            val min = minCarpetSqFt?.toInt() ?: 0
            val max = maxCarpetSqFt?.toInt()
            parts.add(if (max != null && min > 0) "$min–$max sq.ft." else if (max != null) "Up to $max sq.ft." else "Min $min sq.ft.")
        }
        if (maxPriceOrRent != null && maxPriceOrRent > 0) {
            val isRental = transactionType.contains("lease", ignoreCase = true) || transactionType.contains("rent", ignoreCase = true)
            val formattedMax = CalculationUtils.formatIndianCurrency(maxPriceOrRent, isRental)
            parts.add("Max $formattedMax")
        }
        if (furnishing != null) parts.add(furnishing.label)
        if (bhkConfig != null) parts.add(bhkConfig)
        return parts.joinToString(" • ")
    }
}

data class NaturalSearchResult(
    val exactMatches: List<PropertyItem>,
    val alternatives: List<PropertyItem>,
    val isVague: Boolean,
    val extractedRequirement: ExtractedClientRequirement
)

class GeminiRealEstateService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * AI SMART PROPERTY ADD
     * Extracts structured 24-column inventory fields from pasted text. Never invents missing values.
     */
    suspend fun parsePropertyMessage(rawText: String, defaultCompanyPrefix: String = "ACS"): ExtractedPropertyDraft = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val prompt = """
You are a senior real estate data ingestion specialist for PROPERTY OS.
Extract structured inventory fields from this raw broker/client text:
"${rawText.replace("\"", "'")}"

CRITICAL RULES:
- NEVER invent missing information. If a field is missing, leave it empty or null.
- Output ONLY a JSON object with keys:
  "tab": one of ["Off Lease", "Off Out", "Shop Lease", "Shop Out", "Pre - Leased", "Resi Rent", "Resi Resale", "Und Const"]
  "propertyType": string (e.g. "Commercial Office", "Retail Showroom", "Residential Apartment", "Pre-Leased Commercial")
  "projectName": string
  "location": string (e.g. "Kharadi, Pune")
  "unitNumber": string
  "floor": string
  "carpetAreaSqFt": number
  "builtUpAreaSqFt": number or null
  "priceSale": number or null (sale outright price)
  "rent": number or null (monthly rent)
  "deposit": number or null
  "furnishing": one of ["Bare Shell", "Warm Shell", "Semi-Furnished", "Fully Furnished", "Unfurnished"]
  "possession": string
  "contactName": string
  "contactPhone": string
  "remarks": string
                """.trimIndent()

                val jsonPayload = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply { put("text", prompt) })
                            })
                        })
                    })
                    put("generationConfig", JSONObject().apply {
                        put("responseMimeType", "application/json")
                    })
                }

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
                val request = Request.Builder()
                    .url(url)
                    .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string().orEmpty()

                if (response.isSuccessful) {
                    val root = JSONObject(responseBody)
                    val text = root.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")

                    val parsed = JSONObject(text)
                    val tabStr = parsed.optString("tab", "Off Lease")
                    val matchedTab = InventoryTab.values().find { it.code.equals(tabStr, ignoreCase = true) } ?: InventoryTab.OFF_LEASE
                    val furnStr = parsed.optString("furnishing", "Semi-Furnished")
                    val matchedFurn = FurnishingType.values().find { it.label.equals(furnStr, ignoreCase = true) } ?: FurnishingType.SEMI_FURNISHED

                    val rentVal = if (parsed.has("rent") && !parsed.isNull("rent")) parsed.optDouble("rent") else null
                    val saleVal = if (parsed.has("priceSale") && !parsed.isNull("priceSale")) parsed.optDouble("priceSale") else null
                    val primaryPrice = if (matchedTab.isRental) (rentVal ?: 0.0) else (saleVal ?: 0.0)

                    return@withContext ExtractedPropertyDraft(
                        tab = matchedTab,
                        propertyType = parsed.optString("propertyType", if (matchedTab.isCommercial) "Commercial Office" else "Residential Flat"),
                        projectName = parsed.optString("projectName", "Commercial Center"),
                        location = parsed.optString("location", "Pune"),
                        unitNumber = parsed.optString("unitNumber", "Available Unit"),
                        floor = parsed.optString("floor", "Mid Floor"),
                        carpetAreaSqFt = parsed.optDouble("carpetAreaSqFt", 0.0),
                        builtUpAreaSqFt = if (parsed.has("builtUpAreaSqFt") && !parsed.isNull("builtUpAreaSqFt")) parsed.optDouble("builtUpAreaSqFt") else null,
                        priceOrRent = primaryPrice,
                        priceSale = saleVal,
                        rent = rentVal,
                        deposit = if (parsed.has("deposit") && !parsed.isNull("deposit")) parsed.optDouble("deposit") else null,
                        furnishing = matchedFurn,
                        possession = parsed.optString("possession", "Immediate"),
                        contactName = parsed.optString("contactName", "Broker / Owner"),
                        contactPhone = parsed.optString("contactPhone", ""),
                        remarks = parsed.optString("remarks", ""),
                        confidenceNotes = "Extracted via Gemini 3.5 Flash Model"
                    )
                }
            } catch (e: Exception) {
                Log.w("GeminiRealEstate", "Gemini error: ${e.message}")
            }
        }

        return@withContext fallbackParseProperty(rawText)
    }

    private fun fallbackParseProperty(text: String): ExtractedPropertyDraft {
        val lower = text.lowercase()

        val tab = when {
            lower.contains("pre-leased") || lower.contains("roi") || lower.contains("yield") -> InventoryTab.PRE_LEASED
            lower.contains("shop") && (lower.contains("sale") || lower.contains("outright")) -> InventoryTab.SHOP_OUT
            lower.contains("shop") || lower.contains("showroom") -> InventoryTab.SHOP_LEASE
            (lower.contains("office") || lower.contains("commercial")) && (lower.contains("sale") || lower.contains("outright")) -> InventoryTab.OFF_OUT
            lower.contains("office") || lower.contains("commercial") || lower.contains("workstation") -> InventoryTab.OFF_LEASE
            lower.contains("under construction") || lower.contains("rera") -> InventoryTab.UND_CONST
            (lower.contains("bhk") || lower.contains("flat") || lower.contains("apartment")) && (lower.contains("rent") || lower.contains("lease")) -> InventoryTab.RESI_RENT
            lower.contains("bhk") || lower.contains("resale") -> InventoryTab.RESI_RESALE
            else -> InventoryTab.OFF_LEASE
        }

        val sqftRegex = Regex("""(\d+[\d,.]*)\s*(sq\.?ft|sqft|sft|carpet)""", RegexOption.IGNORE_CASE)
        val carpet = sqftRegex.find(text)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: 1000.0

        var price = 0.0
        val crRegex = Regex("""(\d+[\d,.]*)\s*(cr|crore)""", RegexOption.IGNORE_CASE)
        val lacRegex = Regex("""(\d+[\d,.]*)\s*(lac|lakh|lacs)""", RegexOption.IGNORE_CASE)
        val kRegex = Regex("""(\d+[\d,.]*)\s*(k|thousand)""", RegexOption.IGNORE_CASE)

        crRegex.find(text)?.let { price = (it.groupValues[1].toDoubleOrNull() ?: 0.0) * 10_000_000.0 }
            ?: lacRegex.find(text)?.let { price = (it.groupValues[1].toDoubleOrNull() ?: 0.0) * 100_000.0 }
            ?: kRegex.find(text)?.let { price = (it.groupValues[1].toDoubleOrNull() ?: 0.0) * 1_000.0 }

        if (price == 0.0) {
            val rentRegex = Regex("""rent[:\s]*₹?\s*(\d[\d,]*)""", RegexOption.IGNORE_CASE)
            rentRegex.find(text)?.let { price = it.groupValues[1].replace(",", "").toDoubleOrNull() ?: 85000.0 }
        }
        if (price == 0.0) price = if (tab.isRental) 85000.0 else 12500000.0

        val phoneRegex = Regex("""(\+91[\-\s]?)?[6-9]\d{9}""")
        val phone = phoneRegex.find(text)?.value ?: ""

        val furnishing = when {
            lower.contains("fully furnished") || lower.contains("fully-furnished") -> FurnishingType.FULLY_FURNISHED
            lower.contains("semi furnished") || lower.contains("semi-furnished") -> FurnishingType.SEMI_FURNISHED
            lower.contains("warm shell") -> FurnishingType.WARM_SHELL
            lower.contains("bare shell") -> FurnishingType.BARE_SHELL
            else -> FurnishingType.UNFURNISHED
        }

        val locations = listOf("Kharadi", "Baner", "Viman Nagar", "Balewadi", "Hinjawadi", "Koregaon Park", "Shivaji Nagar", "Magarpatta", "Hadapsar", "Aundh")
        val foundLoc = locations.find { lower.contains(it.lowercase()) } ?: "Kharadi"

        return ExtractedPropertyDraft(
            tab = tab,
            propertyType = if (tab.isCommercial) "Commercial Office" else "Residential Flat",
            projectName = if (lower.contains("imperium")) "Gera Imperium Alpha" else "Prime Center",
            location = "$foundLoc, Pune",
            unitNumber = "Available Unit",
            floor = "Mid Floor",
            carpetAreaSqFt = carpet,
            priceOrRent = price,
            priceSale = if (!tab.isRental) price else null,
            rent = if (tab.isRental) price else null,
            deposit = if (tab.isRental) price * 6.0 else null,
            furnishing = furnishing,
            possession = "Immediate",
            contactPhone = phone,
            remarks = text.take(120),
            confidenceNotes = "Extracted via Smart Extraction Engine"
        )
    }

    /**
     * STEP 7: AI NATURAL LANGUAGE PROPERTY SEARCH EXTRACTION
     * Uses Gemini 3.5 Flash to extract structured search criteria or falls back to rule-based pattern engine.
     */
    suspend fun extractRequirementsWithGemini(query: String): ExtractedClientRequirement = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val prompt = """
You are a real estate AI assistant for Commercial & Residential property inventory in Pune, India.
Analyze this client requirement query/message:
"${query.replace("\"", "'")}"

Extract structured search criteria into a JSON object with these exact keys:
- "portfolio": "COMMERCIAL" or "RESIDENTIAL" or "AUTO"
- "propertyType": string (e.g. "Office", "Shop", "Showroom", "Warehouse", "Pre-Leased", "1 BHK", "2 BHK", "3 BHK", "4 BHK", "Villa", "Apartment", "Plot")
- "transactionType": "Lease" or "Sale" or ""
- "minPriceOrRent": number or null (monthly rent in ₹ or sale price in ₹)
- "maxPriceOrRent": number or null (monthly rent in ₹ or sale price in ₹, e.g. 2 lakh = 200000, 1.5 Cr = 15000000)
- "minCarpetSqFt": number or null
- "maxCarpetSqFt": number or null
- "locations": array of strings (e.g. ["Kharadi", "Baner"])
- "furnishing": "Bare Shell" or "Warm Shell" or "Semi-Furnished" or "Fully Furnished" or "Unfurnished" or null
- "bhkConfig": string or null (e.g. "2 BHK", "3 BHK")
- "isVague": boolean (true if query is broad like 'properties in Pune' without specific budget, type, or location)

Rules:
- 1 lakh / 1 lac = 100,000
- 1 crore / 1 cr = 10,000,000
- Auto-detect portfolio if ambiguous: Commercial for Office/Shop/Showroom/Warehouse/Pre-Leased; Residential for BHK/Flat/Villa/Apartment.
- Return ONLY valid JSON without markdown code fences.
                """.trimIndent()

                val jsonPayload = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply { put("text", prompt) })
                            })
                        })
                    })
                    put("generationConfig", JSONObject().apply {
                        put("responseMimeType", "application/json")
                    })
                }

                val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
                val request = Request.Builder()
                    .url(url)
                    .post(jsonPayload.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string().orEmpty()

                if (response.isSuccessful) {
                    val root = JSONObject(responseBody)
                    val text = root.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")

                    val parsed = JSONObject(text)
                    val portStr = parsed.optString("portfolio", "AUTO")
                    val portBrand = when {
                        portStr.contains("COMMERCIAL", ignoreCase = true) -> Brand.ASCEND_COMMERCIAL
                        portStr.contains("RESIDENTIAL", ignoreCase = true) -> Brand.AUREA_LIVING
                        else -> detectPortfolioFromQuery(query)
                    }

                    val furnStr = parsed.optString("furnishing", "")
                    val furnType = FurnishingType.values().find { it.label.equals(furnStr, ignoreCase = true) }

                    val locList = mutableListOf<String>()
                    val locArray = parsed.optJSONArray("locations")
                    if (locArray != null) {
                        for (i in 0 until locArray.length()) {
                            locList.add(locArray.getString(i))
                        }
                    }

                    return@withContext ExtractedClientRequirement(
                        rawPrompt = query,
                        portfolio = portBrand,
                        propertyType = parsed.optString("propertyType", ""),
                        transactionType = parsed.optString("transactionType", ""),
                        minPriceOrRent = if (parsed.has("minPriceOrRent") && !parsed.isNull("minPriceOrRent")) parsed.optDouble("minPriceOrRent") else null,
                        maxPriceOrRent = if (parsed.has("maxPriceOrRent") && !parsed.isNull("maxPriceOrRent")) parsed.optDouble("maxPriceOrRent") else null,
                        minCarpetSqFt = if (parsed.has("minCarpetSqFt") && !parsed.isNull("minCarpetSqFt")) parsed.optDouble("minCarpetSqFt") else null,
                        maxCarpetSqFt = if (parsed.has("maxCarpetSqFt") && !parsed.isNull("maxCarpetSqFt")) parsed.optDouble("maxCarpetSqFt") else null,
                        locations = locList,
                        furnishing = furnType,
                        bhkConfig = if (parsed.has("bhkConfig") && !parsed.isNull("bhkConfig")) parsed.optString("bhkConfig") else null,
                        isVague = parsed.optBoolean("isVague", false),
                        extractionSource = "Gemini 3.5 Flash Model"
                    )
                }
            } catch (e: Exception) {
                Log.w("GeminiRealEstate", "Gemini search extraction error: ${e.message}")
            }
        }

        return@withContext fallbackExtractRequirements(query)
    }

    fun fallbackExtractRequirements(query: String): ExtractedClientRequirement {
        val lower = query.lowercase()

        val portfolio = detectPortfolioFromQuery(query)

        val knownLocations = listOf(
            "Kharadi", "Baner", "Viman Nagar", "Balewadi", "Hinjawadi", "Koregaon Park",
            "Shivaji Nagar", "Magarpatta", "Hadapsar", "Aundh", "Kalyani Nagar", "Wakad",
            "Pimple Nilakh", "Ravet", "Bhavani Peth", "FC Road", "JM Road", "Senapati Bapat Road"
        )
        val foundLocations = knownLocations.filter { lower.contains(it.lowercase()) }

        val propertyType = when {
            lower.contains("office") -> "Office"
            lower.contains("shop") -> "Shop"
            lower.contains("showroom") -> "Showroom"
            lower.contains("warehouse") || lower.contains("godown") -> "Warehouse"
            lower.contains("pre-leased") || lower.contains("preleased") -> "Pre-Leased"
            lower.contains("1 bhk") || lower.contains("1bhk") -> "1 BHK"
            lower.contains("2 bhk") || lower.contains("2bhk") -> "2 BHK"
            lower.contains("3.5 bhk") || lower.contains("3.5bhk") -> "3.5 BHK"
            lower.contains("3 bhk") || lower.contains("3bhk") -> "3 BHK"
            lower.contains("4 bhk") || lower.contains("4bhk") -> "4 BHK"
            lower.contains("villa") || lower.contains("bungalow") -> "Villa / Bungalow"
            lower.contains("plot") -> "Plot"
            lower.contains("flat") || lower.contains("apartment") -> "Apartment"
            else -> ""
        }

        val transactionType = when {
            lower.contains("rent") || lower.contains("lease") -> "Lease"
            lower.contains("sale") || lower.contains("buy") || lower.contains("outright") || lower.contains("resale") -> "Sale"
            else -> ""
        }

        var maxPrice: Double? = null
        var minPrice: Double? = null

        val crRegex = Regex("""(\d+[\d,.]*)\s*(cr|crore)""", RegexOption.IGNORE_CASE)
        val lacRegex = Regex("""(\d+[\d,.]*)\s*(lac|lakh|lacs|l)""", RegexOption.IGNORE_CASE)

        val lacMatches = lacRegex.findAll(query).toList()
        if (lacMatches.isNotEmpty()) {
            val vals = lacMatches.mapNotNull { it.groupValues[1].replace(",", "").toDoubleOrNull()?.times(100_000.0) }
            if (vals.size >= 2) {
                minPrice = vals.minOrNull()
                maxPrice = vals.maxOrNull()
            } else if (vals.isNotEmpty()) {
                maxPrice = vals[0]
            }
        } else {
            val crMatches = crRegex.findAll(query).toList()
            if (crMatches.isNotEmpty()) {
                val vals = crMatches.mapNotNull { it.groupValues[1].replace(",", "").toDoubleOrNull()?.times(10_000_000.0) }
                if (vals.size >= 2) {
                    minPrice = vals.minOrNull()
                    maxPrice = vals.maxOrNull()
                } else if (vals.isNotEmpty()) {
                    maxPrice = vals[0]
                }
            }
        }

        var minCarpet: Double? = null
        var maxCarpet: Double? = null
        val sqftRangeRegex = Regex("""(\d+[\d,.]*)\s*[-–to\s]+\s*(\d+[\d,.]*)\s*(sq\.?ft|sqft|sft|carpet)""", RegexOption.IGNORE_CASE)
        val singleSqftRegex = Regex("""(\d+[\d,.]*)\s*(sq\.?ft|sqft|sft|carpet)""", RegexOption.IGNORE_CASE)

        sqftRangeRegex.find(query)?.let {
            minCarpet = it.groupValues[1].replace(",", "").toDoubleOrNull()
            maxCarpet = it.groupValues[2].replace(",", "").toDoubleOrNull()
        } ?: singleSqftRegex.find(query)?.let {
            val v = it.groupValues[1].replace(",", "").toDoubleOrNull()
            if (lower.contains("under") || lower.contains("below") || lower.contains("up to")) {
                maxCarpet = v
            } else {
                minCarpet = v
            }
        }

        val furnishing = when {
            lower.contains("fully furnished") || lower.contains("fully-furnished") || lower.contains("furnished") -> FurnishingType.FULLY_FURNISHED
            lower.contains("semi furnished") || lower.contains("semi-furnished") -> FurnishingType.SEMI_FURNISHED
            lower.contains("warm shell") -> FurnishingType.WARM_SHELL
            lower.contains("bare shell") -> FurnishingType.BARE_SHELL
            lower.contains("unfurnished") -> FurnishingType.UNFURNISHED
            else -> null
        }

        val isVague = foundLocations.isEmpty() && propertyType.isBlank() && maxPrice == null && minCarpet == null && maxCarpet == null

        return ExtractedClientRequirement(
            rawPrompt = query,
            portfolio = portfolio,
            propertyType = propertyType,
            transactionType = transactionType,
            minPriceOrRent = minPrice,
            maxPriceOrRent = maxPrice,
            minCarpetSqFt = minCarpet,
            maxCarpetSqFt = maxCarpet,
            locations = foundLocations,
            furnishing = furnishing,
            bhkConfig = if (propertyType.contains("BHK")) propertyType else null,
            isVague = isVague,
            extractionSource = "Smart Pattern Recognition Engine"
        )
    }

    fun detectPortfolioFromQuery(query: String): Brand? {
        val lower = query.lowercase()
        val commScore = listOf("office", "shop", "showroom", "warehouse", "pre-leased", "commercial", "lease", "workstation").count { lower.contains(it) }
        val resiScore = listOf("bhk", "flat", "villa", "apartment", "bungalow", "residential", "resi").count { lower.contains(it) }
        return when {
            commScore > resiScore -> Brand.ASCEND_COMMERCIAL
            resiScore > commScore -> Brand.AUREA_LIVING
            else -> null
        }
    }

    /**
     * Executes property filtering using the extracted client requirement rules against actual Master Inventory.
     */
    fun executeNaturalSearch(
        req: ExtractedClientRequirement,
        inventory: List<PropertyItem>
    ): NaturalSearchResult {
        val portfolioFiltered = when (req.portfolio) {
            Brand.ASCEND_COMMERCIAL -> inventory.filter { it.isCommercial() }
            Brand.AUREA_LIVING -> inventory.filter { it.isResidential() }
            null -> inventory
        }

        val scored = portfolioFiltered.map { prop ->
            var score = 50
            val reasons = mutableListOf<String>()

            if (req.locations.isNotEmpty()) {
                val propLoc = prop.location.lowercase()
                if (req.locations.any { propLoc.contains(it.lowercase()) }) {
                    score += 25
                    reasons.add("Micro-market match: ${prop.location}")
                }
            }

            if (req.propertyType.isNotBlank()) {
                val pType = prop.propertyType.lowercase()
                val reqType = req.propertyType.lowercase()
                if (pType.contains(reqType) || (reqType.contains("office") && prop.isCommercial())) {
                    score += 20
                    reasons.add("Property type matches ${req.propertyType}")
                }
            }

            if (req.transactionType.isNotBlank()) {
                val isReqRental = req.transactionType.contains("lease", ignoreCase = true) || req.transactionType.contains("rent", ignoreCase = true)
                if (prop.tab.isRental == isReqRental) {
                    score += 15
                    reasons.add(if (isReqRental) "Rental structure match" else "Outright sale match")
                }
            }

            if (req.maxPriceOrRent != null && req.maxPriceOrRent > 0) {
                if (prop.priceOrRent <= req.maxPriceOrRent) {
                    score += 20
                    reasons.add("Price within budget (${CalculationUtils.formatIndianCurrency(prop.priceOrRent, prop.tab.isRental)})")
                } else if (prop.priceOrRent <= req.maxPriceOrRent * 1.15) {
                    score += 5
                    reasons.add("Slightly above budget (${CalculationUtils.formatIndianCurrency(prop.priceOrRent, prop.tab.isRental)})")
                }
            }

            if (req.minCarpetSqFt != null && req.maxCarpetSqFt != null) {
                if (prop.carpetAreaSqFt >= req.minCarpetSqFt && prop.carpetAreaSqFt <= req.maxCarpetSqFt * 1.1) {
                    score += 15
                    reasons.add("Carpet area in range (${prop.carpetAreaSqFt.toInt()} sq.ft)")
                }
            } else if (req.maxCarpetSqFt != null) {
                if (prop.carpetAreaSqFt <= req.maxCarpetSqFt * 1.1) {
                    score += 15
                    reasons.add("Carpet area up to ${req.maxCarpetSqFt.toInt()} sq.ft")
                }
            } else if (req.minCarpetSqFt != null) {
                if (prop.carpetAreaSqFt >= req.minCarpetSqFt * 0.9) {
                    score += 15
                    reasons.add("Carpet area above ${req.minCarpetSqFt.toInt()} sq.ft")
                }
            }

            if (req.furnishing != null && prop.furnishing == req.furnishing) {
                score += 10
                reasons.add("Furnishing match: ${prop.furnishing.label}")
            }

            val finalScore = score.coerceIn(20, 98)
            ClientMatchResult(
                property = prop,
                matchScorePercent = finalScore,
                matchingReasons = reasons.ifEmpty { listOf("Active property in portfolio") },
                matchType = if (finalScore >= 75) "Exact Match" else if (finalScore >= 55) "Close Match" else "Alternative"
            )
        }.sortedByDescending { it.matchScorePercent }

        val matches = scored.filter { it.matchScorePercent >= 60 }.map { it.property }

        val alternatives = if (matches.isEmpty()) {
            portfolioFiltered.take(3)
        } else emptyList()

        return NaturalSearchResult(
            exactMatches = matches,
            alternatives = alternatives,
            isVague = req.isVague || (req.locations.isEmpty() && req.maxPriceOrRent == null),
            extractedRequirement = req
        )
    }

    /**
     * FIND PROPERTY FOR CLIENT
     * Strictly searches ONLY the current tenant's private inventory.
     * Groups results into: Exact Matches, Close Matches, Alternative Properties.
     */
    fun matchClientRequirementsCategorized(requirementText: String, tenantInventory: List<PropertyItem>): List<ClientMatchCategory> {
        val lower = requirementText.lowercase()

        val allResults = tenantInventory.map { prop ->
            var score = 40
            val reasons = mutableListOf<String>()

            // Location
            val propLoc = prop.location.lowercase()
            if (lower.split(" ", ",", "\n").any { it.length > 3 && propLoc.contains(it) }) {
                score += 30
                reasons.add("Exact micro-market match: ${prop.location}")
            }

            // Category / Type
            if (lower.contains("office") && (prop.tab == InventoryTab.OFF_LEASE || prop.tab == InventoryTab.OFF_OUT)) {
                score += 20
                reasons.add("Category matches Commercial Office")
            } else if (lower.contains("rent") && prop.tab.isRental) {
                score += 15
                reasons.add("Rental structure matches")
            } else if (lower.contains("bhk") && (prop.bhk != null && lower.contains(prop.bhk.lowercase().take(5)))) {
                score += 25
                reasons.add("Configuration match: ${prop.bhk}")
            }

            // Furnishing
            if (lower.contains("fully furnished") && prop.furnishing == FurnishingType.FULLY_FURNISHED) {
                score += 15
                reasons.add("Furnishing matches: Fully Furnished")
            }

            val finalScore = score.coerceIn(20, 98)
            val matchType = when {
                finalScore >= 80 -> "Exact Match"
                finalScore >= 60 -> "Close Match"
                else -> "Alternative"
            }

            ClientMatchResult(
                property = prop,
                matchScorePercent = finalScore,
                matchingReasons = reasons.ifEmpty { listOf("Available in current tenant portfolio") },
                matchType = matchType
            )
        }.sortedByDescending { it.matchScorePercent }

        val exact = allResults.filter { it.matchType == "Exact Match" }
        val close = allResults.filter { it.matchType == "Close Match" }
        val alternatives = allResults.filter { it.matchType == "Alternative" }.take(3)

        return listOf(
            ClientMatchCategory("Exact Matches (${exact.size})", exact),
            ClientMatchCategory("Close Matches (${close.size})", close),
            ClientMatchCategory("Alternative Properties (${alternatives.size})", alternatives)
        ).filter { it.results.isNotEmpty() }
    }

    /**
     * CUSTOM WHATSAPP WRITE-UP GENERATOR
     * Supports presets and tone adjustments. Never leaks confidential contacts.
     */
    fun generateCustomWhatsAppPitch(
        properties: List<PropertyItem>,
        promptStyle: String,
        companyName: String,
        companyContact: String
    ): String {
        val isShort = promptStyle.contains("short", ignoreCase = true)
        val isInvestor = promptStyle.contains("investor", ignoreCase = true) || promptStyle.contains("pre-leased", ignoreCase = true)
        val isBroker = promptStyle.contains("broker", ignoreCase = true)

        val sb = StringBuilder()
        sb.append("✨ *EXCLUSIVE MANDATE | $companyName*\n\n")

        properties.forEachIndexed { i, prop ->
            if (properties.size > 1) {
                sb.append("*OPTION ${i + 1}: ${prop.projectName.uppercase()}*\n")
            } else {
                sb.append("🏢 *${prop.projectName.uppercase()}*\n")
            }

            sb.append("📍 Location: ${prop.location}\n")
            sb.append("📐 Carpet Area: ${prop.carpetAreaSqFt.toInt()} sq.ft\n")
            sb.append("🛋 Furnishing: ${prop.furnishing.label}\n")

            if (isInvestor && prop.roiPercent != null) {
                sb.append("📈 ROI Yield: ${prop.roiPercent}%\n")
                sb.append("💼 Tenant: ${prop.tenantName ?: "MNC Corporate"}\n")
            }

            sb.append("💰 Commercials: ${CalculationUtils.formatIndianCurrency(prop.priceOrRent, prop.tab.isRental)}\n")

            if (!isShort) {
                sb.append("🚗 Parking: ${prop.parking}\n")
                sb.append("🔑 Possession: ${prop.possession}\n")
                if (prop.amenities.isNotEmpty()) {
                    sb.append("🌟 Amenities: ${prop.amenities.take(3).joinToString(", ")}\n")
                }
            }
            sb.append("\n")
        }

        if (isBroker) {
            sb.append("🤝 *Broker Welcome* — Side-by-side inspection can be arranged today.\n")
        } else {
            sb.append("Direct verified mandate through $companyName.\n")
        }

        sb.append("📞 *Direct Connect:* $companyContact")
        return sb.toString().trim()
    }

    fun matchClientRequirements(requirementText: String, inventory: List<PropertyItem>): List<ClientMatchResult> {
        return matchClientRequirementsCategorized(requirementText, inventory).flatMap { it.results }
    }

    fun generatePropertyPitch(property: PropertyItem): String {
        return generateCustomWhatsAppPitch(
            properties = listOf(property),
            promptStyle = "Make a premium short WhatsApp message",
            companyName = if (property.tab.brand == Brand.ASCEND_COMMERCIAL) "COMMERCIAL PORTFOLIO" else "RESIDENTIAL PORTFOLIO",
            companyContact = "9766880099 | 9766668099"
        )
    }
}
