package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AvailabilityStatus
import com.example.model.Brand
import com.example.model.FurnishingType
import com.example.model.InventoryTab
import com.example.ui.theme.*

data class FilterState(
    val brand: Brand? = null,
    val tab: InventoryTab? = null,
    val status: AvailabilityStatus? = null,
    val furnishing: FurnishingType? = null,
    val minCarpet: Double = 0.0,
    val maxPrice: Double = Double.MAX_VALUE,
    val bhkFilter: String? = null,
    val onlyMainRoad: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterSheet(
    filterState: FilterState,
    onFilterChange: (FilterState) -> Unit,
    onDismiss: () -> Unit
) {
    var state by remember { mutableStateOf(filterState) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = BrandCharcoalSurface,
        dragHandle = { BottomSheetDefaults.DragHandle(color = AscendGold) },
        modifier = Modifier.testTag("filter_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Advanced Inventory Filters",
                    color = TextPrimaryDark,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                TextButton(
                    onClick = {
                        state = FilterState()
                        onFilterChange(state)
                    }
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp), tint = AscendGold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reset All", color = AscendGold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Brand Selector
            FilterSectionTitle("BUSINESS SEGMENT")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChipItem(
                    label = "All Businesses",
                    isSelected = state.brand == null,
                    onClick = { state = state.copy(brand = null) }
                )
                FilterChipItem(
                    label = "Commercial",
                    isSelected = state.brand == Brand.ASCEND_COMMERCIAL,
                    onClick = { state = state.copy(brand = Brand.ASCEND_COMMERCIAL) }
                )
                FilterChipItem(
                    label = "Residential",
                    isSelected = state.brand == Brand.AUREA_LIVING,
                    onClick = { state = state.copy(brand = Brand.AUREA_LIVING) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Inventory Tab
            FilterSectionTitle("INVENTORY TAB (8 SHEETS)")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChipItem(
                        label = "All Sheets",
                        isSelected = state.tab == null,
                        onClick = { state = state.copy(tab = null) }
                    )
                }
                items(InventoryTab.values().filter { it != InventoryTab.UND_CONST }) { tab ->
                    FilterChipItem(
                        label = tab.code,
                        isSelected = state.tab == tab,
                        onClick = { state = state.copy(tab = tab) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Availability Status
            FilterSectionTitle("VERIFICATION / STATUS")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChipItem(
                    label = "All Statuses",
                    isSelected = state.status == null,
                    onClick = { state = state.copy(status = null) }
                )
                AvailabilityStatus.values().forEach { st ->
                    FilterChipItem(
                        label = st.label,
                        isSelected = state.status == st,
                        onClick = { state = state.copy(status = st) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Carpet Area
            FilterSectionTitle("MINIMUM CARPET AREA")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.0 to "Any Area", 1000.0 to ">1k sqft", 2000.0 to ">2k sqft", 3500.0 to ">3.5k sqft").forEach { (sqft, label) ->
                    FilterChipItem(
                        label = label,
                        isSelected = state.minCarpet == sqft,
                        onClick = { state = state.copy(minCarpet = sqft) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Furnishing
            FilterSectionTitle("FURNISHING CONDITION")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChipItem(
                        label = "Any Furnishing",
                        isSelected = state.furnishing == null,
                        onClick = { state = state.copy(furnishing = null) }
                    )
                }
                items(FurnishingType.values()) { furn ->
                    FilterChipItem(
                        label = furn.label,
                        isSelected = state.furnishing == furn,
                        onClick = { state = state.copy(furnishing = furn) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Apply Button
            Button(
                onClick = {
                    onFilterChange(state)
                    onDismiss()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AscendGold,
                    contentColor = BrandCharcoalDark
                )
            ) {
                Text("Apply Filters", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun FilterSectionTitle(title: String) {
    Text(
        text = title,
        color = AscendGold,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.8.sp,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}

@Composable
fun FilterChipItem(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) AscendGold else BrandCharcoalCard)
            .border(
                width = 0.8.dp,
                color = if (isSelected) AscendGold else BrandCharcoalBorder,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) BrandCharcoalDark else TextSecondaryDark,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
