package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================================================
// TLC-1 APPROVED DESIGN SYSTEM — Deep Navy, Premium Teal & Soft White
// ============================================================================

val DeepNavy = Color(0xFF102A43)         // Primary Header / Brand Navy (#102A43)
val PremiumTeal = Color(0xFF007F83)      // Primary Interactive Accent / Active Pill (#007F83)
val PremiumTealLight = Color(0xFFE6F4F4) // Subtle Teal Container Tint
val SoftWhiteBg = Color(0xFFF7F9FB)      // App Canvas Background (#F7F9FB)
val PureWhiteCard = Color(0xFFFFFFFF)    // Elevated Card Surface (#FFFFFF)
val NavyPrimaryText = Color(0xFF172B4D)  // Primary Text (#172B4D)
val SlateSecondaryText = Color(0xFF66788A) // Secondary Text (#66788A)
val CardDividerBorder = Color(0xFFE2E8F0)  // Subtle Card Border & Hairline Divider

// Backward-compatible semantic aliases used across screens
val AscendGold = Color(0xFF007F83)       // Mapped to Premium Teal (#007F83) for consistent primary actions
val AscendGoldLight = Color(0xFF26999D)
val AscendGoldDark = Color(0xFF102A43)   // Deep Navy (#102A43)
val AscendGoldSubtle = Color(0xFFF0F7F7)

val BrandCharcoalDark = Color(0xFFF7F9FB)    // Soft White Background (#F7F9FB)
val BrandCharcoalSurface = Color(0xFFFFFFFF) // White Surface (#FFFFFF)
val BrandCharcoalCard = Color(0xFFFFFFFF)    // White Card Surface (#FFFFFF)
val BrandCharcoalBorder = Color(0xFFE2E8F0)  // Subtle Border
val BrandOffBlack = Color(0xFF102A43)        // Deep Navy

val BrandOffWhiteBg = Color(0xFFF7F9FB)
val BrandOffWhiteSurface = Color(0xFFFFFFFF)
val BrandOffWhiteCard = Color(0xFFFFFFFF)
val BrandOffWhiteBorder = Color(0xFFE2E8F0)

val TextPrimaryDark = Color(0xFF172B4D)      // Primary Text (#172B4D)
val TextSecondaryDark = Color(0xFF66788A)    // Secondary Text (#66788A)
val TextMutedDark = Color(0xFF66788A)        // Supporting Muted Text (#66788A)

val TextPrimaryLight = Color(0xFF172B4D)
val TextSecondaryLight = Color(0xFF66788A)
val TextMutedLight = Color(0xFF66788A)

// Status Colors
val StatusAvailable = Color(0xFF1E9E52)      // Available Green
val StatusAvailableBg = Color(0xFFE8F8EE)
val StatusUnconfirmed = Color(0xFFD97706)    // Pending Verification Amber
val StatusUnconfirmedBg = Color(0xFFFFFBEB)
val StatusNotAvailable = Color(0xFFDC3545)   // Rented / Leased / Sold Red
val StatusNotAvailableBg = Color(0xFFFEF2F2)
val StatusArchivedGrey = Color(0xFF7B8794)   // Archived Neutral Grey
val StatusArchivedBg = Color(0xFFF1F5F9)

// Pill & Brand Tag Tints (Matching TLC-1 Visualisation)
val PillCategoryBlueBg = Color(0xFFDCEEFB)
val PillCategoryBlueText = Color(0xFF0B4F71)
val PillBrandPurpleBg = Color(0xFFEDE2FE)
val PillBrandPurpleText = Color(0xFF5A2A82)

// Data Completion Bar Colors
val CompletionLowRed = Color(0xFFEF4444)
val CompletionMidYellow = Color(0xFFF59E0B)
val CompletionHighGreen = Color(0xFF10B981)

val CommercialBlue = Color(0xFF102A43)
val CommercialBlueBg = Color(0xFFDCEEFB)
val ResidentialEmerald = Color(0xFF007F83)
val ResidentialEmeraldBg = Color(0xFFE6F4F4)
val ResidentialRose = Color(0xFFBE123C)
val PreLeasedAmber = Color(0xFFB45309)
val UnderConstTeal = Color(0xFF007F83)
val ResidentialGold = Color(0xFF007F83)
val AureaGold = Color(0xFF007F83)

val SurfacePlaceholder = Color(0xFFEFF3F8)
val MapWaterTint = Color(0xFFBFDBFE)
val MapGridLine = Color(0xFFE2E8F0)
val MapRoadStroke = Color(0xFFCBD5E1)
