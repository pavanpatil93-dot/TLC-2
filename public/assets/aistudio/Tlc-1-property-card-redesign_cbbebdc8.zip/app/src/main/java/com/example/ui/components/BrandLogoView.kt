package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.model.Brand
import com.example.ui.theme.*

@Composable
fun BrandLogoView(
    brand: Brand?,
    customLogoUri: String?,
    size: Dp = 38.dp,
    modifier: Modifier = Modifier
) {
    if (!customLogoUri.isNullOrBlank()) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(customLogoUri)
                .crossfade(true)
                .build(),
            contentDescription = when (brand) {
                Brand.ASCEND_COMMERCIAL -> "Ascend Commercial Logo"
                Brand.AUREA_LIVING -> "Aurea Living Logo"
                null -> "Real Estate Inventory Logo"
            },
            contentScale = ContentScale.Crop,
            modifier = modifier
                .size(size)
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, AscendGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
        )
    } else {
        // High-Fidelity Styled Portfolio Monogram Badge
        when (brand) {
            Brand.ASCEND_COMMERCIAL -> {
                Box(
                    modifier = modifier
                        .size(size)
                        .clip(RoundedCornerShape(8.dp))
                        .background(BrandCharcoalSurface)
                        .border(1.2.dp, AscendGold, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "C",
                        color = AscendGold,
                        fontWeight = FontWeight.Black,
                        fontSize = (size.value * 0.55).sp
                    )
                }
            }
            Brand.AUREA_LIVING -> {
                Box(
                    modifier = modifier
                        .size(size)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F291E))
                        .border(1.2.dp, Color(0xFF10B981), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "R",
                        color = Color(0xFF6EE7B7),
                        fontWeight = FontWeight.Black,
                        fontSize = (size.value * 0.55).sp
                    )
                }
            }
            null -> {
                Box(
                    modifier = modifier
                        .size(size)
                        .clip(RoundedCornerShape(8.dp))
                        .background(AscendGold)
                        .border(1.2.dp, AscendGoldLight, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "RE",
                        color = BrandCharcoalDark,
                        fontWeight = FontWeight.Black,
                        fontSize = (size.value * 0.45).sp
                    )
                }
            }
        }
    }
}
