package com.example

import com.example.model.*
import com.example.ui.components.resolveCardStatusStyle
import com.example.ui.components.resolveCompletionBarColor
import com.example.ui.theme.*
import org.junit.Assert.*
import org.junit.Test

/**
 * PART 8 — TESTING AND VALIDATION FOR TLC-1 PROPERTY CARD REDESIGN
 * Uses disposable synthetic test objects only (never modifies or touches real inventory).
 */
class PropertyCardRedesignTest {

    @Test
    fun testCommercialCardRenderingAndMetrics() {
        val commProp = PropertyItem(
            id = "test_comm_1",
            propertyCode = "LO-KHD-901",
            projectName = "Test Business Hub",
            location = "Kharadi",
            propertyType = "Office",
            tab = InventoryTab.OFF_LEASE,
            carpetAreaSqFt = 2000.0,
            builtUpAreaSqFt = 2600.0,
            priceOrRent = 160000.0,
            furnishing = FurnishingType.FULLY_FURNISHED,
            floor = "4th Floor",
            status = AvailabilityStatus.AVAILABLE,
            ownerName = "Test Owner",
            ownerContact = "9000000001"
        )

        assertTrue(commProp.isCommercial())
        assertFalse(commProp.isResidential())
        assertEquals("2,000", CalculationUtils.formatAreaNumber(commProp.carpetAreaSqFt))
        assertEquals("2,600", CalculationUtils.formatAreaNumber(commProp.builtUpAreaSqFt!!))
        assertEquals("₹1.6 Lac/mo", CalculationUtils.formatIndianCurrency(commProp.priceOrRent, isMonthly = true))
        val rentPerSqFt = CalculationUtils.calculateRentPerCarpet(commProp.priceOrRent, commProp.carpetAreaSqFt)
        assertNotNull(rentPerSqFt)
        assertEquals(80, rentPerSqFt!!.toInt())
    }

    @Test
    fun testResidentialCardRenderingAndMetrics() {
        val resiProp = PropertyItem(
            id = "test_resi_1",
            propertyCode = "RS-VIM-202",
            projectName = "Test Residency",
            location = "Viman Nagar",
            propertyType = "Apartment",
            tab = InventoryTab.RESI_RESALE,
            bhk = "3 BHK",
            carpetAreaSqFt = 1350.0,
            priceOrRent = 15000000.0,
            possession = "Immediate",
            status = AvailabilityStatus.AVAILABLE
        )

        assertTrue(resiProp.isResidential())
        assertFalse(resiProp.isCommercial())
        assertEquals("3 BHK", resiProp.bhk)
        assertEquals("1,350", CalculationUtils.formatAreaNumber(resiProp.carpetAreaSqFt))
        assertEquals("₹1.5 Cr", CalculationUtils.formatIndianCurrency(resiProp.priceOrRent, isMonthly = false))
    }

    @Test
    fun testMissingPropertyInformationHandledGracefully() {
        val sparseProp = PropertyItem(
            id = "test_sparse_1",
            propertyCode = "LO-001",
            projectName = "",
            location = "",
            carpetAreaSqFt = 0.0,
            builtUpAreaSqFt = null,
            priceOrRent = 0.0,
            ownerName = null,
            ownerContact = null,
            images = emptyList()
        )

        // Missing values must never fabricate prices or measurements
        assertNull(CalculationUtils.calculateRentPerCarpet(sparseProp.priceOrRent, sparseProp.carpetAreaSqFt))
        assertNull(CalculationUtils.calculateRatePerBuiltUp(sparseProp.priceOrRent, sparseProp.builtUpAreaSqFt))
        assertEquals("0", CalculationUtils.formatAreaNumber(sparseProp.carpetAreaSqFt))
        assertTrue(sparseProp.images.isEmpty())
    }

    @Test
    fun testAvailabilityAndArchivedStatusLabelsAndColors() {
        val availProp = PropertyItem(id = "1", tab = InventoryTab.OFF_LEASE, status = AvailabilityStatus.AVAILABLE)
        val (availLabel, availColor, _) = resolveCardStatusStyle(availProp)
        assertEquals("Available", availLabel)
        assertEquals(StatusAvailable, availColor)

        val pendingProp = PropertyItem(id = "2", tab = InventoryTab.OFF_LEASE, status = AvailabilityStatus.NOT_CONFIRMED)
        val (pendLabel, pendColor, _) = resolveCardStatusStyle(pendingProp)
        assertEquals("Pending Verification", pendLabel)
        assertEquals(StatusUnconfirmed, pendColor)

        val rentedProp = PropertyItem(id = "3", tab = InventoryTab.OFF_LEASE, status = AvailabilityStatus.NOT_AVAILABLE)
        val (rentedLabel, rentedColor, _) = resolveCardStatusStyle(rentedProp)
        assertEquals("Rented", rentedLabel)
        assertEquals(StatusNotAvailable, rentedColor)

        val soldProp = PropertyItem(id = "4", tab = InventoryTab.OFF_OUT, status = AvailabilityStatus.NOT_AVAILABLE)
        val (soldLabel, soldColor, _) = resolveCardStatusStyle(soldProp)
        assertEquals("Sold", soldLabel)
        assertEquals(StatusNotAvailable, soldColor)

        val archivedProp = PropertyItem(
            id = "5",
            tab = InventoryTab.OFF_LEASE,
            status = AvailabilityStatus.AVAILABLE,
            archiveStatus = ArchiveStatus.ARCHIVED
        )
        val (archLabel, archColor, _) = resolveCardStatusStyle(archivedProp)
        assertEquals("Archived", archLabel)
        assertEquals(StatusArchivedGrey, archColor)
    }

    @Test
    fun testDataCompletionCalculationsAndBarColors() {
        val incompleteComm = PropertyItem(
            id = "inc_1",
            propertyCode = "LO-100",
            projectName = "",
            location = "",
            propertyType = "",
            carpetAreaSqFt = 0.0,
            priceOrRent = 0.0,
            ownerName = null,
            ownerContact = null,
            tab = InventoryTab.OFF_LEASE
        )
        val lowScore = CalculationUtils.computeCompletenessScore(incompleteComm)
        assertTrue("Incomplete property must score < 50%", lowScore < 50)
        assertEquals(CompletionLowRed, resolveCompletionBarColor(lowScore))

        val partialComm = PropertyItem(
            id = "part_1",
            propertyCode = "LO-101",
            projectName = "Tower A",
            location = "Kharadi",
            propertyType = "Office",
            carpetAreaSqFt = 0.0,
            priceOrRent = 0.0,
            tab = InventoryTab.OFF_LEASE
        )
        val midScore = CalculationUtils.computeCompletenessScore(partialComm)
        assertTrue("Partially complete property must score between 50% and 79%", midScore in 50..79)
        assertEquals(CompletionMidYellow, resolveCompletionBarColor(midScore))

        val completeComm = PropertyItem(
            id = "comp_1",
            propertyCode = "LO-102",
            projectName = "Tower A",
            location = "Kharadi",
            propertyType = "Office",
            carpetAreaSqFt = 1500.0,
            priceOrRent = 120000.0,
            ownerName = "Owner Name",
            ownerContact = "9000000009",
            tab = InventoryTab.OFF_LEASE
        )
        val highScore = CalculationUtils.computeCompletenessScore(completeComm)
        assertEquals(100, highScore)
        assertEquals(CompletionHighGreen, resolveCompletionBarColor(highScore))
    }

    @Test
    fun testPreservationOfPropertyIdentifiersAndOptionalClearing() {
        val original = PropertyItem(
            id = "legacy_id_99",
            propertyCode = "LO-LEGACY-99",
            projectName = "Saved Building",
            location = "Kharadi",
            builtUpAreaSqFt = 2500.0,
            floor = "5th Floor",
            ownerName = "Saved Owner"
        )
        val clearedOptional = original.copy(builtUpAreaSqFt = null, floor = "")
        // Preserves original ID and property code while allowing optional fields to be cleared
        assertEquals("legacy_id_99", clearedOptional.id)
        assertEquals("LO-LEGACY-99", clearedOptional.propertyCode)
        assertNull(clearedOptional.builtUpAreaSqFt)
        assertEquals("", clearedOptional.floor)
    }
}
