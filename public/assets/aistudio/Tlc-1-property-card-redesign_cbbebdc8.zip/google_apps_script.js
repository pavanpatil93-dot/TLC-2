/**
 * ASCEND & AUREA MASTER INVENTORY 2-WAY SYNC API
 * 
 * SETUP INSTRUCTIONS:
 * 1. Open your Google Sheet.
 * 2. Go to Extensions > Apps Script.
 * 3. Delete any existing code and PASTE THIS ENTIRE FILE.
 * 4. Click 'Deploy' > 'New Deployment'.
 * 5. Select 'Web App'.
 * 6. Execute as: 'Me'.
 * 7. Who has access: 'Anyone'.
 * 8. Copy the 'Web App URL' and paste it into the App's Sync screen.
 */

function doGet(e) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var tabs = ['Off Lease','Off Out','Shop Lease','Shop Out','Pre - Leased','Resi Rent','Resi Resale','Und Const'];
  var data = {};
  
  tabs.forEach(function(t) {
    var sheet = ss.getSheetByName(t);
    if (sheet) {
      data[t] = sheet.getDataRange().getValues();
    }
  });
  
  return ContentService.createTextOutput(JSON.stringify({ status: 'success', data: data }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  var postData = JSON.parse(e.postData.contents);
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheetName = postData.tab;
  var sheet = ss.getSheetByName(sheetName) || ss.getSheets()[0];
  
  var action = postData.action; // "ADD" or "UPDATE"
  var propertyCode = postData.propertyCode;
  
  var dataRange = sheet.getDataRange();
  var values = dataRange.getValues();
  var headers = values[0];
  
  // Find row index by property code
  var rowIndex = -1;
  for (var i = 1; i < values.length; i++) {
    if (values[i][0] == propertyCode) {
      rowIndex = i + 1;
      break;
    }
  }
  
  // Prepare row data based on standard 24-column structure
  // 1:Code, 2:Date, 3:Loc, 4:Project, 5:Unit, 6:Floor, 7:Type, 8:SubType, 9:Carpet, 10:Builtup, 11:Price, 12:Rent...
  var row = new Array(24).fill("");
  row[0] = postData.propertyCode;
  row[1] = postData.timestamp;
  row[2] = postData.location;
  row[3] = postData.projectName;
  row[4] = postData.unitNumber;
  row[5] = postData.floor;
  row[6] = "Commercial"; // Default
  row[7] = postData.tab;
  row[8] = postData.carpetAreaSqFt;
  row[10] = postData.priceOrRent; // Price
  row[11] = postData.priceOrRent; // Rent
  row[14] = postData.possession;
  row[15] = postData.furnishing;
  row[16] = postData.status;
  row[17] = postData.ownerName;
  row[18] = postData.ownerContact;
  row[19] = "App Sync";
  row[20] = postData.remarks;
  
  if (rowIndex > 0) {
    // UPDATE existing row
    sheet.getRange(rowIndex, 1, 1, row.length).setValues([row]);
  } else {
    // APPEND new row
    sheet.appendRow(row);
  }
  
  return ContentService.createTextOutput(JSON.stringify({ status: 'success', action: action }))
    .setMimeType(ContentService.MimeType.JSON);
}
