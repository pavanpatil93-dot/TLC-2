# Implementation Plan - Rebrand to Real Estate Inventory (Commercial & Residential)

Completely remove all occurrences of "Ascend", "Ascend Commercial Solutions", "Aurea", and "Aurea Living" across the entire Android application codebase, string resources, metadata, navigation, top bar, drawer, company settings, PDF flyers, WhatsApp sharing templates, and model classes, replacing them strictly with "Commercial" and "Residential" branding under the main app title "Real Estate Inventory".

## Proposed Changes

### 1. Application Name & String Resources
- Update `res/values/strings.xml` to set `app_name` to `"Real Estate Inventory"`.
- Update `metadata.json` to set `name` to `"Real Estate Inventory"` and description accordingly.
- Update `settings.gradle.kts` `rootProject.name` to `"Real Estate Inventory"`.

### 2. UI Components & Headers
- **`TopBar.kt`**:
  - Replace `"ASCEND & AUREA"` title with `"REAL ESTATE INVENTORY"`.
  - Replace `"ASCEND"` portfolio option with `"COMMERCIAL"`.
  - Replace `"AUREA"` portfolio option with `"RESIDENTIAL"`.
  - Update subtitles from `"COMMERCIAL SOLUTIONS"` / `"RESIDENTIAL PORTFOLIO"` to `"COMMERCIAL"` and `"RESIDENTIAL"`.
- **`AppNavigationDrawer.kt`**:
  - Rename drawer destinations `"Ascend Commercial"` to `"Commercial"` and `"Aurea Residential"` to `"Residential"`.
  - Update drawer header title to `"REAL ESTATE INVENTORY"`.
- **`BottomNavBar.kt`**:
  - Ensure labels remain clean ("Inventory", "Search", "Add", "AI Match", "Saved").
- **`BrandLogoView` & Logos (`BrandModels.kt`, `BrandLogoView.kt`)**:
  - Update `Brand` enum labels: `COMMERCIAL` ("Commercial") and `RESIDENTIAL` ("Residential").
  - Remove "Ascend" and "Aurea" text or logo references; replace default brand placeholders with sleek Commercial (Business) and Residential (Home/Building) vector icons.

### 3. Settings & Company Profiles
- **`UserSettingsManager.kt` & `SettingsScreen.kt`**:
  - Rename company profile references from "Ascend Commercial Solutions" and "Aurea Living" to "Commercial" and "Residential".
  - Update WhatsApp share footers and default company names to "Commercial Portfolio" and "Residential Portfolio".

### 4. Data Models & Repositories
- **`PropertyModels.kt`**:
  - Update brand/portfolio display helpers (`Brand.ASCEND_COMMERCIAL` -> `Brand.COMMERCIAL`, `Brand.AUREA_LIVING` -> `Brand.RESIDENTIAL`).
- **`SheetsRepository.kt`**:
  - Update diagnostic ping app name and generated Apps Script headers from "Ascend & Aurea" to "Real Estate Inventory".

## User Review Required

> [!IMPORTANT]
> This rebrand is strictly a UI text, label, and string replacement. Existing property codes, Google Sheet data, and inventory records will remain completely intact and untouched.
